﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Web.Helpers;
using System.Web.Mvc;
using CDSC.Migrations;
using CDSC.Models;
using CDSC.CDS;
using Vatenkecis = CDSC.Models.Vatenkecis;
using System.Security.Cryptography;
using System.Globalization;
using System.Net.Http;
using System.Web;
using System.Text.RegularExpressions;
using System.IO;
using Microsoft.VisualBasic;
using System.Data.Entity.Migrations;
using System.Threading.Tasks;
using System.Linq.Expressions;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Exceptions;
using CDSC.CERTS;
using CDSC.CDSFINSECS;
using System.Xml;
using System.Data.Entity;
using System.Web.Security;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Xml.Linq;
using HttpMultipartParser;

namespace CDSC.Controllers
{
    public class SubscriberController : Controller
    {


        public string index()
        {

            return "test me ";
        }
        readonly cdscDbContext _cdscDbContext = new cdscDbContext();
        readonly CdDataContext _cdDataContext = new CdDataContext();
        readonly AtsDbContext _AtsDbContext = new AtsDbContext();
        readonly FINSEC cDSFINSEC = new FINSEC();
        readonly CERT cERT = new CERT();
        string connectionStringCDSC = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
        string connectionStringCDS_Router = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
        string connectionStringCDS = ConfigurationManager.ConnectionStrings["CDS"].ConnectionString;
        string connectionStringATS = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
        string escrowshare = ConfigurationManager.ConnectionStrings["CERT"].ConnectionString;
        string finsec = ConfigurationManager.ConnectionStrings["FINSEC"].ConnectionString;
        readonly CDS.CDS _cdsDataContext = new CDS.CDS();
        private static readonly HttpClient client = new HttpClient();


        public JsonResult transCompanies(string group_cds_number)
        {


            var sql = "select distinct(Company) from cds_router.dbo.trans_groups where GroupID = '" + group_cds_number + "'";

            var shareAllocations = new List<TransId>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    TransId shareAllocation = new TransId
                    {

                        Company = rdr["Company"].ToString()


                    };
                    shareAllocations.Add(shareAllocation);


                }

                connection.Close();
            }

            return Json(shareAllocations, JsonRequestBehavior.AllowGet);
        }

        public JsonResult MarketDataDetails(string exchange)
        {


            var sql = "SELECT  top  1 [DateCaptured],BlackMarketBond,exhangeRate,percentageexhangeRate,percentageinterestRate,interestRate,BlackMarketRTGS,blackmarkertRTSPercentage,OMIRPercentage,blackmarkertBondPercentage,blackmarkertZWLPercentage, [SecurityType] ,TurnOverZWL,TurnOverUSD  ,indexpercentage  ,[MarkertPercentageIncr_DecreZWL], [MarkertPercentageIncr_DecreUSD],[TurnOverPercentageIncrease_DecrZWL],[TurnOverPercentageIncrease_DecrUSD],[MarkertCapZWL] ,[MarkertCapUSD],[Index]  ,[VolumeTrade],[SecuritySubType] ,[OMIR] ,[BlackMarketZWL] ,[BlackMarketUSD] ,[PriceUSD]  ,[PriceZWL]  ,[Rate] FROM[CDS].[dbo].[MarkertData] where  SecuritySubType = '" + exchange + "' order by id desc";

            var shareAllocations = new List<marketData>();

            using (SqlConnection connection = new SqlConnection(finsec))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    marketData shareAllocation = new marketData
                    {
                        blackmarkertZWLPercentage = rdr["blackmarkertZWLPercentage"].ToString(),
                        BlackMarketBond = rdr["BlackMarketBond"].ToString(),
                        BlackMarketRTGS = rdr["BlackMarketRTGS"].ToString(),

                        blackmarkertRTSPercentage = rdr["blackmarkertRTSPercentage"].ToString(),
                        blackmarkertBondPercentage = rdr["blackmarkertBondPercentage"].ToString(),
                        OMIRPercentage = rdr["OMIRPercentage"].ToString(),
                        interestRate = rdr["interestRate"].ToString(),
                        exhangeRate = rdr["exhangeRate"].ToString(),
                        percentageinterestRate = rdr["percentageinterestRate"].ToString(),
                        percentageexhangeRate = rdr["percentageexhangeRate"].ToString(),
                        MarkertPercentageIncr_DecreZWL = rdr["MarkertPercentageIncr_DecreZWL"].ToString(),
                        MarkertPercentageIncr_DecreUSD = rdr["MarkertPercentageIncr_DecreUSD"].ToString(),
                        turnoverZWL = rdr["TurnOverZWL"].ToString(),
                        turnoverUSD = rdr["TurnOverUSD"].ToString(),
                        TurnOverPercentageIncrease_DecrZWL = rdr["TurnOverPercentageIncrease_DecrZWL"].ToString(),

                        TurnOverPercentageIncrease_DecrUSD = rdr["TurnOverPercentageIncrease_DecrUSD"].ToString(),

                        DateCaptured = DateTime.Parse(rdr["DateCaptured"].ToString()).ToString("dd MMM yyyy"),
                        SecurityType = rdr["SecurityType"].ToString(),

                        indexpercentage = rdr["indexpercentage"].ToString(),
                        MarkertCapZWL = rdr["MarkertCapZWL"].ToString(),
                        MarkertCapUSD = rdr["MarkertCapUSD"].ToString(),


                        Index = rdr["Index"].ToString(),



                        VolumeTrade = rdr["VolumeTrade"].ToString(),

                        SecuritySubType = rdr["SecuritySubType"].ToString(),
                        OMIR = rdr["OMIR"].ToString(),
                        BlackMarketZWL = rdr["BlackMarketZWL"].ToString(),

                        BlackMarketUSD = rdr["BlackMarketUSD"].ToString(),

                        PriceUSD = rdr["PriceUSD"].ToString(),
                        PriceZWL = rdr["PriceZWL"].ToString(),
                        Rate = rdr["Rate"].ToString()



                    };
                    shareAllocations.Add(shareAllocation);


                }

                connection.Close();
            }

            return Json(shareAllocations, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getCompanyRatios(string company)
        {


            var sql = "Declare @company nvarchar(50) = '" + company + "' select top 1 current_,payout,earnings_bt,quick,ebtida,dept_or_equity,rsf.net_income as rsf_net_income,net_dept_lfi,roa,roi,roe,rme.net_income as rme_net_income,rme.revenue as rme_revenue, gross,net,operating,pretax,earnings_,book_value,rpsd.revenue as rpsd_revenue,cash,rpsd.cash_flow as rpsd_cash_flow,price_or_ratio,ptb,pts,ptf,dividend_yield_5yr_avg, dividend_yield_an_div_closing_p,div_per_share,rv.cash_flow as rv_cash_flow from ratios_financial_strength rsf cross join ratios_management_effectiness rme cross join ratios_margin rm cross join ratios_per_share_data rpsd cross join ratios_price rp cross join ratios_valuation rv where rsf.company = @company and rme.company = @company and rm.company = @company and rpsd.company = @company and rv.company = @company and rp.company = @company order by rsf.id,rme.id,rm.id,rpsd.id,rv.id,rp.id desc";

            var ratios = new List<CompanyRatios>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    RatiosManagementEffectiness rme = new RatiosManagementEffectiness
                    {
                        roe = rdr["roe"].ToString(),
                        roa = rdr["roa"].ToString(),
                        roi = rdr["roi"].ToString(),
                        net_income = rdr["rme_net_income"].ToString(),
                        revenue = rdr["rme_revenue"].ToString(),


                    };

                    RatiosMargin rm = new RatiosMargin
                    {

                        gross = rdr["gross"].ToString(),
                        net = rdr["net"].ToString(),
                        operating = rdr["operating"].ToString(),
                        pretax = rdr["pretax"].ToString(),


                    };
                    RatiosPerShareData rpsd = new RatiosPerShareData
                    {
                        earnings_ = rdr["earnings_"].ToString(),
                        book_value = rdr["book_value"].ToString(),
                        revenue = rdr["rpsd_revenue"].ToString(),
                        cash = rdr["cash"].ToString(),
                        cash_flow = rdr["rpsd_cash_flow"].ToString(),


                    };
                    RatiosPrice rp = new RatiosPrice
                    {
                        price_or_ratio = rdr["price_or_ratio"].ToString(),
                        ptb = rdr["ptb"].ToString(),
                        pts = rdr["pts"].ToString(),
                        ptf = rdr["ptf"].ToString(),


                    };
                    RatiosFinancialStrength rsf = new RatiosFinancialStrength
                    {
                        current_ = rdr["current_"].ToString(),
                        quick = rdr["quick"].ToString(),
                        payout = rdr["payout"].ToString(),
                        dept_or_equity = rdr["dept_or_equity"].ToString(),
                        ebtida = rdr["ebtida"].ToString(),
                        earnings_bt = rdr["earnings_bt"].ToString(),
                        net_income = rdr["rsf_net_income"].ToString(),
                        net_dept_lfi = rdr["net_dept_lfi"].ToString(),


                    };
                    RatiosValuation rv = new RatiosValuation
                    {
                        dividend_yield_5yr_avg = rdr["dividend_yield_5yr_avg"].ToString(),
                        dividend_yield_an_div_closing_p = rdr["dividend_yield_an_div_closing_p"].ToString(),
                        div_per_share = rdr["div_per_share"].ToString(),
                        cash_flow = rdr["rv_cash_flow"].ToString(),


                    };

                    CompanyRatios cr = new CompanyRatios()
                    {
                        ratiosFinancialStrength = rsf,
                        ratiosManagementEffectiness = rme,
                        ratiosMargin = rm,
                        ratiosPerShareData = rpsd,
                        ratiosPrice = rp,
                        ratiosValuation = rv

                    };
                    ratios.Add(cr);


                }

                connection.Close();
            }

            return Json(ratios, JsonRequestBehavior.AllowGet);
        }
        public JsonResult allSEData()
        {


            var sql = "SELECT * FROM[CDS].[dbo].[MarkertData] WHERE DateCaptured = CONVERT(date,GETDATE()) order by id desc";

            var shareAllocations = new List<marketData>();

            using (SqlConnection connection = new SqlConnection(finsec))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    marketData shareAllocation = new marketData
                    {

                        blackmarkertZWLPercentage = rdr["blackmarkertZWLPercentage"].ToString(),
                        BlackMarketBond = rdr["BlackMarketBond"].ToString(),
                        BlackMarketRTGS = rdr["BlackMarketRTGS"].ToString(),

                        blackmarkertRTSPercentage = rdr["blackmarkertRTSPercentage"].ToString(),
                        blackmarkertBondPercentage = rdr["blackmarkertBondPercentage"].ToString(),
                        OMIRPercentage = rdr["OMIRPercentage"].ToString(),
                        MarkertPercentageIncr_DecreZWL = rdr["MarkertPercentageIncr_DecreZWL"].ToString(),
                        MarkertPercentageIncr_DecreUSD = rdr["MarkertPercentageIncr_DecreUSD"].ToString(),

                        TurnOverPercentageIncrease_DecrZWL = rdr["TurnOverPercentageIncrease_DecrZWL"].ToString(),

                        TurnOverPercentageIncrease_DecrUSD = rdr["TurnOverPercentageIncrease_DecrUSD"].ToString(),

                        DateCaptured = DateTime.Parse(rdr["DateCaptured"].ToString()).ToString("dd MMM yyyy"),
                        SecurityType = rdr["SecurityType"].ToString(),

                        indexpercentage = rdr["indexpercentage"].ToString(),
                        MarkertCapZWL = rdr["MarkertCapZWL"].ToString(),
                        MarkertCapUSD = rdr["MarkertCapUSD"].ToString(),

                        turnoverZWL = rdr["TurnOverZWL"].ToString(),
                        turnoverUSD = rdr["TurnOverUSD"].ToString(),

                        Index = rdr["Index"].ToString(),

                        VolumeTrade = rdr["VolumeTrade"].ToString(),

                        SecuritySubType = rdr["SecuritySubType"].ToString(),
                        OMIR = rdr["OMIR"].ToString(),
                        BlackMarketZWL = rdr["BlackMarketZWL"].ToString(),

                        BlackMarketUSD = rdr["BlackMarketUSD"].ToString(),

                        PriceUSD = rdr["PriceUSD"].ToString(),
                        PriceZWL = rdr["PriceZWL"].ToString(),
                        Rate = rdr["Rate"].ToString()



                    };
                    shareAllocations.Add(shareAllocation);


                }

                connection.Close();
            }

            return Json(shareAllocations, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getCompanyPerfomance(string company)
        {


            var sql = "SELECT top 1  * FROM [CDS_ROUTER].[dbo].[tbl_security_perfomance] where company = '" + company + "' order by id desc ";

            var shareAllocations = new List<Perfomance>();

            using (SqlConnection connection = new SqlConnection(finsec))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    Perfomance shareAllocation = new Perfomance()
                    {

                        company = rdr["company"].ToString(),
                        one_week = rdr["one_week"].ToString(),
                        one_month = rdr["one_month"].ToString(),
                        three_months = rdr["three_months"].ToString(),
                        ytd = rdr["ytd"].ToString(),
                        one_year = rdr["one_year"].ToString(),
                        three_years = rdr["three_years"].ToString(),
                        five_years = rdr["five_years"].ToString(),
                        one_w_high_low = rdr["one_w_high_low"].ToString(),
                        one_m_high_low = rdr["one_m_high_low"].ToString(),
                        six_w_high_low = rdr["six_w_high_low"].ToString(),
                        six_m_high_low = rdr["six_m_high_low"].ToString(),
                        high_ytd_ = rdr["high_ytd_"].ToString(),
                        low_ytd_ = rdr["low_ytd_"].ToString(),
                        ftwo_high = rdr["ftwo_high"].ToString(),
                        ftwo_low = rdr["ftwo_low"].ToString(),
                        avg_p_one_w = rdr["avg_p_one_w"].ToString(),
                        avg_p_one_m = rdr["avg_p_one_m"].ToString(),
                        avg_p_six_m = rdr["avg_p_six_m"].ToString(),
                        avg_p_one_y = rdr["avg_p_one_y"].ToString(),
                        avg_v_one_w = rdr["avg_v_one_w"].ToString(),
                        avg_v_one_m = rdr["avg_v_one_m"].ToString(),
                        avg_v_six_m = rdr["avg_v_six_m"].ToString(),
                        avg_v_one_y = rdr["avg_v_one_y"].ToString(),
                        volatality_three_w = rdr["volatality_three_w"].ToString(),
                        volatality_one_m = rdr["volatality_one_m"].ToString(),
                        volatality_six_m = rdr["volatality_six_m"].ToString(),
                        volatality_one_y = rdr["volatality_one_y"].ToString(),
                        captured_date = DateTime.Parse(rdr["captured_date"].ToString()).ToString("dd MMM yyyy"),



                    };
                    shareAllocations.Add(shareAllocation);


                }

                connection.Close();
            }

            return Json(shareAllocations, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getCompanyPerfomanceFeeds(string company)
        {


            var sql = "SELECT * FROM [CDS_ROUTER].[dbo].[company_feeds] where company = '" + company + "'";

            var shareAllocations = new List<PerformanceFeed>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    PerformanceFeed shareAllocation = new PerformanceFeed()
                    {
                        title = rdr["title"].ToString(),
                        message = rdr["message_"].ToString(),
                        date_created = DateTime.Parse(rdr["date_posted"].ToString()).ToString("dd MMM yyyy")



                    };
                    shareAllocations.Add(shareAllocation);


                }

                connection.Close();
            }

            return Json(shareAllocations, JsonRequestBehavior.AllowGet);
        }


        public JsonResult getAllMarketDataDetails(string exchange)
        {


            var sql = "SELECT [DateCaptured] , [SecurityType] ,indexpercentage,TurnOverZWL,TurnOverUSD  ,[MarkertPercentageIncr_DecreZWL], [MarkertPercentageIncr_DecreUSD],[TurnOverPercentageIncrease_DecrZWL],[TurnOverPercentageIncrease_DecrUSD],[MarkertCapZWL] ,[MarkertCapUSD],[Index]  ,[VolumeTrade],[SecuritySubType] ,[OMIR] ,[BlackMarketZWL] ,[BlackMarketUSD] ,[PriceUSD]  ,[PriceZWL]  ,[Rate] FROM [CDS].[dbo].[MarkertData] where convert(date, DateCaptured )>= DATEADD(day,-30, getdate())  and   SecuritySubType =  '" + exchange + "' ";

            var shareAllocations = new List<marketData>();

            using (SqlConnection connection = new SqlConnection(finsec))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    marketData shareAllocation = new marketData
                    {


                        MarkertPercentageIncr_DecreZWL = rdr["MarkertPercentageIncr_DecreZWL"].ToString(),
                        turnoverZWL = rdr["TurnOverZWL"].ToString(),
                        turnoverUSD = rdr["TurnOverUSD"].ToString(),
                        MarkertPercentageIncr_DecreUSD = rdr["MarkertPercentageIncr_DecreUSD"].ToString(),

                        TurnOverPercentageIncrease_DecrZWL = rdr["TurnOverPercentageIncrease_DecrZWL"].ToString(),

                        TurnOverPercentageIncrease_DecrUSD = rdr["TurnOverPercentageIncrease_DecrUSD"].ToString(),

                        DateCaptured = DateTime.Parse(rdr["DateCaptured"].ToString()).ToString("dd MMM yyyy"),
                        SecurityType = rdr["SecurityType"].ToString(),

                        indexpercentage = rdr["indexpercentage"].ToString(),
                        MarkertCapZWL = rdr["MarkertCapZWL"].ToString(),
                        MarkertCapUSD = rdr["MarkertCapUSD"].ToString(),


                        Index = rdr["Index"].ToString(),



                        VolumeTrade = rdr["VolumeTrade"].ToString(),

                        SecuritySubType = rdr["SecuritySubType"].ToString(),
                        OMIR = rdr["OMIR"].ToString(),
                        BlackMarketZWL = rdr["BlackMarketZWL"].ToString(),

                        BlackMarketUSD = rdr["BlackMarketUSD"].ToString(),

                        PriceUSD = rdr["PriceUSD"].ToString(),
                        PriceZWL = rdr["PriceZWL"].ToString(),
                        Rate = rdr["Rate"].ToString()



                    };
                    shareAllocations.Add(shareAllocation);


                }

                connection.Close();
            }

            return Json(shareAllocations, JsonRequestBehavior.AllowGet);
        }

        public JsonResult IssuerCompanies()
        {


            var sql = "select distinct(Company),id from para_company";

            var shareAllocations = new List<Companies>();

            using (SqlConnection connection = new SqlConnection(escrowshare))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    Companies shareAllocation = new Companies()
                    {

                        id = Convert.ToInt16(rdr["id"].ToString()),
                        Company = rdr["Company"].ToString()


                    };
                    shareAllocations.Add(shareAllocation);


                }

                connection.Close();
            }

            return Json(shareAllocations, JsonRequestBehavior.AllowGet);
        }
        public JsonResult equityData(string company)
        {


            var sql = "SELECT * FROM [CDS_ROUTER].[dbo].[EquityData] where Company = '" + company + "' AND CapturedDate > DATEADD(DAY,-30,CONVERT(date,getdate()))";

            var shareAllocations = new List<EquityAnalysisData>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    EquityAnalysisData shareAllocation = new EquityAnalysisData()
                    {


                        company = rdr["Company"].ToString(),
                        ex = rdr["Exchange"].ToString(),
                        hstP = rdr["HighestPrice"].ToString(),
                        lstP = rdr["LowestPrice"].ToString(),
                        oP = rdr["OpeningPrice"].ToString(),
                        cP = rdr["ClosingPrice"].ToString(),
                        date = DateTime.Parse(rdr["CapturedDate"].ToString())
                    };
                    shareAllocations.Add(shareAllocation);


                }

                connection.Close();
            }

            return Json(shareAllocations, JsonRequestBehavior.AllowGet);
        }

        public JsonResult getIssuerDetails(string email)
        {

            var sql = "SELECT [email],[designation] ,[company] FROM [CDS_ROUTER].[dbo].[issuer_client] where email=  '" + email + "'";

            var suserTrans = new List<IssuerData>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {

                    IssuerData shareAllocation = new IssuerData()
                    {
                        Email = rdr["Email"].ToString(),
                        designation = rdr["designation"].ToString(),
                        company = rdr["company"].ToString()


                    };
                    suserTrans.Add(shareAllocation);


                }

                connection.Close();
            }



            return Json(suserTrans, JsonRequestBehavior.AllowGet);
        }

        public JsonResult getHolders(string company, DateTime asAt, string top = "10")
        {
            var sql = "SELECT TOP " + top + " shareholder, name, SUM(tot_shares) AS tot_shares,add_1,add_2,add_3,add_4,add_5 FROM top_table WHERE top_table.company = '" + company + "' AND top_table.date <= '" + asAt + "' AND shareholder NOT IN (SELECT cds_ac_no FROM para_company WHERE company = '" + company + "') GROUP BY shareholder, name,add_1,add_2,add_3,add_4,add_5 ORDER BY tot_shares DESC";
            var shareAllocations = new List<Holders>();

            using (SqlConnection connection = new SqlConnection(escrowshare))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    Holders shareAllocation = new Holders()
                    {
                        numberOfShares = rdr["tot_shares"].ToString(),
                        fullname = rdr["name"].ToString(),
                        shareholder = rdr["shareholder"].ToString(),

                    };
                    shareAllocations.Add(shareAllocation);
                }
                connection.Close();
            }
            return Json(shareAllocations, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getRegister(String company, DateTime asAt)
        {
            var sql = "SELECT TOP 100 PERCENT dbo.trans.company, dbo.trans.shareholder, ltrim(dbo.names.forenames + ' ' + dbo.names.surname) AS Name, dbo.names.short, dbo.names.country, dbo.names.Industry, dbo.names.tax, SUM(dbo.trans.shares) AS totalshares, dbo.names.add_1, dbo.names.add_2, dbo.names.add_3, dbo.names.add_4, dbo.names.add_5 FROM dbo.trans INNER JOIN dbo.names ON dbo.trans.shareholder = dbo.names.shareholder WHERE (dbo.trans.company = '" + company + "') and (dbo.trans.shareholder=dbo.names.shareholder) AND (dbo.trans.date <= '" + asAt + "') AND (dbo.trans.shareholder NOT IN (SELECT cds_ac_no FROM para_company WHERE company = '" + company + "')) GROUP BY dbo.trans.company, dbo.trans.shareholder, dbo.names.forenames, dbo.names.surname, dbo.names.short, dbo.names.country, dbo.names.Industry, dbo.names.tax, dbo.names.add_1, dbo.names.add_2, dbo.names.add_3, dbo.names.add_4, dbo.names.add_5 HAVING (SUM(dbo.trans.shares) > 0) AND (dbo.trans.shareholder NOT IN (SELECT cds_ac_no FROM para_company WHERE company = '" + company + "')) ORDER BY dbo.names.surname";

            var shareAllocations = new List<Registerkshares>();

            using (SqlConnection connection = new SqlConnection(escrowshare))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    Registerkshares shareAllocation = new Registerkshares()
                    {
                        company = rdr["company"].ToString(),
                        fullname = rdr["Name"].ToString(),
                        shareholder = rdr["shareholder"].ToString(),
                        numberOfShares = rdr["totalshares"].ToString(),
                        tax = rdr["tax"].ToString(),
                        Industry = rdr["Industry"].ToString(),
                        country = rdr["country"].ToString(),



                    };
                    shareAllocations.Add(shareAllocation);


                }

                connection.Close();
            }
            return Json(shareAllocations, JsonRequestBehavior.AllowGet);
        }

        public JsonResult sharePrice(string company)
        {


            var sql = "select PricePerShare ,CONVERT(date,DateToday) DateToday from [dbo].[PortFolio]  where   CONVERT(date,DateToday)>=DATEADD(day, -40, getdate()) and Company='" + company + "'";

            var shareAllocations = new List<CompanyPrice>();

            using (SqlConnection connection = new SqlConnection(escrowshare))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    CompanyPrice shareAllocation = new CompanyPrice()
                    {

                        PricePerShare = Convert.ToDecimal(rdr["PricePerShare"].ToString()),
                        DateToday = rdr["DateToday"].ToString()


                    };
                    shareAllocations.Add(shareAllocation);


                }

                connection.Close();
            }

            return Json(shareAllocations, JsonRequestBehavior.AllowGet);
        }


        public JsonResult shareDividends(string company)
        {


            var sql = "select top 10 div_no,company,div_no,div_type,date_declared,date_closed,rate,date_payment   from [dbo].[div_instr] where  company = '" + company + "'  order by id desc ";

            var shareAllocations = new List<Dividends>();

            using (SqlConnection connection = new SqlConnection(escrowshare))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    Dividends shareAllocation = new Dividends()
                    {

                        rate = Convert.ToDecimal(rdr["rate"].ToString()),
                        div_no = rdr["div_no"].ToString(),
                        div_type = rdr["div_type"].ToString(),
                        company = rdr["company"].ToString(),
                        date_declared = DateTime.Parse(rdr["date_declared"].ToString()).ToString("dd MMM yyyy"),
                        date_closed = DateTime.Parse(rdr["date_closed"].ToString()).ToString("dd MMM yyyy"),
                        date_payment = DateTime.Parse(rdr["date_payment"].ToString()).ToString("dd MMM yyyy")


                    };
                    shareAllocations.Add(shareAllocation);


                }

                connection.Close();
            }

            return Json(shareAllocations, JsonRequestBehavior.AllowGet);
        }

        public JsonResult getGroupShareholdings(string cds_number, string group_cds_number)
        {


            var sql = "select  I.cds_number, I.groupid, I.company,sum(i.shares) as Mine, (select sum(shares) from trans_groups where company=i.company and groupid='" + group_cds_number + "') as [GroupTotal],sum(i.shares)/(select sum(shares) from trans_groups where company=i.company and groupid='" + group_cds_number + "')*100 as [MyPercentage]  from trans_groups i where i.cds_number='" + cds_number + "' and i.groupid='" + group_cds_number + "'   group by i.company, i.groupid, i.cds_number ";

            var shareAllocations = new List<ShareAllocation>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    ShareAllocation shareAllocation = new ShareAllocation
                    {
                        MyPercentage = rdr["MyPercentage"].ToString(),
                        GroupTotal = rdr["GroupTotal"].ToString(),
                        Mine = rdr["Mine"].ToString(),
                        Company = rdr["company"].ToString()


                    };
                    shareAllocations.Add(shareAllocation);


                }

                connection.Close();
            }

            return Json(shareAllocations, JsonRequestBehavior.AllowGet);
        }


        public JsonResult Holdings(string groupid, string company)
        {

            //var sql = "select cds_number,company ,sum(shares) as [TotalShares] from cds_router.dbo.trans_groups where groupid='"+ groupid + "' and company=' "+ company + "' group by cds_number, company";
            var sql = "select Company,aw.CDS_Number,aw.Mobile,concat(Forenames,' ',Surname) as fullname,sum(shares)  as [TotalShares] from cds_router.dbo.trans_Groups tg left join cds_router.dbo.accounts_clients_web aw on aw.CDS_Number = tg.CDS_Number where GroupID = '"+groupid+"' and company='"+company+"' group by Forenames,Surname,aw.CDS_Number,aw.Mobile,Company";

            var suserTrans = new List<Holdings>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Holdings shareAllocation = new Holdings
                    {
                        cds_number = rdr["CDS_Number"].ToString(),
                        shares = rdr["TotalShares"].ToString(),
                        company = rdr["Company"].ToString(),
                        fullName = rdr["fullname"].ToString(),
                        mobile = rdr["Mobile"].ToString()
                    };
                    suserTrans.Add(shareAllocation);


                }

                connection.Close();
            }



            return Json(suserTrans, JsonRequestBehavior.AllowGet);
        }

        public JsonResult HoldingsDrillDown(string groupid, string company, string cdsnumber)
        {


            var sql = "select company, shares,cds_number,Date_Created from cds_router.dbo.trans_groups where cds_number ='" + cdsnumber + "' and company = '" + company + "' and groupid = '" + groupid + "'";

            var suserTrans = new List<HoldingsDriillDown>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {

                    HoldingsDriillDown shareAllocation = new HoldingsDriillDown
                    {
                        cds_number = rdr["cds_number"].ToString(),
                        shares = rdr["shares"].ToString(),
                        company = rdr["company"].ToString(),
                        Date_Created = DateTime.Parse(rdr["Date_Created"].ToString()).ToString("dd MMM yyyy")




                    };
                    suserTrans.Add(shareAllocation);


                }

                connection.Close();
            }



            return Json(suserTrans, JsonRequestBehavior.AllowGet);
        }
        public JsonResult CashTranGroup(string cdsNumber)
        {

            var sql = " select A.Email, A.FullName,A.CdsNumber,C.Amount ,C.DateCreated, C.TransType from CDSC.dbo.Vatenkecis A JOIN CDSC.dbo.CashTransGroups C ON A.CdsNumber=C.CDS_Number WHERE C.CDS_NumberGroup='" + cdsNumber + "'";

            var suserTrans = new List<CashListTransGroup>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {

                    CashListTransGroup shareAllocation = new CashListTransGroup
                    {
                        Email = rdr["Email"].ToString(),
                        FullName = rdr["FullName"].ToString(),
                        TransType = rdr["TransType"].ToString(),
                        Amount = rdr["Amount"].ToString(),
                        CdsNumber = rdr["CdsNumber"].ToString(),
                        DateCreated = rdr["DateCreated"].ToString()


                    };
                    suserTrans.Add(shareAllocation);


                }

                connection.Close();
            }



            return Json(suserTrans, JsonRequestBehavior.AllowGet);
        }


        public JsonResult MyCashTranGroup(string cdsNumber, string groupcdsNumber)
        {

            var sql = " select A.Email, A.FullName,A.CdsNumber,C.Amount ,C.DateCreated, C.TransType from CDSC.dbo.Vatenkecis A JOIN CDSC.dbo.CashTransGroups C ON A.CdsNumber=C.CDS_Number WHERE C.CDS_NumberGroup='" + groupcdsNumber + "' and C.CDS_Number= '" + cdsNumber + "'";

            var suserTrans = new List<CashListTransGroup>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {

                    CashListTransGroup shareAllocation = new CashListTransGroup
                    {
                        Email = rdr["Email"].ToString(),
                        FullName = rdr["FullName"].ToString(),
                        TransType = rdr["TransType"].ToString(),
                        Amount = rdr["Amount"].ToString(),
                        CdsNumber = rdr["CdsNumber"].ToString(),
                        DateCreated = rdr["DateCreated"].ToString()


                    };
                    suserTrans.Add(shareAllocation);


                }

                connection.Close();
            }



            return Json(suserTrans, JsonRequestBehavior.AllowGet);
        }

        public JsonResult ClublistMembersWithEmail(int clubid)
        {
            // var sql = " select [CDSC].[dbo].club_members.* , [CDSC].[dbo].Vatenkecis.FullName from [CDSC].[dbo].club_members left join  [CDSC].[dbo].Vatenkecis on [CDSC].[dbo].Vatenkecis.Email=club_members.member_email  where   club_members.club_id='" + clubid + "'";
            var sql = "select *,(SELECT top 1 concat(Forenames,' ',Surname) FROM [CDS_ROUTER].[dbo].[Accounts_Clients] where CDS_Number = C.member_cds_number) as FullName from [CDSC].[dbo].club_members c where club_id = '" + clubid + "' and c.Active = 1 and c.confirmed = 1";
            var suserTrans = new List<ClubMembers>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {

                    ClubMembers shareAllocation = new ClubMembers
                    {
                        id = Convert.ToInt16(rdr["id"].ToString()),
                        club_phone = rdr["club_phone"].ToString(),
                        FullName = rdr["FullName"].ToString(),
                        confirmed = Convert.ToBoolean(rdr["confirmed"].ToString()),
                        rejected = Convert.ToBoolean(rdr["rejected"].ToString()),
                        member_cds_number = rdr["member_cds_number"].ToString(),
                        member_phone = rdr["member_phone"].ToString(),
                        member_email = rdr["member_email"].ToString(),
                        Surname = rdr["Surname"].ToString(),
                        cdsnumber = rdr["cdsnumber"].ToString(),
                        Firstname = rdr["Firstname"].ToString(),
                        created_date = DateTime.Parse(rdr["created_date"].ToString()).ToString("dd MMM yyyy")



                    };
                    suserTrans.Add(shareAllocation);


                }

                connection.Close();
            }
            return Json(suserTrans, JsonRequestBehavior.AllowGet);

        }



        public JsonResult getAllCreatedclubs(string clubname = null)
        {
            // var sql = " select [CDSC].[dbo].club_members.* , [CDSC].[dbo].Vatenkecis.FullName from [CDSC].[dbo].club_members left join  [CDSC].[dbo].Vatenkecis on [CDSC].[dbo].Vatenkecis.Email=club_members.member_email  where   club_members.club_id='" + clubid + "'";
            var sql = "SELECT  [id],[chairman_id] ,[club_member_num] ,[club_name] ,[club_phone],[created_date],[phone] ,[Active],[club_cds_number] FROM [CDSC].[dbo].[investment_club] where active =1 and club_name like '" + clubname + "'";
            var suserTrans = new List<ClubMembers>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {

                    ClubMembers shareAllocation = new ClubMembers
                    {
                        id = Convert.ToInt16(rdr["id"].ToString()),
                        club_phone = rdr["club_phone"].ToString(),
                        FullName = rdr["FullName"].ToString(),
                        confirmed = Convert.ToBoolean(rdr["confirmed"].ToString()),
                        rejected = Convert.ToBoolean(rdr["rejected"].ToString()),
                        member_cds_number = rdr["member_cds_number"].ToString(),
                        member_phone = rdr["member_phone"].ToString(),
                        member_email = rdr["member_email"].ToString(),
                        Surname = rdr["Surname"].ToString(),
                        cdsnumber = rdr["cdsnumber"].ToString(),
                        Firstname = rdr["Firstname"].ToString(),
                        created_date = DateTime.Parse(rdr["created_date"].ToString()).ToString("dd MMM yyyy")



                    };
                    suserTrans.Add(shareAllocation);


                }

                connection.Close();
            }
            return Json(suserTrans, JsonRequestBehavior.AllowGet);

        }



        public JsonResult getMemberphoneNo(string emeail)
        {
            // var sql = " select [CDSC].[dbo].club_members.* , [CDSC].[dbo].Vatenkecis.FullName from [CDSC].[dbo].club_members left join  [CDSC].[dbo].Vatenkecis on [CDSC].[dbo].Vatenkecis.Email=club_members.member_email  where   club_members.club_id='" + clubid + "'";
            var sql = "select CDS_Number,mobile_number from Accounts_Clients_Web where Email ='" + emeail + "'";
            var suserTrans = new List<memberAccWebDetails>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {

                    memberAccWebDetails shareAllocation = new memberAccWebDetails
                    {
                        CDS_Number = rdr["CDS_Number"].ToString(),
                        phoneNo = rdr["mobile_number"].ToString(),

                    };
                    suserTrans.Add(shareAllocation);


                }

                connection.Close();
            }
            return Json(suserTrans, JsonRequestBehavior.AllowGet);

        }

        public JsonResult sendNotificationToGroup(String CDS_NumberGroup,String mcdsnumber, String notification, String id = null)
        {
            var tempDbContext = new cdscDbContext();
            var message = "";


            if (id != null)
            {

                long n_id = long.Parse(id);
                NotificationGroup notificationGroup = tempDbContext.NotificationGroup.Single(b => b.ID == n_id);


                notificationGroup.Notification = notification;
                tempDbContext.NotificationGroup.AddOrUpdate(notificationGroup);
                tempDbContext.SaveChanges();
                message = "Edited Successfully";
                recordClubActivity(CDS_NumberGroup, "f");
            }
            else
            {
                NotificationGroup notificationGroup = new NotificationGroup
                {
                    Notification = notification,
                    CDS_NumberGroup = CDS_NumberGroup,
                    DateCreated = DateTime.Now,
                    CDS_Number = mcdsnumber

                };
                message = "notification Added Successfully";
                tempDbContext.NotificationGroup.Add(notificationGroup);
                tempDbContext.SaveChanges();
                recordClubActivity(CDS_NumberGroup, "f");
            }
            return Json(message, JsonRequestBehavior.AllowGet);

        }

        public JsonResult deleteNotificationToGroup(String id)
        {
            var tempDbContext = new cdscDbContext();
            long n_id = long.Parse(id);
            NotificationGroup notificationGroup = tempDbContext.NotificationGroup.Single(b => b.ID == n_id);
            tempDbContext.NotificationGroup.Remove(notificationGroup);
            tempDbContext.SaveChanges();

            return Json("deleted  Successfully", JsonRequestBehavior.AllowGet);
        }



        public JsonResult getNotificationToGroup(String CDS_NumberGroup,string mcdsnumber)
        {
            var tempDbContext = new cdscDbContext();
            var notifications = new List<NotificationGroupReturn>();
            var sql = "SELECT ng.ID,CDS_NumberGroup,ng.DateCreated,ng.Notification,concat(Forenames,' ',Surname) as names  FROM[CDSC].[dbo].[NotificationGroups] ng  left join CDS_ROUTER.dbo.Accounts_Clients_Web aw on aw.CDS_Number = ng.CDS_Number where CDS_NumberGroup= '" + CDS_NumberGroup+"'";


            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    NotificationGroupReturn notificationGroup = new NotificationGroupReturn
                    {
                        ID = long.Parse(rdr["ID"].ToString()),
                        Notification = rdr["Notification"].ToString(),
                        CDS_NumberGroup = rdr["CDS_NumberGroup"].ToString(),
                        DateCreated = DateTime.Parse(rdr["DateCreated"].ToString()).ToString("dd MMM yyyy"),
                        names = rdr["names"].ToString()

                    };
                    notifications.Add(notificationGroup);


                }

                connection.Close();
            }
            recordActivityViewed(CDS_NumberGroup, mcdsnumber,"f");
            return Json(notifications, JsonRequestBehavior.AllowGet);

        }



        long LongRandom(long min, long max, Random rand)
        {
            byte[] buf = new byte[8];
            rand.NextBytes(buf);
            long longRand = BitConverter.ToInt64(buf, 0);
            return (Math.Abs(longRand % (max - min)) + min);
        }

        public static string EncryptIt(string theText)
        {
            int i = theText.Length;
            string theEncrypteOne = "";

            int j;
            for (j = 0; j < i; j++)
                theEncrypteOne += Strings.ChrW((Strings.AscW(theText.Substring(j, 1)) - 10));
            string EncryptIt = theEncrypteOne;
            return EncryptIt;
        }

        public JsonResult VatenkeciLoginSecure(string idNumber, string pass)
        {
            var cdDataContexts = new cdscDbContext();

            string encryptedPassword = EncryptIt(pass.Trim());

            var usernameFound = cdDataContexts.Vatenkecis.FirstOrDefault(x => (x.Username.Trim() == idNumber.Trim() || x.CdsNumber.Trim() == idNumber.Trim()) && x.Password == encryptedPassword);

            if (usernameFound != null)
            {
                if (usernameFound.Active == false)
                {
                    return Json(8, JsonRequestBehavior.AllowGet);
                }
                //                return Json("2", JsonRequestBehavior.AllowGet);
                var user = _cdDataContext.Accounts_Clients.FirstOrDefault(x => (x.CDS_Number.Trim() == usernameFound.CdsNumber.Trim()));
                if (user != null)
                {
                    Random generator = new Random();
                    string GenerateRandomNo = generator.Next(1, 10000).ToString("D4");
                    string getstatus_ = testAccountinJoint(idNumber);
                    var rets =
                        _cdDataContext.Accounts_Clients.Where(x => (x.CDS_Number.Trim() == usernameFound.CdsNumber.Trim()))
                            .OrderByDescending(x => x.ID)
                            .Select(c => new
                            {
                                id = c.CDS_Number,
                                brokerName = c.Custodian,
                                broker = c.BrokerCode,
                                cds = c.CDS_Number,
                                email = usernameFound.Email,
                                name = c.Surname + " " + c.Forenames,
                                phone = c.Mobile,
                                pin = GenerateRandomNo,
                                has_company = getstatus_
                            });

                    String sqlx = "";
                    foreach (var p in rets)
                    {

                        var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                        sqlx = "Update Vatenkecis set PIN ='" + GenerateRandomNo + "' where CdsNumber='" + p.cds.ToString() + "' ";
                        using (SqlConnection connectionsx = new SqlConnection(connectionString))
                        {
                            SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                            connectionsx.Open();
                            cmd.CommandType = CommandType.Text;
                            cmd.ExecuteNonQuery();

                        }
                        //connectionsx.Close();
                        break;
                    }
                    try
                    {
                        SmtpClient client = new SmtpClient();
                        client.Port = 587;
                        client.Host = "smtp.gmail.com";
                        client.EnableSsl = true;
                        ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                        client.Timeout = 30000;
                        client.DeliveryMethod = SmtpDeliveryMethod.Network;
                        client.UseDefaultCredentials = false;
                        //client.Credentials = new System.Net.NetworkCredential("mobilectrade@gmail.com", "asdfghjkl2017");
                        client.Credentials = new System.Net.NetworkCredential("no-reply@ctrade.co.zw", "asdfghjkl2018");
                        MailMessage mm = new MailMessage();
                        mm.BodyEncoding = Encoding.UTF8;
                        mm.From = new MailAddress("no-reply@ctrade.co.zw");
                        mm.To.Add(user.Email);
                        mm.Subject = "C-TRADE Mobile OTP";
                        mm.Body = GenerateRandomNo;
                        mm.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;

                        client.Send(mm);
                        return Json(rets, JsonRequestBehavior.AllowGet);
                    }
                    catch (Exception e)
                    {
                        return Json("Error sending OTP Please try again", JsonRequestBehavior.AllowGet);
                    }
                }
                return Json("No email in accounts creation", JsonRequestBehavior.AllowGet);
            }
            //1. Checking from Accounts_Creation
            return Json("No email in registrations", JsonRequestBehavior.AllowGet);
        }

        public string EncryptPasswords()
        {
            string result = "done";

            var sql = "select * from [CDSC].[dbo].[Vatenkecis]";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    string password = rdr["Password"].ToString();
                    int id = int.Parse(rdr["Id"].ToString());

                    string sqlx = "Update [CDSC].[dbo].[Vatenkecis] set Password = @password where id = @id";
                    using (SqlConnection connectionsx = new SqlConnection(connectionStringCDS_Router))
                    {
                        SqlCommand cmdU = new SqlCommand(sqlx, connectionsx)
                        {
                            CommandType = CommandType.Text
                        };
                        cmdU.Parameters.AddWithValue("@password", EncryptIt(password));
                        cmdU.Parameters.AddWithValue("@id", id);
                        cmdU.CommandTimeout = 0;
                        connectionsx.Open();
                        cmdU.ExecuteNonQuery();
                        connectionsx.Close();

                    }
                }

                connection.Close();
            }

            return result;
        }

        public string PostAmmendOrder(string ordernumber, string nprice = null, string nquantity = null)

        {

            var today = DateTime.Today.ToString("yyyy-MM-dd");

            try
            {
                var list = new List<Pre_Order_Live>();
                Pre_Order_Live orderLiveObj = new Pre_Order_Live();
                int orderNo = int.Parse(ordernumber);

                var sql =
                    "select * FROM [testcds_ROUTER].[dbo].[Pre_Order_Live] where orderNo = '" + ordernumber + "'";

                using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {

                        orderLiveObj.Company = rdr["Company"].ToString();
                        orderLiveObj.OrderType = rdr["OrderType"].ToString();
                        orderLiveObj.CDS_AC_No = rdr["CDS_AC_No"].ToString();
                        orderLiveObj.Broker_Code = rdr["Broker_Code"].ToString();
                        orderLiveObj.BrokerRef = rdr["BrokerRef"].ToString();
                        orderLiveObj.OrderStatus = rdr["OrderStatus"].ToString();
                        orderLiveObj.OrderNumber = rdr["OrderNumber"].ToString();
                        orderLiveObj.Quantity = int.Parse(rdr["Quantity"].ToString());
                        orderLiveObj.BasePrice = Math.Round(double.Parse(rdr["BasePrice"].ToString()), 4);
                        list.Add(orderLiveObj);
                    }
                }


                if (list.Any())
                {
                    int? ammendQuantity;
                    double? ammendPrice;
                    string returnstring;

                    //Get order quantity and price
                    double? oldQuantity = orderLiveObj.Quantity;
                    double? oldPrice = orderLiveObj.BasePrice;

                    //Check if price has been ammended, if not take old
                    if (string.IsNullOrEmpty(nprice))
                    {
                        ammendPrice = oldPrice;
                    }
                    else
                    {
                        ammendPrice = double.Parse(nprice);
                    }

                    //Check if quantity has been ammended, if not take old
                    if (string.IsNullOrEmpty(nquantity))
                    {
                        ammendQuantity =Convert.ToInt32 (oldQuantity);
                    }
                    else
                    {
                        ammendQuantity = int.Parse(nquantity);
                    }

                    string sqlx = "insert into CDS_ROUTER.dbo.Orders_Amendments(OrderType, Amount, Notes, CdsNumber, BrokerCode, Company, Price, OrderRef, MatchedQty, MatchedPrice, Status, Sent, Date, PhoneNumber, LPStatus, Custodian, Oldbrokerid, Oldexchangeid) values('" + orderLiveObj.OrderType + "', '" + ammendQuantity + "', '" + ammendQuantity + "', '" + orderLiveObj.CDS_AC_No + "', '" + orderLiveObj.Broker_Code + "', '" + orderLiveObj.Company + "', '" + ammendPrice + "', '" + orderLiveObj.OrderNumber + "', 0, 0, '" + orderLiveObj.OrderStatus + "', 0, GETDATE(), '" + orderLiveObj.CDS_AC_No + "', '" + orderLiveObj.OrderStatus + "', '" + orderLiveObj.Broker_Code + "', '" + orderLiveObj.Broker_Code + "', '" + orderLiveObj.BrokerRef + "')";

                    using (SqlConnection connectionsx = new SqlConnection(connectionStringATS))
                    {
                        SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                        connectionsx.Open();
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                        returnstring = "Order ammendment request successfully sent.";

                    }
                    return returnstring;
                }
                else
                {
                    return "Order does not exist.";
                }



            }
            catch (Exception ex)
            {
                //return "Error occured please contact support at ctrade@escrowgroup.org";
                return ex.ToString();
            }
        }

        //deleteOrder
        public string DeleteOrder(string cdsnumber, string ordernumber)
        {
            string returnstring = "";
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            string sqlx = "Delete from Pre_Order_Live  where OrderNo ='" + ordernumber
                + "' and CDS_AC_No='" + cdsnumber + "' ";

            using (SqlConnection connectionsx = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                connectionsx.Open();
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                returnstring = "Successfully removed";

            }
            return returnstring;
        }

        public JsonResult CheckWhoRegisteredCtrade(string any)
        {
            var rets = _cdDataContext.Accounts_Clients.FirstOrDefault(x => x.Email.Trim() == any || x.CDS_Number == any.Trim());

            var mobAccount = _cdscDbContext.Vatenkecis.FirstOrDefault(x => x.Email == any.Trim() || x.CdsNumber == any.Trim());
            if (mobAccount != null)
            {
                if (mobAccount.Active == false)
                {
                    return Json(4, JsonRequestBehavior.AllowGet);//Account not active
                }
                else
                {
                    if (rets != null)
                    {
                        return Json(1, JsonRequestBehavior.AllowGet);//its in cds and not in ctrade
                    }
                    else
                    {
                        if (mobAccount.FullName == null || mobAccount.FullName == "individual")
                        {
                            return Json(3, JsonRequestBehavior.AllowGet);//is company
                        }
                        else
                        {

                            return Json(1, JsonRequestBehavior.AllowGet);//its in  ctrade only

                        }

                    }
                }
            }
            else if (rets != null)
            {
                return Json(2, JsonRequestBehavior.AllowGet);//its in cds and not in ctrade
            }
            else
            {
                //create new account
                return Json(0, JsonRequestBehavior.AllowGet);//its not in either so create
            }

        }

        public JsonResult InvestorRegTest(string idNumber, string pass)
        {
            //            return 
            //            return Json(idNumber + "  " + pass, JsonRequestBehavior.AllowGet);
            //            x => x.Username.Trim() == "rfde@gmail.com" && x.Password.Trim() == "12341234"
            string encryptedPassword = EncryptIt(pass.Trim());

            var cdDataContexts = new cdscDbContext();
            var usernameFound = cdDataContexts.Vatenkecis.FirstOrDefault(x => (x.Username.Trim() == idNumber.Trim() || x.CdsNumber.Trim() == idNumber.Trim()) && x.Password == encryptedPassword);

            if (usernameFound != null)
            {
                if (usernameFound.Active == false)
                {
                    return Json(8, JsonRequestBehavior.AllowGet);
                }
                //                return Json("2", JsonRequestBehavior.AllowGet);
                var user = _cdDataContext.Accounts_Clients.FirstOrDefault(x => (x.CDS_Number.Trim() == usernameFound.CdsNumber.Trim()));
                if (user != null)
                {
                    Random generator = new Random();
                    string GenerateRandomNo = generator.Next(1, 10000).ToString("D4");
                    string getstatus_ = testAccountinJoint(idNumber);
                    var rets =
                        _cdDataContext.Accounts_Clients.Where(x => (x.CDS_Number.Trim() == usernameFound.CdsNumber.Trim()))
                            .OrderByDescending(x => x.ID)
                            .Select(c => new
                            {
                                id = c.CDS_Number,
                                brokerName = c.Custodian,
                                broker = c.BrokerCode,
                                cds = c.CDS_Number,
                                email = usernameFound.Email,
                                name = c.Surname + " " + c.Forenames,
                                phone = c.Mobile,
                                pin = GenerateRandomNo,
                                has_company = getstatus_
                            });

                    String sqlx = "";
                    foreach (var p in rets)
                    {

                        var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                        sqlx = "Update Vatenkecis set PIN ='" + GenerateRandomNo + "' where CdsNumber='" + p.cds.ToString() + "' ";
                        using (SqlConnection connectionsx = new SqlConnection(connectionString))
                        {
                            SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                            connectionsx.Open();
                            cmd.CommandType = CommandType.Text;
                            cmd.ExecuteNonQuery();

                        }
                        //connectionsx.Close();
                        break;
                    }
                    try
                    {
                        SmtpClient client = new SmtpClient();
                        client.Port = 587;
                        client.Host = "smtp.gmail.com";
                        client.EnableSsl = true;
                        ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                        client.Timeout = 30000;
                        client.DeliveryMethod = SmtpDeliveryMethod.Network;
                        client.UseDefaultCredentials = false;
                        //client.Credentials = new System.Net.NetworkCredential("mobilectrade@gmail.com", "asdfghjkl2017");
                        client.Credentials = new System.Net.NetworkCredential("no-reply@ctrade.co.zw", "asdfghjkl2018");
                        MailMessage mm = new MailMessage();
                        mm.BodyEncoding = Encoding.UTF8;
                        mm.From = new MailAddress("no-reply@ctrade.co.zw");
                        mm.To.Add(user.Email);
                        mm.Subject = "C-TRADE Mobile OTP";
                        mm.Body = GenerateRandomNo;
                        mm.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;

                        client.Send(mm);
                        return Json(rets, JsonRequestBehavior.AllowGet);
                    }
                    catch (Exception e)
                    {
                        return Json("Error sending OTP Please try again", JsonRequestBehavior.AllowGet);
                    }
                }
                return Json("No email in accounts creation", JsonRequestBehavior.AllowGet);
            }
            //1. Checking from Accounts_Creation
            return Json("No email in registrations", JsonRequestBehavior.AllowGet);
        }
        public JsonResult AuthUser(string idNumber, string pass)
        {
            string encryptedPassword = EncryptIt(pass.Trim());
            var cdDataContexts = new cdscDbContext();
            var usernameFound = cdDataContexts.Vatenkecis.FirstOrDefault(x => (x.Username.Trim() == idNumber.Trim() || x.CdsNumber.Trim() == idNumber.Trim()) && x.Password == encryptedPassword);

            if (usernameFound != null)
            {
                if (usernameFound.Active == false)
                {
                    return Json(8, JsonRequestBehavior.AllowGet);
                }
                //                return Json("2", JsonRequestBehavior.AllowGet);
                var user = _cdDataContext.Accounts_Clients.FirstOrDefault(x => (x.CDS_Number.Trim() == usernameFound.CdsNumber.Trim()));
                if (user != null)
                {
                    Random generator = new Random();
                    string GenerateRandomNo = generator.Next(1, 10000).ToString("D4");
                    string getstatus_ = testAccountinJoint(idNumber);
                    var rets =
                        _cdDataContext.Accounts_Clients.Where(x => (x.CDS_Number.Trim() == usernameFound.CdsNumber.Trim()))
                            .OrderByDescending(x => x.ID)
                            .Select(c => new
                            {
                                id = c.CDS_Number,
                                brokerName = c.Custodian,
                                broker = c.BrokerCode,
                                cds = c.CDS_Number,
                                email = usernameFound.Email,
                                name = c.Surname + " " + c.Forenames,
                                phone = c.Mobile,
                                pin = GenerateRandomNo,
                                has_company = getstatus_,
                                account_type = c.AccountType

                            });

                    return Json(rets, JsonRequestBehavior.AllowGet);

                }
                //1. Checking from Accounts_Creation
                return Json("No email in registrations", JsonRequestBehavior.AllowGet);
            }

            return Json(0, JsonRequestBehavior.AllowGet);
        }

        public JsonResult MarketWatchZSE()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcherZSE>();

            var sql =
                "SELECT * FROM ZSE_market_data";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatcherZSE recordSummary = new MarketWatcherZSE();
                    recordSummary.Ticker = rdr["Ticker"].ToString();
                    recordSummary.ISIN = rdr["ISIN"].ToString();
                    recordSummary.Best_Ask = rdr["Best_Ask"].ToString();
                    recordSummary.Best_bid = rdr["Best_bid"].ToString();
                    recordSummary.Current_price = rdr["Current_price"].ToString();
                    recordSummary.Ask_Volume = rdr["Ask_Volume"].ToString();
                    recordSummary.Bid_Volume = rdr["Bid_Volume"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetMarketData(string company)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<MarketData>();

            var sql =
                "select top 1 * from testcds_router.dbo.prices where company_name = '" + company + "' and price_turnover > 0";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketData recordSummary = new MarketData();
                    recordSummary.PriceID = int.Parse(rdr["PriceID"].ToString());
                    recordSummary.company_name = rdr["company_name"].ToString();
                    recordSummary.price_close = rdr["price_close"].ToString();
                    recordSummary.price_open = rdr["price_open"].ToString();
                    recordSummary.price_low = rdr["price_low"].ToString();
                    recordSummary.price_high = rdr["price_high"].ToString();
                    recordSummary.price_best = rdr["price_best"].ToString();
                    recordSummary.price_date = rdr["price_date"].ToString();
                    recordSummary.price_volume = rdr["price_volume"].ToString();
                    recordSummary.price_market_cap = rdr["price_market_cap"].ToString();
                    recordSummary.price_turnover = rdr["price_turnover"].ToString();
                    recordSummary.price_vwap = rdr["price_vwap"].ToString();
                    recordSummary.price_change = rdr["price_change"].ToString();
                    recordSummary.price_change_per = rdr["price_change_per"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult BUREAUPRICES(string company)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<Bureaus>();

            var sql =
                "SELECT BUREAU,CONVERT(varchar, DATE_UPDATED, 5) as 'date',max([SELLING]) as 'price',max([BUYING]) as 'price2' FROM [CDS_ROUTER].[dbo].[ForexMarketWatch] where BUREAU='" + company + "'  group by BUREAU,CONVERT(varchar, DATE_UPDATED, 5)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Bureaus recordSummary = new Bureaus();
                    recordSummary.Bureau = rdr["BUREAU"].ToString();
                    recordSummary.price = rdr["price"].ToString();
                    recordSummary.price2 = rdr["price2"].ToString();
                    recordSummary.date = rdr["date"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult MarketWatchZSENEW()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcherZSE>();

            //var sql = @"SELECT ut.*
            //            , qt.fnam
	           //         ,ISNULL((SELECT TOP 1 t.price_close FROM [testcds_ROUTER].[dbo].[Prices] t
            //            WHERE convert(DATE, t.price_date) = CONVERT(DATE, GETDATE() - 1)
            //            and t.[company_name] = ut.Ticker order by t.PriceID desc)
	           //         , ut.Current_price ) as PrevPrice
            //            FROM [CDS_ROUTER].[dbo].[ZSE_market_data] ut , testcds_ROUTER.dbo.para_company qt 
            //            WHERE ut.Ticker = qt.Company";

            var sql = @"SELECT ut.*
                        , qt.fnam
						, qt.description
	                    ,ISNULL((SELECT TOP 1 t.price_close FROM[testcds_ROUTER].[dbo].[Prices] t
                        WHERE convert(DATE, t.price_date) = CONVERT(DATE, GETDATE() - 1)
                        and t.[company_name] = ut.Ticker order by t.PriceID desc)
	                    , ut.Current_price ) as PrevPrice
                        FROM[CDS_ROUTER].[dbo].[ZSE_market_data] ut , testcds_ROUTER.dbo.para_company qt
                        WHERE ut.Ticker = qt.Company";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();


                while (rdr.Read())
                {


                    MarketWatcherZSE recordSummary = new MarketWatcherZSE();
                    var Price_change = Force4DecimalPlaces(Math.Round((double.Parse(rdr["PrevPrice"].ToString()) - double.Parse(rdr["Current_price"].ToString())), 4).ToString());
                    var Price_change_Per = "0.0000";
                    if (double.Parse(rdr["Current_price"].ToString()).Equals(0))
                    {
                        Price_change_Per = "0.0000";
                    }
                    else
                    {
                        Price_change_Per = Force4DecimalPlaces(Math.Round(
                                               (
                                               (double.Parse(rdr["PrevPrice"].ToString()) /
                                               double.Parse(rdr["Current_price"].ToString())) -
                                               double.Parse("1.0")
                                               ), 4).ToString());
                    }
                    recordSummary.Ticker = rdr["Ticker"].ToString();
                    recordSummary.ISIN = rdr["ISIN"].ToString();
                    recordSummary.Best_Ask = rdr["Best_Ask"].ToString();
                    recordSummary.Best_bid = rdr["Best_bid"].ToString();
                    recordSummary.Current_price = rdr["Current_price"].ToString();
                    recordSummary.Ask_Volume = rdr["Ask_Volume"].ToString();
                    recordSummary.Bid_Volume = rdr["Bid_Volume"].ToString();
                    recordSummary.FullCompanyName = rdr["fnam"].ToString();
                    recordSummary.Description = rdr["description"].ToString();
                    recordSummary.PrevPrice = rdr["PrevPrice"].ToString();
                    recordSummary.PrevChange = Price_change;
                    recordSummary.PrevPer = Price_change_Per;
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult MarketWatchZSECommodity()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcherZSE>();

            var sql = @"SELECT ut.*
                        , qt.fnam
	                    ,ISNULL((SELECT TOP 1 t.price_close FROM[testcds_ROUTER].[dbo].[Prices] t
                        WHERE convert(DATE, t.price_date) = CONVERT(DATE, GETDATE() - 1)
                        and t.[company_name] = ut.Ticker order by t.PriceID desc)
	                    , ut.Current_price ) as PrevPrice
                        FROM[CDS_ROUTER].[dbo].[ZSE_market_data] ut INNER JOIN  CDS_ROUTER.dbo.para_company qt on ut.Ticker=qt.ticker
                        WHERE qt.sec_type='GDR'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();


                while (rdr.Read())
                {


                    MarketWatcherZSE recordSummary = new MarketWatcherZSE();
                    var Price_change = Force4DecimalPlaces(Math.Round((double.Parse(rdr["PrevPrice"].ToString()) - double.Parse(rdr["Current_price"].ToString())), 4).ToString());
                    var Price_change_Per = "0.0000";
                    if (double.Parse(rdr["Current_price"].ToString()).Equals(0))
                    {
                        Price_change_Per = "0.0000";
                    }
                    else
                    {
                        Price_change_Per = Force4DecimalPlaces(Math.Round(
                                               (
                                               (double.Parse(rdr["PrevPrice"].ToString()) /
                                               double.Parse(rdr["Current_price"].ToString())) -
                                               double.Parse("1.0")
                                               ), 4).ToString());
                    }
                    recordSummary.Ticker = rdr["Ticker"].ToString();
                    recordSummary.ISIN = rdr["ISIN"].ToString();
                    recordSummary.Best_Ask = rdr["Best_Ask"].ToString();
                    recordSummary.Best_bid = rdr["Best_bid"].ToString();
                    recordSummary.Current_price = rdr["Current_price"].ToString();
                    recordSummary.Ask_Volume = rdr["Ask_Volume"].ToString();
                    recordSummary.Bid_Volume = rdr["Bid_Volume"].ToString();
                    recordSummary.FullCompanyName = rdr["fnam"].ToString();
                    recordSummary.PrevPrice = rdr["PrevPrice"].ToString();
                    recordSummary.PrevChange = Price_change;
                    recordSummary.PrevPer = Price_change_Per;
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult MarketWatchZSENEWBUYS()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcherZSE>();

            var sql =
                "SELECT t.* , ut.fnam FROM CDS_ROUTER.dbo.ZSE_market_data t , testcds_ROUTER.dbo.para_company  ut WHERE t.Ticker = ut.Company";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    if (!rdr["Ask_Volume"].ToString().Equals("0"))
                    {
                        MarketWatcherZSE recordSummary = new MarketWatcherZSE();
                        recordSummary.Ticker = rdr["Ticker"].ToString();
                        recordSummary.ISIN = rdr["ISIN"].ToString();
                        recordSummary.Best_Ask = rdr["Best_Ask"].ToString();
                        recordSummary.Best_bid = rdr["Best_bid"].ToString();
                        recordSummary.Current_price = rdr["Current_price"].ToString();
                        recordSummary.Ask_Volume = rdr["Ask_Volume"].ToString();
                        recordSummary.Bid_Volume = rdr["Bid_Volume"].ToString();
                        recordSummary.FullCompanyName = rdr["fnam"].ToString();
                        marketWatcher.Add(recordSummary);
                    }
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult MarketWatchZSENEWSELLS()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcherZSE>();

            var sql =
                "SELECT t.* , ut.fnam FROM CDS_ROUTER.dbo.ZSE_market_data t , testcds_ROUTER.dbo.para_company  ut WHERE t.Ticker = ut.Company";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    if (!rdr["Bid_Volume"].ToString().Equals("0"))
                    {
                        MarketWatcherZSE recordSummary = new MarketWatcherZSE();
                        recordSummary.Ticker = rdr["Ticker"].ToString();
                        recordSummary.ISIN = rdr["ISIN"].ToString();
                        recordSummary.Best_Ask = rdr["Best_Ask"].ToString();
                        recordSummary.Best_bid = rdr["Best_bid"].ToString();
                        recordSummary.Current_price = rdr["Current_price"].ToString();
                        recordSummary.Ask_Volume = rdr["Ask_Volume"].ToString();
                        recordSummary.Bid_Volume = rdr["Bid_Volume"].ToString();
                        recordSummary.FullCompanyName = rdr["fnam"].ToString();
                        marketWatcher.Add(recordSummary);
                    }

                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetDeliveries(string cds_number)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<Delivery>();

            var sql =
                "select *  FROM [CDS_ROUTER].[dbo].[deriv_contract] where writerNo = '" + cds_number + "' and status = 0";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Delivery recordSummary = new Delivery();
                    recordSummary.Commodity = rdr["Assetname"].ToString();
                    recordSummary.Category = rdr["AssetType"].ToString();
                    recordSummary.Location = rdr["AssetAddress"].ToString();
                    recordSummary.Quantity = rdr["AssetQuantity"].ToString();
                    recordSummary.Warehouse = rdr["Company"].ToString();
                    recordSummary.Expected_delivery_date = rdr["ExpiryMaturityDate"].ToString();
                    marketWatcher.Add(recordSummary);

                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetCommodityTypes(string cds_number)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<Delivery>();

            var sql =
                "select *  FROM [CDS_ROUTER].[dbo].[deriv_contract] where writerNo = '" + cds_number + "' and status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Delivery recordSummary = new Delivery();
                    recordSummary.Commodity = rdr["Ticker"].ToString();
                    recordSummary.Category = rdr["ISIN"].ToString();
                    recordSummary.Location = rdr["Best_Ask"].ToString();
                    recordSummary.Quantity = rdr["Best_bid"].ToString();
                    recordSummary.Warehouse = rdr["Current_price"].ToString();
                    recordSummary.Expected_delivery_date = rdr["Ask_Volume"].ToString();
                    marketWatcher.Add(recordSummary);

                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetProductCategories()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<CommoType>();

            var sql =
                "select distinct market_segment from testcds_ROUTER.dbo.para_company WHERE  instrument='GDR'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    CommoType recordSummary = new CommoType();
                    recordSummary.Category = rdr["market_segment"].ToString();
                    marketWatcher.Add(recordSummary);

                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetPCategoryTypes(string category)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<PSubCategory>();

            var sql =
               "select * from testcds_ROUTER.dbo.para_company WHERE Market_Segment = '" + category + "' and Index_Type='SECONDARY'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    PSubCategory recordSummary = new PSubCategory();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.InitialPrice = rdr["InitialPrice"].ToString();
                    marketWatcher.Add(recordSummary);

                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
        }

      

        public string PostCommodity(string cds_number, string product,
            string quantity, string location, string warehouse,
            string dateofdelivery, string price, string tradetype, string description, string tif = null, string source = null, bool borrow = false)

        {



            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var rndNum = new Random();
            var rnNum = rndNum.Next(100000, 999999);
            var r = LongRandom(0, 999999999, new Random());
            var successMessage = "Posted Successfully.";

            try
            {
                string returnstring;

                if (tradetype.ToUpper().Trim().Equals("DEPOSIT"))
                {
                    string sqlx = "insert into deriv_contract([ContractNo],[writerNo],[writerforename],[writersurname],[Assetname],[AssetDescription],[AssetType],[AssetQuantity],[AssetQuality],[AssetValue],[SettlementDate],[ExpiryMaturityDate],[StrikeExercisePrice],[Terms_Conditions],[SI_Unit],[AssetAddress],[writerAddress],[Company],[Created_By],[Created_On],[writeremail],[writerphone],[writerIDNo],[holderemail],[holderphone],[holderIDNo],[contractType],[HolderNo],[Holderforename],[Holdersurname])values('" + r.ToString() + "','" + cds_number + "',' ',' ','" + product + "',' ','" + description + "','" + quantity + "','GOOD QUALITY',0,'" + today.ToString() + "','" + dateofdelivery + "','" + price + "','VOETSTOETS','kg','" + location + " ','" + cds_number + "','" + warehouse + "','" + cds_number + "',getdate(),' ',' ',' ',' ',' ','" + cds_number + "','" + tradetype + "',' ',' ', ' ')";

                    using (SqlConnection connectionsx = new SqlConnection(connectionStringCDS_Router))
                    {
                        SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                        connectionsx.Open();
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                        returnstring = successMessage;

                    }
                    return returnstring;
                }
                else
                {

                    var result = CommodityPost(product, description, "COMMODITY", tradetype, tradetype, quantity, price, cds_number, source, tif, dateofdelivery, borrow);

                    if (result.Equals("1"))
                    {
                        return successMessage;
                    }
                    else
                    {
                        return result;
                    }
                }
            }
            catch (Exception ex)
            {
                //return "Error occured please contact support at ctrade@escrowgroup.org";
                return ex.ToString();
            }
        }

        public string checkAccount(string email)
        {
            try
            {
                string sqlx = "select email from  [CDS_ROUTER].[dbo].[issuer_client]  where email = '" + email + "'";


                using (SqlConnection connectionsx = new SqlConnection(connectionStringCDS_Router))
                {
                    SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                    connectionsx.Open();
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    return "true";

                }

            }
            catch (Exception e)
            {
                e.ToString();
                return "false";
            }

        }
        public string InsertIssue(string username, string surname,
         string email, string designation, string company,
         string password, string mobile, string tel, string date_created, string company_website)

        {



            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var checkEmail = checkAccount(email);

            var successMessage = "Posted Successfully.";
            var result = "User Has an Existing Account";

            try
            {
                string returnstring;

                if (checkEmail.ToString() == "true")
                {

                    string sqlx = "insert into [CDS_ROUTER].[dbo].[issuer_client] ( [username] ,[surname],[email,[designation],[company ,[password],[mobile] ,[tel],[date_created],[company_website]) values('" + username.ToString() + "','" + surname + "','" + email + "','" + designation + "','" + company + "','" + password + "','" + password + "','" + mobile + "','" + tel + " ','" + date_created.ToString() + "','" + company_website + "')";


                    using (SqlConnection connectionsx = new SqlConnection(connectionStringCDS_Router))
                    {
                        SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                        connectionsx.Open();
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                        returnstring = successMessage;

                    }
                    return successMessage;

                }
                else
                {


                    return result;

                }
            }
            catch (Exception ex)
            {
                //return "Error occured please contact support at ctrade@escrowgroup.org";
                return ex.ToString();
            }
        }


        public JsonResult JoinMeetingMobile(string shareholder, string email, string fullnames)
        {
            var joinInfor_ = new List<JoinInfor>();
            JoinInfor joinInfor;
            joinInfor = new JoinInfor();

            var getfetchStatus_ = new List<GetFetchStatus>();
            GetFetchStatus getfetchStatus;
            getfetchStatus = new GetFetchStatus();
            double myNum = 0;
            try
            {
                if (shareholder == null || shareholder == "" || email == null || email == "" || fullnames == null || fullnames == "")
                {
                    getfetchStatus.ResultID = "1";
                    getfetchStatus.Resultdesc = "provide both email, shareholder and fullname";
                    getfetchStatus_.Add(getfetchStatus);
                    return Json(getfetchStatus_, JsonRequestBehavior.AllowGet);
                }
                else if (Double.TryParse(shareholder, out myNum) == false)
                {
                    getfetchStatus.ResultID = "1";
                    getfetchStatus.Resultdesc = "shareholder number should be numeric";
                    getfetchStatus_.Add(getfetchStatus);
                    return Json(getfetchStatus_, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    //insert if not exists
                    insertUserIfNotExists(email, shareholder, fullnames);
                    //insert if not exists
                    try
                    {
                        using (SqlConnection con = new SqlConnection(escrowshare))
                        {
                            SqlCommand cmd = new SqlCommand("SELECT ISNULL(A.SURNAME,'')+' '+ISNULL(A.forenames,'') AS UserFullname,'SHAREHOLDER' AS UserRole,ISNULL((select top 1 C.PreferredUsername from SignUps C where C.Shareholder=@shareholder),@email) AS userID FROM [MASTER] A JOIN all_agms B ON A.agm_id=B.id where B.locked=0 AND A.shareholder=@shareholder", con);
                            cmd.Parameters.AddWithValue("@shareholder", shareholder);
                            cmd.Parameters.AddWithValue("@email", email);
                            SqlDataAdapter da = new SqlDataAdapter(cmd);
                            DataSet ds = new DataSet("ds");
                            da.Fill(ds);
                            DataTable dt = ds.Tables[0];
                            if (dt.Rows.Count > 0)
                            {
                                DataRow dr = dt.Rows[0];
                                joinInfor.userid = dr["userID"].ToString();
                                joinInfor.userFullname = dr["UserFullname"].ToString();
                                joinInfor.userRole = dr["UserRole"].ToString();
                                joinInfor_.Add(joinInfor);
                                return Json(joinInfor_, JsonRequestBehavior.AllowGet);
                            }
                            else
                            {
                                getfetchStatus.ResultID = "0";
                                getfetchStatus.Resultdesc = "shareholder not in register with active meeting";
                                getfetchStatus_.Add(getfetchStatus);
                                return Json(getfetchStatus_, JsonRequestBehavior.AllowGet);
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        writetofile(ex.ToString());

                        getfetchStatus.ResultID = "2";
                        getfetchStatus.Resultdesc = "could not join meeting at the moment";
                        getfetchStatus_.Add(getfetchStatus);
                        return Json(getfetchStatus_, JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch (Exception ex)
            {
                writetofile(ex.ToString());
                getfetchStatus.ResultID = "2";
                getfetchStatus.Resultdesc = "could not join meeting at the moment";
                getfetchStatus_.Add(getfetchStatus);
                return Json(getfetchStatus_, JsonRequestBehavior.AllowGet);
            }
        }



        public void insertUserIfNotExists(string email, string shareholder, string fullnames)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(escrowshare))
                {
                    string myRandomPassword = RandomString();
                    SqlCommand cmd = new SqlCommand("insertUserIfNotExists", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@shareholder", shareholder);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@rpassword", myRandomPassword);
                    cmd.Parameters.AddWithValue("@rpassword_encrpts", FormsAuthentication.HashPasswordForStoringInConfigFile(myRandomPassword, "sha1"));
                    cmd.Parameters.AddWithValue("@FullNames", fullnames);
                    cmd.Connection = con;
                    if (con.State == ConnectionState.Open)
                        con.Close();
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception ex)
            {

            }
        }



        private static Random random = new Random();

        public static string RandomString()
        {
            int length = 8;
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
        public string PostForex(string cds_number, string currency,
            string quantity, string timeinforce, string bureau,
            string dateofdelivery, string price, string tradetype, string source, string option)

        {



            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var rndNum = new Random();
            var rnNum = rndNum.Next(100000, 999999);
            var r = LongRandom(0, 999999999, new Random());
            var desc = "";
            if (tradetype.ToUpper().Trim().Equals("BUY"))
            {
                desc = "Forex purchase order";
            }
            else if (tradetype.ToUpper().Trim().Equals("SELL"))
            {
                desc = "Forex sale order";
            }
            var successMessage = desc + " posted successfully.";
            var tempDbContext = new cdscDbContext();
            var user_acc = _cdDataContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cds_number);
            if (SanctionedExsistsval(user_acc.Forenames + " " + user_acc.Surname) == 1)
            {
                return "Order Posting failed.Please Contact Administrator.";
            }

            try
            {
                string returnstring = "";

                if (tradetype.ToUpper().Trim().Equals("BUY"))
                {

                    bool buyforpickup = false;
                    bool buyforwallet = false;

                    if (option.ToLower() == "buyforpickup")
                    {
                        buyforpickup = true;
                        buyforwallet = false;

                    }
                    else if (option.ToLower() == "buyforwallet")
                    {
                        buyforpickup = false;
                        buyforwallet = true;
                    }
                    //validate if you have enough balance in ZWL to buy forex
                    var moneyAvail =
                        tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cds_number && x.TransStatus.Trim() == "1");
                    //convert money requested to zwl
                    var moneyrequested = (Convert.ToDecimal(quantity)) * (Convert.ToDecimal(price));
                    if (moneyAvail != null)
                    {

                        var theCashBal =
                            tempDbContext.CashTrans.Where(x => x.CDS_Number == cds_number && x.TransStatus.Trim() == "1")
                                .Select(x => x.Amount)
                                .Sum();
                        if (theCashBal < moneyrequested)
                        {
                            return "You have insufficient balance in your Cash account";
                        }
                    }
                    else
                    {
                        return "You have insufficient balance in your Cash account";
                    }
                    //debit from cashtrans
                    var orderCashTranszwl = new CashTrans
                    {
                        Description = "Forex Purchase",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -1 * moneyrequested,
                        CDS_Number = cds_number,
                        DateCreated = DateTime.Now
                    };
                    tempDbContext.CashTrans.Add(orderCashTranszwl);
                    //credit cashtrans forex
                    var orderCashTrans = new CashTrans_forex
                    {
                        Description = "Forex Purchase",
                        TransType = "BUY",
                        TransStatus = "0",
                        Amount = (Decimal.Parse(quantity)),
                        CDS_Number = cds_number,
                        Currency = "USD",
                        DateCreated = DateTime.Now,
                        Bureau = bureau,
                        Type_ = "BUY",
                        PickUp = false,
                        Rate = (Decimal.Parse(price)),
                        Source = source,
                        BuyForPickUp = buyforpickup,
                        BuyForWallet = buyforwallet,
                        SellForBureau = false,
                        SellForWallet = false
                    };
                    tempDbContext.CashTrans_forex.Add(orderCashTrans);
                    tempDbContext.SaveChanges();
                    return successMessage;
                }
                else if (tradetype.ToUpper().Trim().Equals("SELL"))
                {
                    bool sellforbureau = false;
                    bool sellforwallet = false;
                    if (option.ToLower() == "sellforbureau")
                    {
                        sellforbureau = true;
                        sellforwallet = false;

                    }
                    else if (option.ToLower() == "sellforwallet")
                    {
                        sellforbureau = false;
                        sellforwallet = true;
                    }
                    //validate if you have enough balance in USD to sell forex
                    var moneyAvail =
                       tempDbContext.CashTrans_forex.FirstOrDefault(x => x.CDS_Number == cds_number && x.TransStatus.Trim() == "1");
                    //convert money requested to zwl
                    var moneyrequested = (Decimal.Parse(quantity));
                    if (moneyAvail != null)
                    {

                        var theCashBal =
                            tempDbContext.CashTrans_forex.Where(x => x.CDS_Number == cds_number && x.TransStatus.Trim() == "1")
                                .Select(x => x.Amount)
                                .Sum();
                        if (theCashBal < moneyrequested)
                        {
                            return "You have insufficient balance in your Cash account";
                        }
                    }
                    else
                    {
                        return "You have insufficient balance in your Cash account";
                    }
                    //debit cashtransforex
                    var orderCashTrans = new CashTrans_forex
                    {
                        Description = "Forex Sell",
                        TransType = "SELL",
                        TransStatus = "1",
                        Amount = -(Decimal.Parse(quantity)),
                        CDS_Number = cds_number,
                        Currency = "USD",
                        DateCreated = DateTime.Now,
                        Bureau = bureau,
                        Type_ = "SELL",
                        PickUp = false,
                        Rate = (Decimal.Parse(price)),
                        Source = source,
                        BuyForPickUp = false,
                        BuyForWallet = false,
                        SellForBureau = sellforbureau,
                        SellForWallet = sellforwallet
                    };
                    tempDbContext.CashTrans_forex.Add(orderCashTrans);
                    tempDbContext.SaveChanges();
                    return successMessage;
                }
            }
            catch (Exception ex)
            {
                //return "Error occured please contact support at ctrade@escrowgroup.org";
                return ex.ToString();
            }
            return successMessage;
        }
        public string PostBroker(string cds_number, string currency,
            string quantity, string timeinforce, string bureau,
            string price, string tradetype, string company, string custodian, string names)

        {



            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var rndNum = new Random();
            var rnNum = rndNum.Next(100000, 999999);
            var r = LongRandom(0, 999999999, new Random());
            var successMessage = "Order posted successfully.";

            try
            {
                string returnstring;

                if (tradetype.ToUpper().Trim().Equals("DEPOSIT"))
                {

                    string sqlx = "insert into [CDS_ROUTER].[dbo].[trans]([Company],[CDS_Number],[Date_Created],[Trans_Time],[Shares],[Update_Type],[Created_By],[Batch_Ref],[Source],[Pledge_shares],[Reference],[Instrument],[Broker]) values ('" + currency + "','" + cds_number + "',getdate(),cast(getdate() as time),'" + quantity + "','DEPOSIT','ONLINE','0','0','0','0','FOREX','" + bureau + "')";

                    using (SqlConnection connectionsx = new SqlConnection(connectionStringCDS_Router))
                    {
                        SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                        connectionsx.Open();
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                        returnstring = successMessage;

                    }
                    return returnstring;
                }
                else
                {

                    var result = ForexBroker(company, "EQUITY", "EQUITY", tradetype, tradetype, quantity, price, cds_number, "BROKEROFFICE", timeinforce, today, currency, bureau, custodian, names);

                    if (result.Equals("1"))
                    {
                        return successMessage;
                    }
                    else
                    {
                        return result;
                    }
                }
            }
            catch (Exception ex)
            {
                //return "Error occured please contact support at ctrade@escrowgroup.org";
                return ex.ToString();
            }
        }
        public string ForexBroker(string product, string description, string security, string orderTrans,
  string orderType, string quantity, string price, string cdsNumber,
  string source, string tif, string date_, string currencys, string broker, string custodian, string names)

        {

            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "L";
            Double basePrice = Double.Parse(price, CultureInfo.InvariantCulture); //;
            var theOrderTrans = "";

            try
            {
                //var user_acc = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);
                var acc_type = "I";
                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }


                long orderNumber = 0;
                var myCompany = product;
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }
                var theCds = cdsNumber + "";

                /*if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
                {
                    return "Enter CDS Number";
                }
                */
                /*if (orderTrans.ToString().ToUpper().Equals("SELL"))
                {

                    var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                    var sql = "select * from cdsc.dbo.PortfolioAll d where d.CDS_Number='" + cdsNumber + "' and Company = '" + myCompany + "' ";
                    var shareAvail = 0;
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        connection.Open();
                        SqlDataReader rdr = cmd.ExecuteReader();
                        while (rdr.Read())
                        {
                            shareAvail = int.Parse(rdr["Net"].ToString());
                            //break;
                        }
                    }
                    if (shareAvail < int.Parse(quantity))
                    {
                        return "You have insufficient units in your account.";
                    }

                }*/
                //}

                //IF BUY ORDER
                var totalAmountToSpent = decimal.Parse("0.0");
                var theQuantity = 0;
                if (quantity != null)
                {
                    theQuantity = int.Parse(quantity);
                }

                totalAmountToSpent = theQuantity * decimal.Parse(price) * decimal.Parse("0.0001");

                /*if (acc_type == "i")
                {
                    if (orderTrans.ToString().ToUpper().Equals("BUY"))
                    {
                        var moneyAvail =
                            tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                        if (moneyAvail != null)
                        {
                            var theCashBal =
                                tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                                    .Select(x => x.Amount)
                                    .Sum();
                            if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                            {
                                return "You have insufficient funds in your cash account";
                            }
                        }
                        else
                        {
                            return "You have insufficient funds in your cash account";
                        }
                    }
                }*/
                //SAVING TO DB
                var orderStatus = "OPEN";
                if (acc_type == "c")
                {
                    orderStatus = "NOT AUTHORISED";
                }
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                var expiryDate = DateTime.Parse(date_);

                var brokerCode = "";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = tif;
                var orderQualifier = "None";
                //var brokerRef = theBroker1.Company_Code + "" + orderNumber;
                var contraBrokerId = "";
                var brokerRef = broker + "" + orderNumber;
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "$";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                try
                {
                    var orderLive = new Pre_Order_Live
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        Client_Type = acc_type,
                        Tax = 0,
                        Shareholder = cdsNumber,
                        ClientName = names,
                        TotalShareHolding = 0,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Deal_Begin_Date = dealBeginDate,
                        Expiry_Date = expiryDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        AvailableShares = 0,
                        OrderPref = orderPref,
                        OrderAttribute = orderAttrib,
                        Marketboard = marketBoard,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        ContraBrokerId = contraBrokerId,
                        MaxPrice = maxPrice,
                        MiniPrice = minPrice,
                        Flag_oldorder = flagOldOrder,
                        OrderNumber = orderNum,
                        Currency = currencys,
                        trading_platform = GetTradingPlaform(myCompany),
                        FOK = false,
                        Source = source,
                        Affirmation = true,
                        Custodian = custodian
                    };

                    //save to cdsc tempPreorderLive too
                    CashTrans orderCashTrans = null;

                    orderCashTrans = new CashTrans
                    {
                        Description = "BUY - Order",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -totalAmountToSpent,
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };

                    try
                    {

                        atsDbContext.Pre_Order_Live.Add(orderLive);
                        atsDbContext.SaveChanges();
                        if (orderTrans.ToString().ToUpper().Equals("BUY"))
                        {

                            tempDbContext.CashTrans.Add(orderCashTrans);
                            tempDbContext.SaveChanges();
                        }

                        return "1";
                    }
                    catch (Exception e)
                    {
                        return "Error occured please contact support at ctrade@escrowgroup.org";
                    }
                }
                catch (Exception e)
                {
                    return "Error occured please contact support at ctrade@escrowgroup.org";
                }

            }
            catch (Exception ex)
            {
                //return ex.ToString();
                return "Error occured please contact support at ctrade@escrowgroup.org. Please verify CDS Account.";
            }
        }
        public string ForexPost(string product, string description, string security, string orderTrans,
       string orderType, string quantity, string price, string cdsNumber,
       string source, string tif, string date_, string currencys, string broker)

        {

            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "L";
            Double basePrice = Double.Parse(price, CultureInfo.InvariantCulture); //;
            var theOrderTrans = "";

            try
            {
                var user_acc = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);
                var acc_type = user_acc.AccountType;
                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }


                long orderNumber = 0;
                var myCompany = product;
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }
                var theCds = cdsNumber + "";

                if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
                {
                    return "Enter CDS Number";
                }

                if (orderTrans.ToString().ToUpper().Equals("SELL"))
                {

                    var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                    var sql = "select * from cdsc.dbo.PortfolioAll d where d.CDS_Number='" + cdsNumber + "' and Company = '" + myCompany + "' ";
                    var shareAvail = 0;
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        connection.Open();
                        SqlDataReader rdr = cmd.ExecuteReader();
                        while (rdr.Read())
                        {
                            shareAvail = int.Parse(rdr["Net"].ToString());
                            //break;
                        }
                    }
                    if (shareAvail < int.Parse(quantity))
                    {
                        return "You have insufficient units in your account.";
                    }

                }
                //}

                //IF BUY ORDER
                var totalAmountToSpent = decimal.Parse("0.0");
                var theQuantity = 0;
                if (quantity != null)
                {
                    theQuantity = int.Parse(quantity);
                }

                totalAmountToSpent = theQuantity * decimal.Parse(price) * decimal.Parse("0.0001");

                if (acc_type == "i")
                {
                    if (orderTrans.ToString().ToUpper().Equals("BUY"))
                    {
                        var moneyAvail =
                            tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                        if (moneyAvail != null)
                        {
                            var theCashBal =
                                tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                                    .Select(x => x.Amount)
                                    .Sum();
                            if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                            {
                                return "You have insufficient funds in your cash account";
                            }
                        }
                        else
                        {
                            return "You have insufficient funds in your cash account";
                        }
                    }
                }
                //SAVING TO DB
                var orderStatus = "OPEN";
                if (acc_type == "c")
                {
                    orderStatus = "NOT AUTHORISED";
                }
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                var expiryDate = DateTime.Parse(date_);

                var brokerCode = "";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = tif;
                var orderQualifier = "None";
                //var brokerRef = theBroker1.Company_Code + "" + orderNumber;
                var contraBrokerId = "";
                var brokerRef = broker + "" + orderNumber;
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "$";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                try
                {
                    var orderLive = new Pre_Order_Live
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        Client_Type = acc_type,
                        Tax = 0,
                        Shareholder = cdsNumber,
                        ClientName = name,
                        TotalShareHolding = 0,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Deal_Begin_Date = dealBeginDate,
                        Expiry_Date = expiryDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        AvailableShares = 0,
                        OrderPref = orderPref,
                        OrderAttribute = orderAttrib,
                        Marketboard = marketBoard,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        ContraBrokerId = contraBrokerId,
                        MaxPrice = maxPrice,
                        MiniPrice = minPrice,
                        Flag_oldorder = flagOldOrder,
                        OrderNumber = orderNum,
                        Currency = currencys,
                        trading_platform = GetTradingPlaform(myCompany),
                        FOK = false,

                        Affirmation = true
                    };

                    //save to cdsc tempPreorderLive too
                    CashTrans orderCashTrans = null;

                    orderCashTrans = new CashTrans
                    {
                        Description = "BUY - Order",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -totalAmountToSpent,
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };

                    try
                    {

                        atsDbContext.Pre_Order_Live.Add(orderLive);
                        atsDbContext.SaveChanges();
                        if (orderTrans.ToString().ToUpper().Equals("BUY"))
                        {

                            tempDbContext.CashTrans.Add(orderCashTrans);
                            tempDbContext.SaveChanges();
                        }

                        return "1";
                    }
                    catch (Exception e)
                    {
                        return "Error occured please contact support at ctrade@escrowgroup.org";
                    }
                }
                catch (Exception e)
                {
                    return "Error occured please contact support at ctrade@escrowgroup.org";
                }

            }
            catch (Exception ex)
            {
                //return ex.ToString();
                return "Error occured please contact support at ctrade@escrowgroup.org. Please verify CDS Account.";
            }
        }


        public string CommodityPost(string product, string description, string security, string orderTrans,
      string orderType, string quantity, string price, string cdsNumber,
      string source, string tif, string date_, bool borrow = false)

        {

            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "L";
            Double basePrice = Double.Parse(price, CultureInfo.InvariantCulture); //;
            var theOrderTrans = "";

            try
            {
                var user_acc = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);
                var acc_type = user_acc.AccountType;
                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }


                long orderNumber = 0;
                var myCompany = product;
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }
                var theCds = cdsNumber + "";

                if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
                {
                    return "Enter CDS Number";
                }

                if (orderTrans.ToString().ToUpper().Equals("SELL"))
                {

                    var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                    var sql = "select * from cdsc.dbo.PortfolioAll d where d.CDS_Number='" + cdsNumber + "' and Company = '" + myCompany + "' ";
                    var shareAvail = 0;
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        connection.Open();
                        SqlDataReader rdr = cmd.ExecuteReader();
                        while (rdr.Read())
                        {
                            shareAvail = int.Parse(rdr["Net"].ToString());
                            //break;
                        }
                    }
                    if (shareAvail < int.Parse(quantity))
                    {
                        return "You have insufficient units in your account. \n  Units Avalable are" + shareAvail;
                    }

                }
                //}

                //IF BUY ORDER
                var totalAmountToSpent = decimal.Parse("0.0");
                var theQuantity = 0;
                if (quantity != null)
                {
                    theQuantity = int.Parse(quantity);
                }

                totalAmountToSpent = theQuantity * decimal.Parse(price) * decimal.Parse("0.0001");

                if (acc_type == "i")
                {
                    if (orderTrans.ToString().ToUpper().Equals("BUY"))
                    {
                        var moneyAvail =
                            tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                        if (moneyAvail != null)
                        {
                            var theCashBal =
                                tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                                    .Select(x => x.Amount)
                                    .Sum();
                            if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                            {
                                return "You have insufficient funds in your cash account";
                            }
                        }
                        else
                        {
                            return "You have insufficient funds in your cash account";
                        }
                    }
                }
                //SAVING TO DB
                var orderStatus = "OPEN";
                if (acc_type == "c")
                {
                    orderStatus = "NOT AUTHORISED";
                }
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                var expiryDate = DateTime.Parse(date_);

                var brokerCode = "IMARA";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = tif;
                var orderQualifier = "None";
                //var brokerRef = theBroker1.Company_Code + "" + orderNumber;
                var contraBrokerId = "";
                var brokerRef = "IMARA" + orderNumber;
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "$";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                try
                {
                    var orderLive = new Pre_Order_Live
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = brokerCode,
                        Client_Type = acc_type,
                        Tax = 0,
                        Shareholder = cdsNumber,
                        ClientName = name,
                        TotalShareHolding = 0,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Deal_Begin_Date = dealBeginDate,
                        Expiry_Date = expiryDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        AvailableShares = 0,
                        OrderPref = orderPref,
                        OrderAttribute = orderAttrib,
                        Marketboard = marketBoard,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        ContraBrokerId = contraBrokerId,
                        MaxPrice = maxPrice,
                        MiniPrice = minPrice,
                        Flag_oldorder = flagOldOrder,
                        OrderNumber = orderNum,
                        Currency = currency,
                        trading_platform = GetTradingPlaform(myCompany),
                        FOK = false,
                        Source = source,
                        Affirmation = true,
                        borrowStatus = borrow
                    };

                    //save to cdsc tempPreorderLive too
                    CashTrans orderCashTrans = null;

                    orderCashTrans = new CashTrans
                    {
                        Description = "BUY - Order",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -totalAmountToSpent,
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };

                    try
                    {

                        atsDbContext.Pre_Order_Live.Add(orderLive);
                        atsDbContext.SaveChanges();
                        if (orderTrans.ToString().ToUpper().Equals("BUY"))
                        {

                            tempDbContext.CashTrans.Add(orderCashTrans);
                            tempDbContext.SaveChanges();
                        }

                        return "1";
                    }
                    catch (Exception e)
                    {
                        return "Error occured please contact support at ctrade@escrowgroup.org1";
                    }
                }
                catch (Exception e)
                {
                    return "Error occured please contact support at ctrade@escrowgroup.org2";
                }

            }
            catch (Exception ex)
            {
                return ex.ToString();
                //return "Error occured please contact support at ctrade@escrowgroup.org3";
            }
        }

        public JsonResult portFolioAll(string cdsNumber = null)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var myPortf = new List<PortfolioAll>();

            var sql = "select d.*, ut.fnam as fullCompanyName, ut.Instrument from cdsc.dbo.PortfolioAll d,testcds_ROUTER.dbo.para_company ut  where d.CDS_Number='" + cdsNumber + "' and d.Company = ut.Company";
            var ix = 1;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    PortfolioAll recordSummary = new PortfolioAll();
                    string curr_Port = Force4DecimalPlaces(Math.Round((double.Parse(rdr["currePrice"].ToString()) * double.Parse(rdr["totAllShares"].ToString())), 4).ToString());
                    string prev_Port = Force4DecimalPlaces(Math.Round((double.Parse(rdr["PrevPrice"].ToString()) * double.Parse(rdr["prevdayQuantity"].ToString())), 4).ToString());
                    double ret_Port = Math.Round(double.Parse(curr_Port), 4) - Math.Round(double.Parse(prev_Port), 4);
                    recordSummary.id = ix.ToString();
                    recordSummary.counter = rdr["Company"].ToString();
                    recordSummary.numbershares = rdr["totAllShares"].ToString();
                    recordSummary.Instrument = rdr["Instrument"].ToString();
                    recordSummary.prev_numbershares = rdr["prevdayQuantity"].ToString();
                    recordSummary.lastactivitydate = rdr["LastAcDate"].ToString();
                    recordSummary.currentprice = Force4DecimalPlaces(rdr["currePrice"].ToString());
                    recordSummary.prevprice = Force4DecimalPlaces(rdr["PrevPrice"].ToString());
                    recordSummary.totalportvalue = curr_Port;
                    recordSummary.totalPrevPortValue = prev_Port;
                    recordSummary.returns = Force4DecimalPlaces(ret_Port.ToString());
                    recordSummary.uncleared = Force4DecimalPlaces(rdr["Uncleared"].ToString());
                    recordSummary.net = Force4DecimalPlaces(rdr["Net"].ToString());
                    recordSummary.companyFullName = rdr["fullCompanyName"].ToString();



                    var BuysBymes = new List<BuysByme>();
                    var sql2 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares>0";
                    using (SqlConnection connection2 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd2 = new SqlCommand(sql2, connection2);
                        cmd2.CommandType = CommandType.Text;
                        connection2.Open();
                        SqlDataReader rdr2 = cmd2.ExecuteReader();
                        while (rdr2.Read())
                        {
                            BuysByme recordSum1 = new BuysByme();
                            recordSum1.company = rdr2["Company"].ToString();
                            recordSum1.volume = rdr2["Shares"].ToString();
                            recordSum1.price = Force4DecimalPlaces(rdr2["TradePrice"].ToString());
                            recordSum1.totalValue = Force4DecimalPlaces((decimal.Parse(rdr2["TradePrice"].ToString()) * decimal.Parse(rdr2["Shares"].ToString())).ToString());
                            BuysBymes.Add(recordSum1);
                        }
                    }
                    // foreach (var p in retBids)
                    //{

                    //}
                    recordSummary.BuyDetail = BuysBymes;
                    //get my buys

                    //get my sells
                    //var retOffers = _cdDataContext.trans.Where(x => x.CDS_Number == cdsNumber.ToString() && x.Shares < 0 && x.Company == recordSummary.counter).Select(v => new
                    //{
                    //    comp = v.Company,
                    //    volum = v.Shares,
                    //    pric = v.Shares,
                    //    totVal = v.Shares
                    //});
                    //var sellBymes = new List<SellsByme>();

                    //foreach (var p in retOffers)
                    //{
                    //    SellsByme recordSum2 = new SellsByme();
                    //    recordSum2.company = p.comp.ToString();
                    //    recordSum2.volume = p.volum.ToString();
                    //    recordSum2.price = p.pric.ToString();
                    //    recordSum2.totalValue = p.totVal.ToString();
                    //    sellBymes.Add(recordSum2);
                    //}
                    var sellBymes = new List<SellsByme>();
                    var sql3 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares<0";
                    using (SqlConnection connection3 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd3 = new SqlCommand(sql3, connection3);
                        cmd3.CommandType = CommandType.Text;
                        connection3.Open();
                        SqlDataReader rdr3 = cmd3.ExecuteReader();
                        while (rdr3.Read())
                        {
                            SellsByme recordSum2 = new SellsByme();
                            recordSum2.company = rdr3["Company"].ToString();
                            recordSum2.volume = rdr3["Shares"].ToString();
                            recordSum2.price = Force4DecimalPlaces(rdr3["TradePrice"].ToString());
                            recordSum2.totalValue = Force4DecimalPlaces((decimal.Parse(rdr3["TradePrice"].ToString()) * decimal.Parse(rdr3["Shares"].ToString())).ToString());
                            sellBymes.Add(recordSum2);
                        }
                    }
                    recordSummary.SellDetail = sellBymes;
                    //get my sells

                    myPortf.Add(recordSummary);
                    ix = ix + 1;
                }
            }
            return Json(myPortf, JsonRequestBehavior.AllowGet);
        }

        public JsonResult PortfolioByType(string cdsNumber = null, string type = null)
        {
            string cdcnumber = "";
            try
            {
                var cdc = _cdDataContext.Accounts_Clients_Web.ToList().Where(a => a.CDS_Number.ToLower().Replace(" ", "") == cdsNumber.ToLower().Replace(" ", "")).FirstOrDefault();
                cdcnumber = cdc.CDC_Number;
            }
            catch (Exception)
            {


            }
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var myPortf = new List<PortfolioAll>();


            var sql = "select d.*, ut.fnam as fullCompanyName, ut.Instrument from cdsc.dbo.PortfolioAll d,testcds_ROUTER.dbo.para_company ut  where d.CDS_Number='" + cdsNumber + "' and d.Company = ut.Company and ut.Instrument = '" + type + "'";
            if (string.IsNullOrEmpty(cdcnumber) == false)
            {
                sql = "select d.*, ut.fnam as fullCompanyName, ut.Instrument from cdsc.dbo.PortfolioAll d,testcds_ROUTER.dbo.para_company ut  where d.CDS_Number in ('" + cdsNumber + "','" + cdcnumber + "') and d.Company = ut.Company and ut.Instrument = '" + type + "'";

            }
            var ix = 1;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    PortfolioAll recordSummary = new PortfolioAll();
                    string curr_Port = Force4DecimalPlaces(Math.Round((double.Parse(rdr["currePrice"].ToString()) * double.Parse(rdr["totAllShares"].ToString())), 4).ToString());
                    string prev_Port = Force4DecimalPlaces(Math.Round((double.Parse(rdr["PrevPrice"].ToString()) * double.Parse(rdr["prevdayQuantity"].ToString())), 4).ToString());
                    double ret_Port = Math.Round(double.Parse(curr_Port), 4) - Math.Round(double.Parse(prev_Port), 4);
                    recordSummary.id = ix.ToString();
                    recordSummary.counter = rdr["Company"].ToString();
                    recordSummary.numbershares = rdr["totAllShares"].ToString();
                    recordSummary.Instrument = rdr["Instrument"].ToString();
                    recordSummary.prev_numbershares = rdr["prevdayQuantity"].ToString();
                    recordSummary.lastactivitydate = rdr["LastAcDate"].ToString();
                    recordSummary.currentprice = Force4DecimalPlaces(rdr["currePrice"].ToString());
                    recordSummary.prevprice = Force4DecimalPlaces(rdr["PrevPrice"].ToString());
                    recordSummary.totalportvalue = curr_Port;
                    recordSummary.totalPrevPortValue = prev_Port;
                    recordSummary.returns = Force4DecimalPlaces(ret_Port.ToString());
                    recordSummary.uncleared = Force4DecimalPlaces(rdr["Uncleared"].ToString());
                    recordSummary.net = Force4DecimalPlaces(rdr["Net"].ToString());
                    recordSummary.companyFullName = rdr["fullCompanyName"].ToString();



                    var BuysBymes = new List<BuysByme>();
                    var sql2 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares>0";
                    if (string.IsNullOrEmpty(cdcnumber) == false)
                    {
                        sql2 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number in ('" + cdsNumber + "','" + cdcnumber + "') and d.Company='" + recordSummary.counter + "' and d.Shares>0";

                    }
                    using (SqlConnection connection2 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd2 = new SqlCommand(sql2, connection2);
                        cmd2.CommandType = CommandType.Text;
                        connection2.Open();
                        SqlDataReader rdr2 = cmd2.ExecuteReader();
                        while (rdr2.Read())
                        {
                            BuysByme recordSum1 = new BuysByme();
                            recordSum1.company = rdr2["Company"].ToString();
                            recordSum1.volume = rdr2["Shares"].ToString();
                            recordSum1.price = Force4DecimalPlaces(rdr2["TradePrice"].ToString());
                            recordSum1.totalValue = Force4DecimalPlaces((decimal.Parse(rdr2["TradePrice"].ToString()) * decimal.Parse(rdr2["Shares"].ToString())).ToString());
                            BuysBymes.Add(recordSum1);
                        }
                    }
                    // foreach (var p in retBids)
                    //{

                    //}
                    recordSummary.BuyDetail = BuysBymes;
                    //get my buys

                    //get my sells
                    //var retOffers = _cdDataContext.trans.Where(x => x.CDS_Number == cdsNumber.ToString() && x.Shares < 0 && x.Company == recordSummary.counter).Select(v => new
                    //{
                    //    comp = v.Company,
                    //    volum = v.Shares,
                    //    pric = v.Shares,
                    //    totVal = v.Shares
                    //});
                    //var sellBymes = new List<SellsByme>();

                    //foreach (var p in retOffers)
                    //{
                    //    SellsByme recordSum2 = new SellsByme();
                    //    recordSum2.company = p.comp.ToString();
                    //    recordSum2.volume = p.volum.ToString();
                    //    recordSum2.price = p.pric.ToString();
                    //    recordSum2.totalValue = p.totVal.ToString();
                    //    sellBymes.Add(recordSum2);
                    //}
                    var sellBymes = new List<SellsByme>();
                    var sql3 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares<0";
                    if (string.IsNullOrEmpty(cdcnumber) == false)
                    {
                        sql3 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number in ('" + cdsNumber + "','" + cdcnumber + "') and d.Company='" + recordSummary.counter + "' and d.Shares<0";

                    }
                    using (SqlConnection connection3 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd3 = new SqlCommand(sql3, connection3);
                        cmd3.CommandType = CommandType.Text;
                        connection3.Open();
                        SqlDataReader rdr3 = cmd3.ExecuteReader();
                        while (rdr3.Read())
                        {
                            SellsByme recordSum2 = new SellsByme();
                            recordSum2.company = rdr3["Company"].ToString();
                            recordSum2.volume = rdr3["Shares"].ToString();
                            recordSum2.price = Force4DecimalPlaces(rdr3["TradePrice"].ToString());
                            recordSum2.totalValue = Force4DecimalPlaces((decimal.Parse(rdr3["TradePrice"].ToString()) * decimal.Parse(rdr3["Shares"].ToString())).ToString());
                            sellBymes.Add(recordSum2);
                        }
                    }
                    recordSummary.SellDetail = sellBymes;
                    //get my sells

                    myPortf.Add(recordSummary);
                    ix = ix + 1;
                }
            }
            return Json(myPortf, JsonRequestBehavior.AllowGet);
        }

        public JsonResult MarketWatch()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcher>();

            var sql =
                "SELECT cp.[COMPANY] as Company, [SHARESINISSUE]  as SharesInIssue, [ClosingPrice] as ClosingPrice, [BestPrice] as CurrentPrice, UPPER(pc.fnam) as CompanyName FROM[testcds_ROUTER].[dbo].[CompanyPrices] cp join para_company pc on pc.Company = cp.COMPANY";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatcher recordSummary = new MarketWatcher();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.SharesInIssue = rdr["SharesInIssue"].ToString();
                    recordSummary.ClosingPrice = Math.Round(decimal.Parse(rdr["ClosingPrice"].ToString()), 4);
                    recordSummary.CurrentPrice = Math.Round(decimal.Parse(rdr["CurrentPrice"].ToString()), 4);
                    recordSummary.CompanyName = rdr["CompanyName"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetProductTypeUnits(string type)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<Trust>();

            var sql = "SELECT * from testcds_ROUTER.DBO.para_company where instrument = '" + type + "'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Trust recordSummary = new Trust();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.Issued_shares = decimal.Parse(rdr["Issued_shares"].ToString());
                    recordSummary.InitialPrice = decimal.Parse(rdr["InitialPrice"].ToString());
                    recordSummary.fnam = rdr["fnam"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }




        public JsonResult GetCommoditiesCat()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<Commodity>();
            List<Categories> comodities = new List<Categories>();

            var sql = "select distinct category from cds_router.dbo.commodities";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {

                    Categories category = new Categories();
                    category.CategoryName = rdr["category"].ToString();
                    comodities.Add(category);

                }
            }

            return Json(comodities, JsonRequestBehavior.AllowGet);

        }

        public JsonResult GetCommodities(string category)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<Commodity>();

            var sql = "select * from cds_router.dbo.commodities where category='" + category + "'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Commodity recordSummary = new Commodity
                    {
                        Id = rdr["id"].ToString(),
                        Product = rdr["product"].ToString(),
                        Price = rdr["price"].ToString(),
                        Category = rdr["category"].ToString(),
                        Multiples = rdr["Multiples"].ToString()
                    };
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(0, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetCommoditiesGrades()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<Commodity>();

            // var sql = "select * from cds_router.dbo.commodities where category='" + category + "'";
            var sql = "SELECT [ID],[Company],[Sector],[InitialPrice],isnull([Multiples],1) [Multiples] FROM[testcds_ROUTER].[dbo].[para_company] where Sector = 'Commodity'";
        
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Commodity recordSummary = new Commodity
                    {
                        Id = rdr["ID"].ToString(),
                        Product = rdr["Company"].ToString(),
                        Price = rdr["InitialPrice"].ToString(),
                        Category = rdr["Sector"].ToString(),
                        Multiples = rdr["Multiples"].ToString()
                    };
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(0, JsonRequestBehavior.AllowGet);
            }
        }


        public JsonResult GetZipitBanks()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<ZipitBankCodes>();

            var sql = "select * FROM [CDS_ROUTER].[dbo].[BankZipitCode]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    ZipitBankCodes recordSummary = new ZipitBankCodes
                    {
                        id = int.Parse(rdr["id"].ToString()),
                        bank_name = rdr["bank_name"].ToString(),
                        zipit_code = rdr["zipit_code"].ToString()
                    };
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(0, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetMyCommodities(string cds_number)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<Deriv_Contract>();

            var sql = " select *, Assetname as fname FROM [CDS_ROUTER].[dbo].[deriv_contract] where writerno ='" + cds_number + "' and status='1' order by id desc";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Deriv_Contract recordSummary = new Deriv_Contract
                    {
                        ContractNo = rdr["ContractNo"].ToString(),
                        Assetname = rdr["Assetname"].ToString(),
                        AssetDescription = rdr["AssetDescription"].ToString(),
                        AssetQuantity = rdr["AssetQuantity"].ToString(),
                        Created_On = DateTime.Parse(rdr["Created_On"].ToString()).ToString("dd MMM yyyy HH:mm")
                    };
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(0, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetOrdersByType(string cds_number, string type)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<Pre_O_Lives>();

            string sql = "select p.*, c.fnam from testcds_router.dbo.pre_order_live p join testcds_router.dbo.para_company c  on p.company = c.company  where p.cds_ac_no = '" + cds_number + "' and p.securitytype = '" + type + "' order by p.OrderNo desc";

            if (type.ToLower() == "commodity")
            {
                //sql = "select p.*,p.Company as fnam from testcds_router.dbo.pre_order_live p where p.cds_ac_no = '" + cds_number + "' and p.OrderStatus = 'open' and p.securitytype = '" + type + "' order by p.OrderNo desc";
                sql = "select p.*,p.Company as fnam from testcds_router.dbo.pre_order_live p where p.cds_ac_no = '" + cds_number + "' and p.securitytype = '" + type + "' order by p.OrderNo desc";

            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Pre_O_Lives recordSummary = new Pre_O_Lives
                    {
                        id = int.Parse(rdr["OrderNo"].ToString()),
                        counter = rdr["Company"].ToString(),
                        type = rdr["OrderType"].ToString(),
                        volume = rdr["Quantity"].ToString(),
                        price = rdr["BasePrice"].ToString(),
                        date = DateTime.Parse(rdr["Create_date"].ToString()).ToString("dd MMM yyyy"),
                        status = rdr["OrderStatus"].ToString(),
                        desc = rdr["OrderNumber"].ToString(),
                        fullname = rdr["fnam"].ToString(),
                        ordernumber = rdr["OrderNumber"].ToString(),
                        source = rdr["Source"].ToString(),

                    };
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(0, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetProdTypesCharges(string type)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<TrustCharges>();

            var sql = "SELECT p.Company, p.Issued_shares, p.InitialPrice, p.Issued_shares, p.fnam,  c.*  from testcds_ROUTER.DBO.para_company p JOIN  [CDS_ROUTER].[dbo].[Charges] c on p.instrument = c.security_type where p.instrument= '" + type + "'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    TrustCharges recordSummary = new TrustCharges();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.Issued_shares = decimal.Parse(rdr["Issued_shares"].ToString());
                    recordSummary.InitialPrice = decimal.Parse(rdr["InitialPrice"].ToString());
                    recordSummary.Issued_shares = decimal.Parse(rdr["Issued_shares"].ToString());
                    recordSummary.fnam = rdr["fnam"].ToString();
                    recordSummary.ChargesBuy = rdr["charges_buy"].ToString();
                    recordSummary.ChargesSell = rdr["charges_sell"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetCommodityPortfolio(string cds_number)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<CommoPort>();

            var sql = " select * FROM [CDSC].[dbo].[PortfolioAll] WHERE COMPANY IN (SELECT COMPANY FROM testcds_ROUTER.DBO.para_company WHERE instrument='GDR') and CDS_Number = '" + cds_number + "'";

         //   select w.id as id, c.cds_number as cds_number, isnull(surname, '') + ' ' + isnull(middlename, '') + ' ' + isnull(forenames, '') as names,w.Quantity as Quantity ,w.Commodity as Commodity , Company_name, c.Company_Code as Company_Code from accounts_clients a inner join Client_Companies c  on a.CDS_Number = c.CDS_Number  join wr w on a.CDS_Number = w.Holder where a.CDS_Number + ' ' + isnull(surname, '') + ' ' + isnull(middlename, '') + ' ' + isnull(forenames, '') like '%" + txtclientnumber.Text + "%'"


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    CommoPort recordSummary = new CommoPort();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.LastAcDate = rdr["LastAcDate"].ToString();
                    recordSummary.totAllShares = rdr["totAllShares"].ToString();
                    recordSummary.prevdayQuantity = rdr["prevdayQuantity"].ToString();
                    recordSummary.currePrice = rdr["currePrice"].ToString();
                    recordSummary.PrevPrice = rdr["PrevPrice"].ToString();
                    recordSummary.Uncleared = rdr["Uncleared"].ToString();
                    recordSummary.Net = rdr["Net"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(0, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetNewsFeeds()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<NewsFeed>();

            var sql = "  select * from cds_router.dbo.Diary ";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    NewsFeed recordSummary = new NewsFeed
                    {
                        Heading = rdr["Caption"].ToString(),
                        Message = rdr["Details"].ToString()
                    };
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetTrustsPortfolio(string cdsNumber)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<TrustBalance>();

            var sql = " select Company,sum(shares) as balance from cds_router.dbo.trans where CDS_Number ='" + cdsNumber + "' and update_type ='DEAL UT' GROUP BY COMPANY HAVING SUM(Shares)>0";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    TrustBalance recordSummary = new TrustBalance
                    {
                        Company = rdr["Company"].ToString(),
                        Balance = rdr["balance"].ToString()
                    };
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }


        public JsonResult MarketWatchZSEE()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcherZSE>();

            var sql =
                "SELECT * FROM ZSE_market_data";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatcherZSE recordSummary = new MarketWatcherZSE();
                    recordSummary.Ticker = rdr["Ticker"].ToString();
                    recordSummary.ISIN = rdr["ISIN"].ToString();
                    recordSummary.Best_Ask = rdr["Best_Ask"].ToString();
                    recordSummary.Best_bid = rdr["Best_bid"].ToString();
                    recordSummary.Current_price = rdr["Current_price"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }


        public JsonResult versionControl()
        {
            List<AppVersion> version = new List<AppVersion>
            {
                new AppVersion() { appVersion = "2.1.1" }
            };
            return Json(version, JsonRequestBehavior.AllowGet);
        }


        public JsonResult marketStatus(String market)
        {
            if (market == "ZSE")
            {
                List<MarketStatus> version = new List<MarketStatus>
            {
                new MarketStatus(){openTime ="1000", closeTime ="1230"}
            };
                return Json(version, JsonRequestBehavior.AllowGet);

            }
            else if (market == "FINSEC")
            {
                List<MarketStatus> version = new List<MarketStatus>
            {
                new MarketStatus(){openTime ="900", closeTime ="1630"}
            };
                return Json(version, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return null;
            }

        }


        public string MarketNews()
        {
            return "Market ";
        }

        public JsonResult Balance(string cdsNumber = null)
        {

            var sums = _cdDataContext.trans.Join(_cdDataContext.para_company, c => c.Company, d => d.Company,
                (c, d) => new
                {
                    Company = d.Fnam,
                    CompanyCode = c.Company,
                    Shares = c.Shares,
                    CdsNumber = c.CDS_Number
                })
             .Where(d => d.CdsNumber == cdsNumber)
             .GroupBy(d => d.Company)
             .Select(g =>
                 new
                 {
                     Name = g.Select(s => s.Company).FirstOrDefault(),
                     ISIN = g.Select(s => s.CompanyCode).FirstOrDefault(),
                     Shares = g.Sum(s => s.Shares),
                 });

            return Json(sums, JsonRequestBehavior.AllowGet);
        }
        public JsonResult Balances(string cdsNumber = null)
        {

            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var CompShares = new List<Balances>();

            var sql = "select tm.*,pc.Fnam from (select tx.Company,tx.CDS_Number,sum(tx.Shares) as totShares from trans tx group by tx.Company,tx.CDS_Number) tm left Join para_company pc on tm.Company = pc.Company  where tm.CDS_Number = '" + cdsNumber + "' and tm.totShares>0";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Balances recordSummary = new Balances();
                    recordSummary.Name = rdr["Fnam"].ToString();
                    recordSummary.ISIN = rdr["Company"].ToString();
                    recordSummary.Shares = long.Parse(rdr["totShares"].ToString());
                    CompShares.Add(recordSummary);
                }
            }

            if (CompShares.Any())
            {
                return Json(CompShares, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult SecMovement(string cdsNumber = null)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<PortfolioMovement>();

            var sql = "select tx.Shares as Shares, tx.Date_Created as Date, tx.Company, pc.Fnam as CompanyName, ISNULL(tx.Instrument, 'EQUITY') as Instrument from trans tx    Join para_company pc on tx.Company = pc.Company  where CDS_Number = '" + cdsNumber + "' order by tx.Date_created asc";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    PortfolioMovement recordSummary = new PortfolioMovement();
                    recordSummary.CompanyName = rdr["CompanyName"].ToString();
                    recordSummary.Shares = rdr["Shares"].ToString();
                    recordSummary.Date = DateTime.Parse(rdr["Date"].ToString()).ToShortDateString();
                    recordSummary.Instrument = rdr["Instrument"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }

        //ACCOUNT CREATION PARAMETERES
        public JsonResult GetCompanies(string company = null)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<GetBroker>();

            var sql = "select distinct UPPER(Company_name) as Name, [Company_Code] as Code FROM [CDS_ROUTER].[dbo].[Client_Companies]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    GetBroker recordSummary = new GetBroker();
                    recordSummary.Name = rdr["Name"].ToString();
                    recordSummary.Code = rdr["Code"].ToString();

                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetBureau()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<GetBureau>();

            var sql = "select distinct UPPER(Company_name) as Name, [Company_Code] as Code,(SELECT  top 1 [BUYING] FROM [CDS_ROUTER].[dbo].[ForexMarketWatch]  where BUREAU=Company_Code   order by id desc) as 'BuyPrice',(SELECT  top 1 [SELLING] FROM [CDS_ROUTER].[dbo].[ForexMarketWatch]  where BUREAU=Company_Code   order by id desc) as 'SellPrice' FROM [CDS_ROUTER].[dbo].[Client_Companies] where Company_type='BUREAU'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    GetBureau recordSummary = new GetBureau
                    {
                        Name = rdr["Name"].ToString(),
                        Code = rdr["Code"].ToString(),
                        BuyingVolume = "200",
                        BuyingPrice = rdr["BuyPrice"].ToString(),
                        SellingVolume = "111",
                        SellingPrice = rdr["SellPrice"].ToString()
                    };
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult GetCurrency()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<GetBroker>();

            var sql = "SELECT TOP 1000 [CurrencyCode] As Code,[CurrencyName] as Name FROM [CDS_ROUTER].[dbo].[para_Currencies]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    GetBroker recordSummary = new GetBroker();
                    recordSummary.Name = rdr["Name"].ToString();
                    recordSummary.Code = rdr["Code"].ToString();

                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }



        public JsonResult ForexMarketWatch()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var marketWatcher = new List<Forex>();

            var sql = "select * FROM ForexMarketWatch";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Forex recordSummary = new Forex();
                    recordSummary.ID = rdr["ID"].ToString();
                    recordSummary.BUREAU = rdr["BUREAU"].ToString();
                    recordSummary.BUYING = rdr["BUYING"].ToString();
                    recordSummary.SELLING = rdr["SELLING"].ToString();
                    recordSummary.DATE_UPDATED = DateTime.Parse(rdr["DATE_UPDATED"].ToString()).ToString("dd-MM-yyyy HH:ss");
                    recordSummary.UPDATED_BY = rdr["UPDATED_BY"].ToString();
                    recordSummary.ACTIVE = rdr["ACTIVE"].ToString();
                    recordSummary.CURRENCY = rdr["CURRENCY"].ToString();
                    recordSummary.BUY_LIMIT = rdr["BUY_LIMIT"].ToString();
                    recordSummary.SELL_LIMIT = rdr["SELL_LIMIT"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult GetCompany(string exchange, string range, string company = null)
        {
            //Selecting distinct
            var companies = _AtsDbContext.para_company.Where(x => x.exchange.Contains(exchange)).GroupBy(x => x.fnam).Select(x => x.FirstOrDefault()).Select(c =>
                new
                {
                    Id = c.ID,
                    Name = c.fnam,
                    c.InitialPrice
                });
            return Json(companies, JsonRequestBehavior.AllowGet);
        }

        public JsonResult MobileMoney(string company = null)
        {
            var mobileMoney = _cdDataContext.para_mobile_money.GroupBy(x => x.Mobile_money_name).Select(x => x.FirstOrDefault()).Select(c => new
            {
                Id = c.ID,
                Name = c.Mobile_money_name
            });
            return Json(mobileMoney, JsonRequestBehavior.AllowGet);
        }

        /*        public JsonResult Banks(string company = null)
                {
                    var getBanks = _cdDataContext.para_bank.GroupBy(x => x.bank_name).Select(x => x.FirstOrDefault()).Select(c => new
                    {
                        Id = c.bank,
                        Code = c.bank,
                        Name = c.bank_name
                    });
                    return Json(getBanks, JsonRequestBehavior.AllowGet);
                }*/

/*        public JsonResult Banks(string company = null)
        {
            var getBanks = _cdDataContext.para_bank.GroupBy(x => x.bank_name).Select(x => x.FirstOrDefault()).Select(c => new
            {
                Id = c.bank,
                Code = c.bank,
                Name = c.bank_name
            });
            return Json(getBanks, JsonRequestBehavior.AllowGet);
        }*/


        public JsonResult Banks()
        {

            SqlConnection connection = new SqlConnection(connectionStringCDS);
            //  var sql = "SELECT * FROM [CDS].[dbo].[WR] " + " where [holder] =  " + "'" + WRNo + "'";
            var sql = "SELECT DISTINCT  c.Company_name +'   '+c.Company_Code  as bank , (SELECT top 1 id from cds.dbo.Para_lendingRules where bank=Para_lendingRules.Bank ) as [id]  from  para_lendingRules p,  Client_Companies c where c.Company_Code=p.Bank";
            connection.Open();

            SqlCommand cmd = new SqlCommand(sql, connection);
            cmd.CommandType = CommandType.Text;


            var banks = new List<BankModel>();

         
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                BankModel bank = new BankModel
                {
                    bank = rdr["bank"].ToString(),
                    id = rdr["id"].ToString()

                };
            banks.Add(bank);
            }


            connection.Close();

            return Json(banks, JsonRequestBehavior.AllowGet);



        }



        public JsonResult Branch(string bank = null)
        {
            var getBranch = _cdDataContext.para_branch.GroupBy(x => x.branch_name).Select(x => x.FirstOrDefault()).Where(x => x.bank == bank).Select(c => new
            {
                Name = c.branch_name
            });
            return Json(getBranch, JsonRequestBehavior.AllowGet);
        }



        public JsonResult GetBranchFromFullName(string bank_name)
        {
            var sql =
                "   Select t.bank_name , ut.branch_name , ut.branch FROM para_bank t, para_branch ut WHERE t.bank = ut.bank and t.bank_name = '" +
                bank_name + "'";
            var marketNews = new List<Branches>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Branches recordSummary = new Branches();
                    recordSummary.Name = rdr["branch_name"].ToString();
                    recordSummary.Code = rdr["branch"].ToString();
                    marketNews.Add(recordSummary);
                }
            }


            if (marketNews.Any())
            {
                return Json(marketNews, JsonRequestBehavior.AllowGet);
            }
            return Json("HEAD", JsonRequestBehavior.AllowGet);

        }



        public JsonResult Prices(string oldpass)
        {

            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcher>();

            var sql =
                "SELECT cp.[COMPANY] as Company ,[SHARESINISSUE]  as SharesInIssue ,[ClosingPrice] as ClosingPrice ,[BestPrice] as CurrentPrice ,UPPER(pc.fnam) as CompanyName ,convert (decimal(10, 2),  (([BestPrice] - [ClosingPrice])/[ClosingPrice])*100) as Change FROM [testcds_ROUTER].[dbo].[CompanyPrices] cp join para_company pc on pc.Company = cp.COMPANY ";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatcher recordSummary = new MarketWatcher();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.SharesInIssue = rdr["SharesInIssue"].ToString();
                    recordSummary.ClosingPrice = Math.Round(decimal.Parse(rdr["ClosingPrice"].ToString()), 4);
                    recordSummary.CurrentPrice = Math.Round(decimal.Parse(rdr["CurrentPrice"].ToString()), 4);
                    recordSummary.Change = decimal.Parse(rdr["Change"].ToString());

                    recordSummary.ChangeString = decimal.Parse(rdr["Change"].ToString()).ToString("##.000");
                    recordSummary.CompanyName = rdr["CompanyName"].ToString();
                    recordSummary.Exchange = "FINSEC";
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }

        public JsonResult EscrosharePrices()
        {

            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcher>();

            var sql =
                "select a.Company as Company,a.PricePerShare as SharesInIssue,a.PricePerShare as ClosingPrice,a.PricePerShare as CurrentPrice,UPPER(c.fnam) as CompanyName,convert (decimal(10, 2),a.PercentageChange) as Change  from PortFolio a join para_company c on a.Company=c.company where a.DateToday=(select top 1 b.DateToday from PortFolio b order by b.id desc)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatcher recordSummary = new MarketWatcher();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.SharesInIssue = rdr["SharesInIssue"].ToString();
                    recordSummary.ClosingPrice = Math.Round(decimal.Parse(rdr["ClosingPrice"].ToString()), 4);
                    recordSummary.CurrentPrice = Math.Round(decimal.Parse(rdr["CurrentPrice"].ToString()), 4);
                    recordSummary.Change = decimal.Parse(rdr["Change"].ToString());

                    recordSummary.ChangeString = decimal.Parse(rdr["Change"].ToString()).ToString("##.000");
                    recordSummary.CompanyName = rdr["CompanyName"].ToString();
                    recordSummary.Exchange = "ZSE";
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }
        public JsonResult AllPrices()
        {

            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var connectionString2 = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcher>();

            var sql =
                "select a.Company as Company,a.PricePerShare as SharesInIssue,a.PricePerShare as ClosingPrice,a.PricePerShare as CurrentPrice,UPPER(c.fnam) as CompanyName,convert (decimal(10, 2),a.PercentageChange) as Change  from PortFolio a join para_company c on a.Company=c.company where a.DateToday=(select top 1 b.DateToday from PortFolio b order by b.id desc)";
            var sql2 =
                "SELECT cp.[COMPANY] as Company ,[SHARESINISSUE]  as SharesInIssue ,[ClosingPrice] as ClosingPrice ,[BestPrice] as CurrentPrice ,UPPER(pc.fnam) as CompanyName ,convert (decimal(10, 2),  (([BestPrice] - [ClosingPrice])/[ClosingPrice])*100) as Change FROM [testcds_ROUTER].[dbo].[CompanyPrices] cp join para_company pc on pc.Company = cp.COMPANY ";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatcher recordSummary = new MarketWatcher();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.SharesInIssue = rdr["SharesInIssue"].ToString();
                    recordSummary.ClosingPrice = Math.Round(decimal.Parse(rdr["ClosingPrice"].ToString()), 4);
                    recordSummary.CurrentPrice = Math.Round(decimal.Parse(rdr["CurrentPrice"].ToString()), 4);
                    recordSummary.Change = decimal.Parse(rdr["Change"].ToString());

                    recordSummary.ChangeString = decimal.Parse(rdr["Change"].ToString()).ToString("##.000");
                    recordSummary.CompanyName = rdr["CompanyName"].ToString();
                    recordSummary.Exchange = "ZSE";
                    marketWatcher.Add(recordSummary);
                }
            }
            //append

            using (SqlConnection connection2 = new SqlConnection(connectionString2))
            {
                SqlCommand cmd2 = new SqlCommand(sql2, connection2);
                cmd2.CommandType = CommandType.Text;
                connection2.Open();
                SqlDataReader rdr2 = cmd2.ExecuteReader();
                while (rdr2.Read())
                {
                    MarketWatcher recordSummary2 = new MarketWatcher();
                    recordSummary2.Company = rdr2["Company"].ToString();
                    recordSummary2.SharesInIssue = rdr2["SharesInIssue"].ToString();
                    recordSummary2.ClosingPrice = Math.Round(decimal.Parse(rdr2["ClosingPrice"].ToString()), 4);
                    recordSummary2.CurrentPrice = Math.Round(decimal.Parse(rdr2["CurrentPrice"].ToString()), 4);
                    recordSummary2.Change = decimal.Parse(rdr2["Change"].ToString());

                    recordSummary2.ChangeString = decimal.Parse(rdr2["Change"].ToString()).ToString("##.000");
                    recordSummary2.CompanyName = rdr2["CompanyName"].ToString();
                    recordSummary2.Exchange = "FINSEC";
                    marketWatcher.Add(recordSummary2);
                }
            }
            //append

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }
        public JsonResult Top_Gainers()
        {

            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var connectionString2 = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcher>();

            var sql =
                "select a.Company as Company,a.PricePerShare as SharesInIssue,a.PricePerShare as ClosingPrice,a.PricePerShare as CurrentPrice,UPPER(c.fnam) as CompanyName,convert (decimal(10, 2),a.PercentageChange) as Change  from PortFolio a join para_company c on a.Company=c.company where a.DateToday=(select top 1 b.DateToday from PortFolio b order by b.id desc) and a.PercentageChange>0 order by a.PercentageChange desc";
            var sql2 =
                "SELECT cp.[COMPANY] as Company ,[SHARESINISSUE]  as SharesInIssue ,[ClosingPrice] as ClosingPrice ,[BestPrice] as CurrentPrice ,UPPER(pc.fnam) as CompanyName ,convert (decimal(10, 2),  (([BestPrice] - [ClosingPrice])/[ClosingPrice])*100) as Change FROM [testcds_ROUTER].[dbo].[CompanyPrices] cp join para_company pc on pc.Company = cp.COMPANY  WHERE cp.[BestPrice] - cp.[ClosingPrice]>0 order by cp.[BestPrice] - cp.[ClosingPrice] desc";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatcher recordSummary = new MarketWatcher();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.SharesInIssue = rdr["SharesInIssue"].ToString();
                    recordSummary.ClosingPrice = Math.Round(decimal.Parse(rdr["ClosingPrice"].ToString()), 4);
                    recordSummary.CurrentPrice = Math.Round(decimal.Parse(rdr["CurrentPrice"].ToString()), 4);
                    recordSummary.Change = decimal.Parse(rdr["Change"].ToString());

                    recordSummary.ChangeString = decimal.Parse(rdr["Change"].ToString()).ToString("##.000");
                    recordSummary.CompanyName = rdr["CompanyName"].ToString();
                    recordSummary.Exchange = "ZSE";
                    marketWatcher.Add(recordSummary);
                }
            }
            //append

            using (SqlConnection connection2 = new SqlConnection(connectionString2))
            {
                SqlCommand cmd2 = new SqlCommand(sql2, connection2);
                cmd2.CommandType = CommandType.Text;
                connection2.Open();
                SqlDataReader rdr2 = cmd2.ExecuteReader();
                while (rdr2.Read())
                {
                    MarketWatcher recordSummary2 = new MarketWatcher();
                    recordSummary2.Company = rdr2["Company"].ToString();
                    recordSummary2.SharesInIssue = rdr2["SharesInIssue"].ToString();
                    recordSummary2.ClosingPrice = Math.Round(decimal.Parse(rdr2["ClosingPrice"].ToString()), 4);
                    recordSummary2.CurrentPrice = Math.Round(decimal.Parse(rdr2["CurrentPrice"].ToString()), 4);
                    recordSummary2.Change = decimal.Parse(rdr2["Change"].ToString());

                    recordSummary2.ChangeString = decimal.Parse(rdr2["Change"].ToString()).ToString("##.000");
                    recordSummary2.CompanyName = rdr2["CompanyName"].ToString();
                    recordSummary2.Exchange = "FINSEC";
                    marketWatcher.Add(recordSummary2);
                }
            }
            //append

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }
        public JsonResult Top_Losers()
        {

            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var connectionString2 = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcher>();

            var sql =
                "select a.Company as Company,a.PricePerShare as SharesInIssue,a.PricePerShare as ClosingPrice,a.PricePerShare as CurrentPrice,UPPER(c.fnam) as CompanyName,convert (decimal(10, 2),a.PercentageChange) as Change  from PortFolio a join para_company c on a.Company=c.company where a.DateToday=(select top 1 b.DateToday from PortFolio b order by b.id desc) and a.PercentageChange<0 order by a.PercentageChange asc";
            var sql2 =
                "SELECT cp.[COMPANY] as Company ,[SHARESINISSUE]  as SharesInIssue ,[ClosingPrice] as ClosingPrice ,[BestPrice] as CurrentPrice ,UPPER(pc.fnam) as CompanyName ,convert (decimal(10, 2),  (([BestPrice] - [ClosingPrice])/[ClosingPrice])*100) as Change FROM [testcds_ROUTER].[dbo].[CompanyPrices] cp join para_company pc on pc.Company = cp.COMPANY  WHERE cp.[BestPrice] - cp.[ClosingPrice]<0 order by cp.[BestPrice] - cp.[ClosingPrice] asc";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatcher recordSummary = new MarketWatcher();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.SharesInIssue = rdr["SharesInIssue"].ToString();
                    recordSummary.ClosingPrice = Math.Round(decimal.Parse(rdr["ClosingPrice"].ToString()), 4);
                    recordSummary.CurrentPrice = Math.Round(decimal.Parse(rdr["CurrentPrice"].ToString()), 4);
                    recordSummary.Change = decimal.Parse(rdr["Change"].ToString());

                    recordSummary.ChangeString = decimal.Parse(rdr["Change"].ToString()).ToString("##.000");
                    recordSummary.CompanyName = rdr["CompanyName"].ToString();
                    recordSummary.Exchange = "ZSE";
                    marketWatcher.Add(recordSummary);
                }
            }
            //append

            using (SqlConnection connection2 = new SqlConnection(connectionString2))
            {
                SqlCommand cmd2 = new SqlCommand(sql2, connection2);
                cmd2.CommandType = CommandType.Text;
                connection2.Open();
                SqlDataReader rdr2 = cmd2.ExecuteReader();
                while (rdr2.Read())
                {
                    MarketWatcher recordSummary2 = new MarketWatcher();
                    recordSummary2.Company = rdr2["Company"].ToString();
                    recordSummary2.SharesInIssue = rdr2["SharesInIssue"].ToString();
                    recordSummary2.ClosingPrice = Math.Round(decimal.Parse(rdr2["ClosingPrice"].ToString()), 4);
                    recordSummary2.CurrentPrice = Math.Round(decimal.Parse(rdr2["CurrentPrice"].ToString()), 4);
                    recordSummary2.Change = decimal.Parse(rdr2["Change"].ToString());

                    recordSummary2.ChangeString = decimal.Parse(rdr2["Change"].ToString()).ToString("##.000");
                    recordSummary2.CompanyName = rdr2["CompanyName"].ToString();
                    recordSummary2.Exchange = "FINSEC";
                    marketWatcher.Add(recordSummary2);
                }
            }
            //append

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }
        public JsonResult TopGainers(string oldpass)
        {

            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcher>();

            var sql =
                "SELECT cp.[COMPANY] as Company ,[SHARESINISSUE]  as SharesInIssue , [ClosingPrice] as ClosingPrice,[BestPrice] as CurrentPrice ,UPPER(pc.fnam) as CompanyName ,convert(decimal(10, 2), (([BestPrice] - [ClosingPrice]) /[ClosingPrice]) * 100) as Change FROM [CompanyPrices] cp join para_company pc on pc.Company = cp.COMPANY where (([BestPrice] - [ClosingPrice]) /[ClosingPrice]) * 100 > 0 order by Change desc  ";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatcher recordSummary = new MarketWatcher();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.SharesInIssue = rdr["SharesInIssue"].ToString();
                    recordSummary.ClosingPrice = Math.Round(decimal.Parse(rdr["ClosingPrice"].ToString()), 4);
                    recordSummary.CurrentPrice = Math.Round(decimal.Parse(rdr["CurrentPrice"].ToString()), 4);
                    recordSummary.Change = Math.Round(decimal.Parse(rdr["Change"].ToString()), 4);

                    recordSummary.ChangeString = decimal.Parse(rdr["Change"].ToString()).ToString("##.000");

                    float f = float.Parse(rdr["Change"].ToString());

                    recordSummary.ChangeString = f.ToString("##,####");


                    recordSummary.CompanyName = rdr["CompanyName"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }
        public JsonResult TopLosers(string oldpass)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<MarketWatcher>();

            var sql = "SELECT top 10 cp.[COMPANY] as Company ,[SHARESINISSUE]  as SharesInIssue ,[ClosingPrice] as ClosingPrice ,[BestPrice] as CurrentPrice ,UPPER(pc.fnam) as CompanyName ,convert(decimal(10, 2),  (([BestPrice] - [ClosingPrice])/[ClosingPrice])*100) as Change FROM[testcds_ROUTER].[dbo].[CompanyPrices] cp join para_company pc on pc.Company = cp.COMPANY where (([BestPrice] - [ClosingPrice])/[ClosingPrice])*100 < 0 order by Change asc";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatcher recordSummary = new MarketWatcher();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.SharesInIssue = rdr["SharesInIssue"].ToString();
                    recordSummary.ClosingPrice = Math.Round(decimal.Parse(rdr["ClosingPrice"].ToString()), 4);
                    recordSummary.CurrentPrice = Math.Round(decimal.Parse(rdr["CurrentPrice"].ToString()), 4);
                    recordSummary.Change = decimal.Parse(decimal.Parse(rdr["Change"].ToString()).ToString("f4"));
                    recordSummary.CompanyName = rdr["CompanyName"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetNews()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var marketNews = new List<TheNews>();

            var sql =
                "SELECT ID,post_title,post_content,post_date,post_mime_type FROM News ORDER BY ID DESC";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    TheNews recordSummary = new TheNews();
                    recordSummary.id = long.Parse(rdr["ID"].ToString());
                    recordSummary.isImportant = true;
                    recordSummary.picture = "";
                    recordSummary.from = "FINSEC";
                    recordSummary.subject = rdr["post_title"].ToString();
                    recordSummary.message = rdr["post_content"].ToString();
                    recordSummary.timestamp = rdr["post_date"].ToString();
                    recordSummary.isRead = false;
                    marketNews.Add(recordSummary);
                }
            }

            if (marketNews.Any())
            {
                return Json(marketNews, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
        }

        public JsonResult MarketWatchs(string oldpass)
        {


            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<MarketWatch>();

            var sql = "SELECT [company] as Company ,[Volume] as Volume ,[Bid] as Bid ,[Volume Sell] as VolumeSell ,[Ask] ,[Last Traded Price] as LastTradedPrice ,[Lastmatched] ,[lastvolume] ,[TotalVolume],[Turnover],[Open],[High],[Low],[Average Price] as AvgPrice,[Change],[percchange],[url],[url2]FROM[testcds_ROUTER].[dbo].[MarketWatch]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatch recordSummary = new MarketWatch();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.Volume = rdr["Volume"].ToString();
                    recordSummary.Bid = rdr["Bid"].ToString();
                    recordSummary.VolumeSell = rdr["VolumeSell"].ToString();
                    recordSummary.Ask = rdr["Ask"].ToString();
                    recordSummary.LastTradedPrice = rdr["LastTradedPrice"].ToString();
                    recordSummary.Lastmatched = rdr["Lastmatched"].ToString();
                    recordSummary.Lastvolume = rdr["Lastvolume"].ToString();
                    recordSummary.TotalVolume = rdr["TotalVolume"].ToString();
                    recordSummary.Turnover = rdr["Turnover"].ToString();
                    recordSummary.Open = rdr["Open"].ToString();
                    recordSummary.High = rdr["High"].ToString();
                    recordSummary.Low = rdr["Low"].ToString();
                    recordSummary.AveragePrice = rdr["AvgPrice"].ToString();
                    recordSummary.Change = rdr["Change"].ToString();
                    recordSummary.Percchange = rdr["Percchange"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }

        public JsonResult MarketWatchsComs(string name)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcher = new List<MarketWatch>();

            var sql = "SELECT [company] as Company, [Volume] as Volume ,[Bid] as Bid ,[Volume Sell] as VolumeSell ,[Ask] ,[Last Traded Price] as LastTradedPrice ,[Lastmatched] ,[lastvolume] ,[TotalVolume],[Turnover],[Open],[High],[Low],[Average Price] as AvgPrice,[Change],[percchange],[url],[url2]FROM[testcds_ROUTER].[dbo].[MarketWatch] where RTRIM(LTRIM(fnam))='" + name.Trim() + "'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatch recordSummary = new MarketWatch();
                    recordSummary.Company = rdr["Company"].ToString();
                    recordSummary.Volume = rdr["Volume"].ToString();
                    recordSummary.Bid = rdr["Bid"].ToString();
                    recordSummary.VolumeSell = rdr["VolumeSell"].ToString();
                    recordSummary.Ask = rdr["Ask"].ToString();
                    recordSummary.LastTradedPrice = rdr["LastTradedPrice"].ToString();
                    recordSummary.Lastmatched = rdr["Lastmatched"].ToString();
                    recordSummary.Lastvolume = rdr["Lastvolume"].ToString();
                    recordSummary.TotalVolume = rdr["TotalVolume"].ToString();
                    recordSummary.Turnover = rdr["Turnover"].ToString();
                    recordSummary.Open = rdr["Open"].ToString();
                    recordSummary.High = rdr["High"].ToString();
                    recordSummary.Low = rdr["Low"].ToString();
                    recordSummary.AveragePrice = rdr["AvgPrice"].ToString();
                    recordSummary.Change = rdr["Change"].ToString();
                    recordSummary.Percchange = rdr["Percchange"].ToString();
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }

        public JsonResult ResetPassword(string email, string natId, string newpass)
        {
            //            var cdDataContext = new CdDataContext();
            if (email != null || newpass != null || natId != null)
            {
                var usernameFound = _cdscDbContext.Vatenkecis.FirstOrDefault(x => x.Email == email);
                if (usernameFound != null)
                {

                    var IdNumberFound = _cdDataContext.Accounts_Clients.FirstOrDefault(x => x.Email == email && x.IDNoPP == natId);

                    if (IdNumberFound != null)
                    {
                        usernameFound.Password = newpass;
                        try
                        {
                            _cdscDbContext.SaveChanges();
                            return Json(1, JsonRequestBehavior.AllowGet);
                        }
                        catch (Exception)
                        {
                            return Json(3, JsonRequestBehavior.AllowGet);
                        }
                    }
                    return Json(4, JsonRequestBehavior.AllowGet);

                }
                return Json(2, JsonRequestBehavior.AllowGet);
            }
            return Json(0, JsonRequestBehavior.AllowGet);
        }

        public JsonResult ForgotPassword(string email, string natId, string newpass, string dob)
        {
            //            var cdDataContext = new CdDataContext();
            if (email != null || newpass != null || natId != null)
            {
                var usernameFound = _cdscDbContext.Vatenkecis.FirstOrDefault(x => x.Email == email);
                if (usernameFound != null)
                {
                    DateTime ofBirth;
                    if (DateTime.TryParse(dob, out ofBirth))
                    {
                        var IdNumberFound = _cdDataContext.Accounts_Clients.FirstOrDefault(x => x.IDNoPP == natId && x.DOB == DateTime.Parse(dob));

                        if (IdNumberFound != null)
                        {
                            usernameFound.Password = newpass;
                            try
                            {
                                _cdscDbContext.SaveChanges();
                                return Json(1, JsonRequestBehavior.AllowGet);
                            }
                            catch (Exception)
                            {
                                return Json(3, JsonRequestBehavior.AllowGet);
                            }
                        }
                        return Json(4, JsonRequestBehavior.AllowGet);
                    }
                    return Json(5, JsonRequestBehavior.AllowGet);//failed to convert striing provided under dob into datetime

                }
                return Json(2, JsonRequestBehavior.AllowGet);
            }
            return Json(0, JsonRequestBehavior.AllowGet);
        }

        /*public JsonResult ResetPassword(string email, string natId, string newpass)
        {
           //            var cdDataContext = new CdDataContext();
           if (email != null || newpass != null || natId != null)
           {
               var usernameFound = _cdscDbContext.Subscribers.FirstOrDefault(x => x.Email == email);
               if (usernameFound != null)
               {

                   //                    var userCtrade = cdDataContext.Accounts_Clients.FirstOrDefault(x => x.Email == email);
                   //
                   //                    if (userCtrade != null)
                   //                    {
                   //
                   //                    }

                   usernameFound.Password = newpass;
                   try
                   {
                       _cdscDbContext.SaveChanges();
                       return Json(1, JsonRequestBehavior.AllowGet);
                   }
                   catch (Exception)
                   {
                       return Json(3, JsonRequestBehavior.AllowGet);
                   }
               }
               return Json(2, JsonRequestBehavior.AllowGet);
           }
           return Json(0, JsonRequestBehavior.AllowGet);
        }*/


        public JsonResult ChangePassword(string oldpass, string newpass, string id)
        {
            if (oldpass != null || newpass != null || id != null)
            {
                //                var ids = int.Parse(id);

                var usernameFound = _cdscDbContext.Vatenkecis.FirstOrDefault(x => x.Password == oldpass && x.Active && x.Email == id);
                if (usernameFound != null)
                {
                    usernameFound.Password = newpass;
                    try
                    {
                        _cdscDbContext.SaveChanges();
                        return Json(1, JsonRequestBehavior.AllowGet);
                    }
                    catch (Exception)
                    {
                        return Json(3, JsonRequestBehavior.AllowGet);
                    }
                }
                return Json(2, JsonRequestBehavior.AllowGet);
            }
            return Json(0, JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeactivateAccount(string username, string password)
        {
            if (username != null || password != null)
            {
                var usernameFound = _cdscDbContext.Vatenkecis.FirstOrDefault(x => x.Username == username && x.Password == password && x.Active);
                if (usernameFound != null)
                {
                    usernameFound.Active = false;
                    try
                    {
                        _cdscDbContext.SaveChanges();
                        return Json(1, JsonRequestBehavior.AllowGet);
                    }
                    catch (Exception)
                    {
                        return Json(3, JsonRequestBehavior.AllowGet);
                    }
                }
                return Json(2, JsonRequestBehavior.AllowGet);
            }
            return Json(0, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Subscribe(string id, string toAdd, string toRemove)
        {
            var itemsToRemove = new ArrayList();
            var itemsToAdd = new ArrayList();
            var count = 0;

            var addReturn = 0;
            var remReturn = 0;
            var ret = "0";

            if (toAdd != null)
            {
                itemsToAdd.AddRange(toAdd.Split('*'));
                itemsToAdd.RemoveAt(itemsToAdd.Count - 1);

                foreach (var adds in itemsToAdd)
                {
                    var theString = adds;
                    var theProduct =
                    _cdscDbContext.Products.OrderByDescending(x => x.Id)
                        .FirstOrDefault(x => x.Name == theString.ToString());

                    if (theProduct != null)
                    {
                        var theProductId = theProduct.Id;

                        //INSERTING INTO SUBSCRIBERPRODUCTS
                        var subscriberProduct = new SubscriberProduct
                        {
                            SubscriberId = int.Parse(id),
                            ProductId = theProductId,
                            Date = DateTime.Now
                        };

                        try
                        {
                            _cdscDbContext.SubscriberProducts.Add(subscriberProduct);
                            _cdscDbContext.SaveChanges();
                            addReturn++;
                        }
                        catch (Exception exception)
                        {
                            ret = exception.ToString();
                            addReturn = 0;
                        }
                    }
                }
            }


            if (toRemove != null)
            {
                itemsToRemove.AddRange(toRemove.Split('*'));
                itemsToRemove.RemoveAt(itemsToRemove.Count - 1);

                //                for (int i = 0; i < toRemove.Length; i++)
                foreach (var rev in itemsToRemove)
                {
                    var theString = rev;
                    var theProduct =
                        _cdscDbContext.Products.OrderByDescending(x => x.Id)
                            .FirstOrDefault(x => x.Name == theString.ToString());

                    if (theProduct != null)
                    {
                        var theProductId = theProduct.Id;
                        var code = _cdscDbContext.SubscriberProducts.FirstOrDefault(x => x.ProductId == theProductId);

                        if (code != null)
                        {
                            try
                            {
                                _cdscDbContext.SubscriberProducts.Remove(code);
                                _cdscDbContext.SaveChanges();
                                count++;
                                remReturn++;
                            }
                            catch (Exception exception)
                            {
                                ret = exception.ToString();
                            }
                        }
                    }
                }
            }
            //0. For any errors
            //1. For Add only
            //2. For Rev Only
            //3. For Add and Rev

            var rets = 0;

            if (toAdd != null && toAdd.Length > 0)
            {
                if (addReturn == itemsToAdd.Count)
                {
                    rets = 1;
                }
                else
                {
                    rets = 0;
                }
            }

            if (toRemove != null && toRemove.Length > 0)
            {
                if (count == itemsToRemove.Count)
                {
                    rets = 2;
                }
                else
                {
                    rets = 0;
                }
            }

            if (toRemove != null && toAdd != null)
            {
                if (addReturn == itemsToAdd.Count && count == itemsToRemove.Count)
                {
                    rets = 3;
                }
            }
            return Json(rets, JsonRequestBehavior.AllowGet);
        }



        public Boolean investmentClubsClient(string clubname, string phone, String cds_Number, String clubEmail)
        {
            {

                var r = LongRandom(0, 9999999999999, new Random());


                Accounts_Clients_Web accountsClients = new Accounts_Clients_Web
                {
                    Title = "",
                    CDS_Number = cds_Number,
                    AccountType = "IC",
                    BrokerCode = "CORP",
                    Surname = clubname,
                    Forenames = clubname,
                    IDNoPP = r.ToString(),
                    DOB = DateTime.Now,
                    Gender = "",
                    Nationality = "Zimbabwean",
                    Country = "Zimbabwe",
                    Email = clubEmail,
                    Div_Bank = "",
                    Div_AccountNo = "",
                    Middlename = "",
                    Initials = "",
                    IDtype = "",
                    Add_1 = "",
                    Add_2 = "",
                    Add_3 = "",
                    Add_4 = "",
                    City = "",
                    Tel = phone,
                    Mobile = phone,
                    Category = "",
                    Custodian = "",
                    TradingStatus = "DEALING ALLOWED",
                    Industry = "",
                    Tax = "",
                    Div_Branch = "",
                    Cash_Bank = "",
                    Cash_Branch = "",
                    Cash_AccountNo = "",
                    Update_Type = "",
                    Created_By = "",
                    AccountState = "",
                    Comments = "",
                    DivPayee = "",
                    SettlementPayee = "",
                    Account_class = "",
                    idnopp2 = "",
                    idtype2 = "",
                    client_image2 = "",
                    documents2 = "",
                    isin = "",
                    sttupdate = true,
                    company_code = "",
                    mobile_money = "",
                    mobile_number = "",
                    Attached_Documents = "",
                    Date_Created = DateTime.Now
                };



                _cdDataContext.Accounts_Clients_Web.Add(accountsClients);
                _cdDataContext.SaveChanges();

                return true;
                //}
                //catch (Exception ex)
                //{
                //    return Json(ex, JsonRequestBehavior.AllowGet);
                //}
            }
        }


        public JsonResult AccountCreationIssuer(string branch, string mobile, string adress_yangu, string theTitle, string theSurname, string theName, string thenationality, string theDOB, string theGender, string theCountry, string idNums, string bank, string accountNum, string email, string password)
        {

            //        public JsonResult AccountCreation(string theTitle)
            //        {


            var rndNum = new Random();
            var rnNum = rndNum.Next(100000, 999999);
            var r = LongRandom(0, 999999999999999, new Random());

            Accounts_Clients_Web accountsClients = new Accounts_Clients_Web
            {
                Title = "",
                CDS_Number = r.ToString(),
                AccountType = "E",
                BrokerCode = "CORP",
                Surname = theSurname,
                Forenames = theName,
                IDNoPP = idNums,
                DOB = DateTime.Parse(theDOB),
                Gender = "",
                Nationality = "Zimbabwean",
                Country = "Zimbabwe",
                Email = email,
                Div_Bank = bank,
                Div_AccountNo = "",
                Middlename = "",
                Initials = "",
                IDtype = "",
                Add_1 = "",
                Add_2 = "",
                Add_3 = "",
                Add_4 = "",
                City = "",
                Tel = mobile,
                Mobile = mobile,
                Category = "",
                Custodian = "",
                TradingStatus = "DEALING ALLOWED",
                Industry = "",
                Tax = "",
                Div_Branch = branch,
                Cash_Bank = "",
                Cash_Branch = "",
                Cash_AccountNo = "",
                Update_Type = "",
                Created_By = "",
                AccountState = "",
                Comments = "",
                DivPayee = "",
                SettlementPayee = "",
                Account_class = "",
                idnopp2 = "",
                idtype2 = "",
                client_image2 = "",
                documents2 = "",
                isin = "",
                sttupdate = true,
                company_code = "",
                mobile_money = "",
                mobile_number = "",
                Attached_Documents = "",
                Date_Created = DateTime.Now
            };



            _cdDataContext.Accounts_Clients_Web.Add(accountsClients);
            _cdDataContext.SaveChanges();

            var subscriber = new Vatenkecis
            {
                Email = email,
                Username = email,
                CdsNumber = GetCdsNumberFROMIDNUM(idNums),
                Password = password,
                Active = true,
                Date = DateTime.Now
            };
            sendmail(email, "You have successfully created C-Trade Account. CDS Number " +
                GetCdsNumberFROMIDNUM(idNums), "Access Account Opened");
            _cdscDbContext.Vatenkecis.Add(subscriber);
            _cdscDbContext.SaveChanges();

            return Json(1, JsonRequestBehavior.AllowGet);
            //}
            //catch (Exception ex)
            //{
            //    return Json(ex, JsonRequestBehavior.AllowGet);
            //}
        }


        public JsonResult AccountCreation(string branch, string mobile, string adress_yangu, string theTitle, string theSurname, string theName, string thenationality, string theDOB, string theGender, string theCountry, string idNums, string bank, string accountNum, string email, string password)
        {

            //        public JsonResult AccountCreation(string theTitle)
            //        {


            var rndNum = new Random();
            var rnNum = rndNum.Next(100000, 999999);
            var r = LongRandom(0, 999999999999999, new Random());

            Accounts_Clients_Web accountsClients = new Accounts_Clients_Web
            {
                Title = theTitle,
                CDS_Number = r.ToString(),
                AccountType = "I",
                BrokerCode = "CORP",
                Surname = theSurname,
                Forenames = theName,
                IDNoPP = idNums,
                DOB = DateTime.Parse(theDOB),
                Gender = theGender,
                Nationality = thenationality,
                Country = theCountry,
                Email = email,
                Div_Bank = bank,
                Div_AccountNo = accountNum,
                Middlename = "",
                Initials = "",
                IDtype = "",
                Add_1 = adress_yangu,
                Add_2 = "",
                Add_3 = "",
                Add_4 = "",
                City = "",
                Tel = mobile,
                Mobile = mobile,
                Category = "",
                Custodian = "",
                TradingStatus = "DEALING ALLOWED",
                Industry = "",
                Tax = "",
                Div_Branch = branch,
                Cash_Bank = "",
                Cash_Branch = "",
                Cash_AccountNo = "",
                Update_Type = "",
                Created_By = "",
                AccountState = "",
                Comments = "",
                DivPayee = "",
                SettlementPayee = "",
                Account_class = "",
                idnopp2 = "",
                idtype2 = "",
                client_image2 = "",
                documents2 = "",
                isin = "",
                sttupdate = true,
                company_code = "",
                mobile_money = "",
                mobile_number = "",
                Attached_Documents = "",
                Date_Created = DateTime.Now
            };



            _cdDataContext.Accounts_Clients_Web.Add(accountsClients);
            _cdDataContext.SaveChanges();

            var subscriber = new Vatenkecis
            {
                Email = email,
                Username = email,
                CdsNumber = GetCdsNumberFROMIDNUM(idNums),
                Password = password,
                Active = true,
                Date = DateTime.Now
            };
            sendmail(email, "You have successfully created C-Trade Account. CDS Number " +
                GetCdsNumberFROMIDNUM(idNums), "Access Account Opened");
            _cdscDbContext.Vatenkecis.Add(subscriber);
            _cdscDbContext.SaveChanges();

            return Json(1, JsonRequestBehavior.AllowGet);
            //}
            //catch (Exception ex)
            //{
            //    return Json(ex, JsonRequestBehavior.AllowGet);
            //}
        }

        public JsonResult AccountMaintenance(string cdsNum, string theAddress, string theCountry, string theTelephone, string theMobile, string theEmail, string theAccName, string theAccNum, string theBank, string theBranch,
                           string theMobileMoney, string theMobileMoneyNumber)
        {
            var found = _cdDataContext.Account_Creation.FirstOrDefault(x => x.CDSC_Number == cdsNum);

            if (found != null)
            {
                found.Address1 = theAddress;
                found.Country = theCountry;
                found.TelephoneNumber = theTelephone;
                found.Emailaddress = theEmail;
                found.Accountnumber = theAccNum;
                found.Bank = theBank;
                found.Branch = theBranch;

                try
                {
                    _cdDataContext.SaveChanges();
                    return Json(1, JsonRequestBehavior.AllowGet);
                }
                catch (Exception)
                {
                    return Json(0, JsonRequestBehavior.AllowGet);
                }
            }
            return Json(0, JsonRequestBehavior.AllowGet);
        }

        public JsonResult CheckWhoRegistered(string any)
        {
            var rets = _cdDataContext.Accounts_Clients.FirstOrDefault(x => x.Email.Trim() == any || x.CDS_Number == any.Trim());
            if (rets != null)
            {
                var mobAccount = _cdscDbContext.Vatenkecis.FirstOrDefault(x => x.Email == any.Trim() || x.CdsNumber == any.Trim());
                if (mobAccount != null)
                {
                    return Json(1, JsonRequestBehavior.AllowGet);
                }
                return Json(rets, JsonRequestBehavior.AllowGet);
            }
            //create new account
            return Json(0, JsonRequestBehavior.AllowGet);
        }
        public JsonResult InvestorReg(string idNumber, string pass)
        {
            //            return 
            //            return Json(idNumber + "  " + pass, JsonRequestBehavior.AllowGet);
            //            x => x.Username.Trim() == "rfde@gmail.com" && x.Password.Trim() == "12341234"


            var cdDataContexts = new cdscDbContext();
            var usernameFound = cdDataContexts.Vatenkecis.FirstOrDefault(x => (x.Username.Trim() == idNumber.Trim() || x.CdsNumber.Trim() == idNumber.Trim()) && x.Password == pass.Trim());


            if (usernameFound != null)
            {
                if (usernameFound.Active == false)
                {
                    return Json(8, JsonRequestBehavior.AllowGet);
                }
                //                return Json("2", JsonRequestBehavior.AllowGet);
                var user = _cdDataContext.Accounts_Clients.FirstOrDefault(x => (x.Email.Trim() == idNumber.Trim() || x.CDS_Number.Trim() == idNumber.Trim()));
                if (user != null)
                {
                    Random generator = new Random();
                    string GenerateRandomNo = generator.Next(1, 10000).ToString("D4");
                    var rets =
                        _cdDataContext.Accounts_Clients.Where(x => (x.Email.Trim() == idNumber.Trim() || x.CDS_Number.Trim() == idNumber.Trim()))
                            .OrderByDescending(x => x.ID)
                            .Select(c => new
                            {
                                id = c.CDS_Number,
                                brokerName = c.Custodian,
                                broker = c.BrokerCode,
                                cds = c.CDS_Number,
                                email = c.Email,
                                name = c.Surname + " " + c.Forenames,
                                phone = c.Mobile,
                                pin = GenerateRandomNo
                            });

                    String sqlx = "";
                    foreach (var p in rets)
                    {
                        var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                        sqlx = "Update Vatenkecis set PIN ='" + GenerateRandomNo + "' where CdsNumber='" + p.cds.ToString() + "' ";
                        //Console.WriteLine("Hello World!" + sqlx);
                        //return Json(sqlx, JsonRequestBehavior.AllowGet);
                        //messagesend_MOBI(p.phone, "Your pin is " + GenerateRandomNo); 
                        using (SqlConnection connectionsx = new SqlConnection(connectionString))
                        {
                            SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                            connectionsx.Open();
                            cmd.CommandType = CommandType.Text;
                            cmd.ExecuteNonQuery();

                        }
                        //connectionsx.Close();
                        break;
                    }

                    /*if(rets != null)
                    {
                    string subject = "CTradeMobile login pin";
                    string emailBody = "Your one time pin is " + GenerateRandomNo;
                    sendmail(user.Email, subject, emailBody);
                    }*/

                    return Json(rets, JsonRequestBehavior.AllowGet);
                }
                return Json("No email in accounts creation", JsonRequestBehavior.AllowGet);
            }
            //1. Checking from Accounts_Creation
            return Json("No email in registrations", JsonRequestBehavior.AllowGet);
        }
        public JsonResult InvestorRegAuto(string idNumber, string pass)
        {
            //            return 
            //            return Json(idNumber + "  " + pass, JsonRequestBehavior.AllowGet);
            //            x => x.Username.Trim() == "rfde@gmail.com" && x.Password.Trim() == "12341234"


            var cdDataContexts = new cdscDbContext();
            var usernameFound = cdDataContexts.Vatenkecis.FirstOrDefault(x => (x.Username.Trim() == idNumber.Trim() || x.CdsNumber.Trim() == idNumber.Trim()) && x.Password == pass.Trim());

            if (usernameFound != null)
            {
                if (usernameFound.Active == false)
                {
                    return Json(8, JsonRequestBehavior.AllowGet);
                }
                //                return Json("2", JsonRequestBehavior.AllowGet);
                var user = _cdDataContext.Accounts_Clients.FirstOrDefault(x => (x.Email.Trim() == idNumber.Trim() || x.CDS_Number.Trim() == idNumber.Trim()));
                if (user != null)
                {
                    Random generator = new Random();
                    string GenerateRandomNo = generator.Next(1, 10000).ToString("D4");
                    var rets =
                        _cdDataContext.Accounts_Clients.Where(x => (x.Email.Trim() == idNumber.Trim() || x.CDS_Number.Trim() == idNumber.Trim()))
                            .OrderByDescending(x => x.ID)
                            .Select(c => new
                            {
                                id = c.CDS_Number,
                                brokerName = c.Custodian,
                                broker = c.BrokerCode,
                                cds = c.CDS_Number,
                                email = c.Email,
                                name = c.Surname + " " + c.Forenames,
                                phone = c.Mobile,
                                pin = GenerateRandomNo
                            });

                    String sqlx = "";
                    foreach (var p in rets)
                    {

                        var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                        sqlx = "Update Vatenkecis set PIN ='" + GenerateRandomNo + "' where CdsNumber='" + p.cds.ToString() + "' ";
                        using (SqlConnection connectionsx = new SqlConnection(connectionString))
                        {
                            SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                            connectionsx.Open();
                            cmd.CommandType = CommandType.Text;
                            cmd.ExecuteNonQuery();

                        }
                        //connectionsx.Close();
                        break;
                    }
                    try
                    {
                        SmtpClient client = new SmtpClient();
                        client.Port = 587;
                        client.Host = "smtp.gmail.com";
                        client.EnableSsl = true;
                        ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                        client.Timeout = 30000;
                        client.DeliveryMethod = SmtpDeliveryMethod.Network;
                        client.UseDefaultCredentials = false;
                        client.Credentials = new System.Net.NetworkCredential("escrowctrade@gmail.com", "asdfghjkl2017");
                        MailMessage mm = new MailMessage();
                        mm.BodyEncoding = Encoding.UTF8;
                        mm.From = new MailAddress("info@ctrade.co.zw");
                        mm.To.Add(user.Email);
                        mm.Subject = "CTradeMobile login pin";
                        mm.Body = GenerateRandomNo;
                        mm.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;

                        client.Send(mm);
                        return Json(rets, JsonRequestBehavior.AllowGet);
                    }
                    catch (Exception e)
                    {
                        return Json("Error sending OTP Please try again", JsonRequestBehavior.AllowGet);
                    }
                }
                return Json("No email in accounts creation", JsonRequestBehavior.AllowGet);
            }
            //1. Checking from Accounts_Creation
            return Json("No email in registrations", JsonRequestBehavior.AllowGet);
        }

        string fileName = "C:\\uss\\Loggingdatarangu.txt";
        private void writetofile(String mssg)
        {

            StreamWriter objWriter3 = new System.IO.StreamWriter(fileName, true);
            objWriter3.WriteLine("Any Message ipapapa" + mssg);
            objWriter3.Close();
        }

        public string messagesend_MOBI(string mobile, string message)
        {
            String my_rteturn = "";
            try
            {
                string mob_number = mobile.Replace(" ", "");
                if (mob_number.StartsWith("0") == true)
                {
                    mob_number = Regex.Replace(mob_number, "^0", "263");
                }
                else if (mob_number.StartsWith("263") == false)
                {
                    mob_number = "263" + mob_number;
                }
                mob_number = "263772166492";
                System.Net.WebClient client = new System.Net.WebClient();
                String url_req = "http://etext.co.zw/sendsms.php?user=263773360785&password=simbaj80&mobile=" + mob_number.ToString() + "&senderid=C-TRADE&message=" + message + "";
                my_rteturn = client.DownloadString(url_req);
                writetofile("Phone " + mob_number + " " + my_rteturn + " " + url_req);
            }
            catch (Exception ex)
            {
                writetofile(ex.ToString());
                my_rteturn = "";
            }
            return my_rteturn;
        }

        public JsonResult Subscriptions(int id)
        {
            var rets = _cdscDbContext.Products.Where(x => x.Active).Select(c => new
            {
                id = c.Id,
                name = c.Name
            });
            return Json(rets, JsonRequestBehavior.AllowGet);
        }

        public JsonResult MySubscriptions(int id)
        {

            var ret = _cdscDbContext.SubscriberProducts.Join(_cdscDbContext.Products, c => c.ProductId, cd => cd.Id,
                (c, cd) => new
                {
                    Name = cd.Name,
                    Id = c.Id,
                    ProductId = cd.Id,
                    SubscriberId = c.SubscriberId
                }).Where(cd => cd.SubscriberId == id);

            return Json(ret, JsonRequestBehavior.AllowGet);
        }

        public string UpdateBroker(string broker, string cdsnumber)
        {
            string returnstring = "";
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            string sqlx = "Update Accounts_Clients set BrokerCode ='" + broker + "' where CDS_Number='" + cdsnumber + "' ";

            using (SqlConnection connectionsx = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                connectionsx.Open();
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                returnstring = "Successfully Updated";

            }
            return returnstring;
        }

        public string UpdateCancelOrder(string orderType, string cdsnumber, string ordernumber)
        {
            string returnstring = "";
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            string sqlx = "Update Pre_Order_Live set OrderStatus ='PENDING CANCELLATION' where OrderNo ='" + ordernumber
                + "' and CDS_AC_No='" + cdsnumber + "' ";

            using (SqlConnection connectionsx = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                connectionsx.Open();
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                returnstring = "Successfully Cancelled";

            }
            return returnstring;
        }


        public string approveOrder(string orderType, string cdsnumber, string ordernumber)
        {
            string returnstring = "";
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            string sqlx = "Update Pre_Order_Live set OrderStatus ='OPEN' where OrderNo ='" + ordernumber
                + "' and CDS_AC_No='" + cdsnumber + "' ";

            using (SqlConnection connectionsx = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                connectionsx.Open();
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                returnstring = "Successfully Approved";

            }
            return returnstring;
        }

        public string updateBankDetails(string bank, string branch, string account, string cdsnumber)
        {
            string returnstring = "";
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            //string sqlx = "Update Pre_Order_Live set OrderStatus ='CANCELLED' where OrderNo ='" + ordernumber
            //    + "' and CDS_AC_No='" + cdsnumber + "' ";
            string sqlx = "update cds.dbo.Accounts_Clients set Cash_Bank = '" + bank + "', Cash_Branch = '" + branch + "', Cash_AccountNo = '" + account + "' where CDS_Number = '" + cdsnumber + "' update CDS_ROUTER.dbo.Accounts_Clients set Cash_Bank = '" + bank + "', Cash_Branch = '" + branch + "', Cash_AccountNo = '" + account + "' where CDS_Number = '" + cdsnumber + "' update cds_router.dbo.Accounts_Clients_Web set Cash_Bank = '" + bank + "', Cash_Branch = '" + branch + "', Cash_AccountNo = '" + account + "' where CDS_Number = '" + cdsnumber + "'";

            using (SqlConnection connectionsx = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                connectionsx.Open();
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                returnstring = "Bank details successfully updated.";

            }
            return returnstring;
        }

        public string updatePersonalDetails(string dob, string gender, string email, string address, string cdsnumber)
        {
            string returnstring = "";
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            //string sqlx = "Update Pre_Order_Live set OrderStatus ='CANCELLED' where OrderNo ='" + ordernumber
            //    + "' and CDS_AC_No='" + cdsnumber + "' ";
            string sqlx = "update cds.dbo.Accounts_Clients set  DOB = '" + dob + "', Gender = '" + gender + "', Email = '" + email + "', Add_1 = '" + address + "' where CDS_Number = '" + cdsnumber + "' update CDS_ROUTER.dbo.Accounts_Clients set DOB = '" + dob + "', Gender = '" + gender + "', Email = '" + email + "' , Add_1 = '" + address + "' where CDS_Number = '" + cdsnumber + "' update cds_router.dbo.Accounts_Clients_Web set DOB = '" + dob + "', Gender = '" + gender + "', Email = '" + email + "' , Add_1 = '" + address + "' where CDS_Number = '" + cdsnumber + "'";

            using (SqlConnection connectionsx = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                connectionsx.Open();
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                returnstring = "Your details have been successfully updated. Please dial *727# again to trade";

            }
            return returnstring;
        }

        public string updateAccountDetails(string bank, string branch, string account, string address, string mobile, string cdsnumber)
        {
            string returnstring = "";
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            //string sqlx = "Update Pre_Order_Live set OrderStatus ='CANCELLED' where OrderNo ='" + ordernumber
            //    + "' and CDS_AC_No='" + cdsnumber + "' ";
            string sqlx = "update cds.dbo.Accounts_Clients set Cash_Bank = '" + bank + "', Cash_Branch = '" + branch + "', Add_1 = '" + address + "', Mobile ='" + mobile + "',  Cash_AccountNo = '" + account + "' where CDS_Number = '" + cdsnumber + "' update CDS_ROUTER.dbo.Accounts_Clients set Cash_Bank = '" + bank + "', Cash_Branch = '" + branch + "', Cash_AccountNo = '" + account + "', Add_1 = '" + address + "', Mobile ='" + mobile + "' where CDS_Number = '" + cdsnumber + "' update cds_router.dbo.Accounts_Clients_Web set Cash_Bank = '" + bank + "', Cash_Branch = '" + branch + "', Cash_AccountNo = '" + account + "', Add_1 = '" + address + "', Mobile ='" + mobile + "' where CDS_Number = '" + cdsnumber + "'";

            using (SqlConnection connectionsx = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                connectionsx.Open();
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                returnstring = "Account details successfully updated.";

            }
            return returnstring;
        }

        public JsonResult NewLog(string idNumber = null)
        {
            var getBrk = "select ac.CDS_Number as id, cc.Company_name as brokerCode, ac.CDS_Number as CdsNumber from [CDS_ROUTER].[dbo].Accounts_Clients ac join [CDS_ROUTER].[dbo].Client_Companies cc on ac.BrokerCode = cc.Company_Code where ac.IDNoPP='" + idNumber + "'";

            var newLogs = new List<NewLog>();
            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    NewLog newLog = new NewLog();
                    newLog.Id = rdr["id"].ToString();
                    newLog.BrokerCode = rdr["brokerCode"].ToString();
                    newLog.CdsNumber = rdr["CdsNumber"].ToString();
                    newLogs.Add(newLog);
                }

                try
                {
                    var jsonResult = Json(newLogs, JsonRequestBehavior.AllowGet);
                    jsonResult.MaxJsonLength = int.MaxValue;
                    return jsonResult;
                }
                catch (Exception)
                {
                    return Json("Data set too large", JsonRequestBehavior.AllowGet);
                }
            }
        }

        public JsonResult Login(string username = null, string password = null)
        {
            if (username != null || password != null)
            {
                var usernameFound = _cdscDbContext.Vatenkecis.FirstOrDefault(x => (x.Username.Trim() == username.Trim() || x.CdsNumber.Trim() == username.Trim()) && (x.Password.Trim() == password.Trim() && x.Active));
                if (usernameFound != null)
                {
                    var ret = _cdscDbContext.Vatenkecis.Where(x => (x.Username.Trim() == username.Trim() || x.CdsNumber.Trim() == username.Trim()) && x.Password.Trim() == password.Trim()).OrderByDescending(x => x.Id).Select(v => new
                    {
                        id = v.Id,
                        username = v.Username,
                        email = v.Email,
                        cds = v.CdsNumber,

                        //fullname = getAccountFullname(cds)
                    }).Take(1);

                    return Json(ret, JsonRequestBehavior.AllowGet);
                }
                return Json(0, JsonRequestBehavior.AllowGet);
            }
            return Json(0, JsonRequestBehavior.AllowGet);
        }

        public JsonResult NewLogin(string username = null, string password = null)
        {

            if (username != null || password != null)
            {

                var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
                var CompShares = new List<VatenkeciNew>();

                var sql = "SELECT t.* , ut.BrokerCode  FROM [CDSC].[dbo].[Vatenkecis] t , [CDS_ROUTER].[dbo].[Accounts_Clients] ut where t.Email ='" + username + "' and t.Password = '" + password + "' and t.CdsNumber = ut.CDS_Number";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        VatenkeciNew recordSummary = new VatenkeciNew();
                        recordSummary.id = int.Parse(rdr["id"].ToString());
                        recordSummary.username = rdr["username"].ToString();
                        recordSummary.email = rdr["email"].ToString();
                        recordSummary.broker = rdr["BrokerCode"].ToString();
                        recordSummary.cds = rdr["CdsNumber"].ToString();
                        recordSummary.Active = Convert.ToBoolean(rdr["Active"].ToString());
                        CompShares.Add(recordSummary);
                    }
                }

                if (CompShares.Any())
                {
                    return Json(CompShares, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(0, JsonRequestBehavior.AllowGet);
                }
            }
            return Json(0, JsonRequestBehavior.AllowGet);

        }
        // GET: Subscriber
        public JsonResult Registration(string email = null, string username = null, string password = null)
        {
            var usernameFound = _cdscDbContext.Vatenkecis.FirstOrDefault(x => x.Username == username && x.Active && x.Email == email);
            if (usernameFound == null)
            {
                if (email != null || username != null || password != null)
                {
                    var subscriber = new Vatenkecis
                    {
                        Email = email,
                        Username = username,
                        CdsNumber = username,
                        Password = password,
                        Active = true,
                        Date = DateTime.Now
                    };
                    try
                    {
                        _cdscDbContext.Vatenkecis.Add(subscriber);
                        _cdscDbContext.SaveChanges();

                        sendmail(email, "You have successfully created C-Trade Account. Kindly note that this is not a trading account, its just an account to access market information. You will be requested to open a trading  account if you want to trade", "Access Account Opened");
                        return Json(1, JsonRequestBehavior.AllowGet);
                    }
                    catch (Exception exception)
                    {
                        return Json(exception.ToString(), JsonRequestBehavior.AllowGet);
                    }
                }
                return Json(0, JsonRequestBehavior.AllowGet);
            }
            return Json(2, JsonRequestBehavior.AllowGet);
        }
        public string SendMailAgain(string Message, string Subject)
        {
            try
            {
                bool retVal;
                SmtpClient smtpClient = new SmtpClient();
                MailMessage message = new MailMessage();

                MailAddress fromAddres = new MailAddress("info@ctrade.co.zw", "Test");
                message.From = fromAddres;
                // To address collection of MailAddress
                message.To.Add("makazatinashe2000@gmail.com");
                message.Subject = Subject;
                smtpClient.Host = "192.168.3.241";
                smtpClient.UseDefaultCredentials = true;
                smtpClient.Credentials = new System.Net.NetworkCredential("info@ctrade.co.zw", "asdfghjkl2017");
                message.IsBodyHtml = true;
                // Message body content
                message.Body = Message;

                smtpClient.Send(message);

                retVal = true;
                message.Dispose();
                return "Message Sent";
            }
            catch (Exception ex)
            {
                return "Error " + ex;
            }

        }

        public string sendmail(string emailAdd, string subject, string emailbody)
        {
            try
            {
                SmtpClient client = new SmtpClient();
                client.Port = 587;
                client.Host = "smtp.gmail.com";
                //client.Host = "smtp.office365.com";
                client.EnableSsl = true;
                ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                client.Timeout = 30000;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new System.Net.NetworkCredential("escrowctrade@gmail.com", "asdfghjkl2017");
                //client.Credentials = new System.Net.NetworkCredential("info@ctrade.co.zw", "asdfghjkl.2017");
                MailMessage mm = new MailMessage();
                mm.BodyEncoding = Encoding.UTF8;
                mm.From = new MailAddress("info@ctrade.co.zw");
                mm.To.Add(emailAdd);
                mm.Subject = subject;
                mm.Body = emailbody;
                mm.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;

                client.Send(mm);

                return "1";
            }
            catch (Exception e)
            {
                return "0";
            }
        }

        public void SendMail2(string emailAddess, string message, string subject)
        {
            try
            {
                SmtpClient client = new SmtpClient();
                client.Port = 587;
                client.Host = "smtp.gmail.com";
                client.EnableSsl = true;
                ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                client.Timeout = 10000;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new System.Net.NetworkCredential("makazatinashe2000@gmail.com", "Lockthemout@2017");

                MailMessage mm = new MailMessage();
                mm.BodyEncoding = Encoding.UTF8;
                mm.From = new MailAddress("makazatinashe2000@gmail.com");
                mm.To.Add(emailAddess);
                mm.Subject = subject;
                mm.Body = message;
                mm.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;

                client.Send(mm);
                //                return "1";
            }
            catch (Exception e)
            {
                //                return e.ToString();
            }
        }
        public JsonResult CashTrans(string cdsNumber = null)
        {
            var ret = _cdscDbContext.CashTrans.Where(x => x.CDS_Number.Trim() == cdsNumber.Trim()).OrderByDescending(x => x.ID).Select(v => new
            {
                id = v.ID,
                desc = v.Description,
                type = v.TransType,
                ammount = v.Amount,
                date = v.DateCreated,
                status = v.TransStatus
            });
            List<CashTranss> my = new List<CashTranss>();
            foreach (var p in ret)
            {
                my.Add(new CashTranss() { id = p.id.ToString(), desc = p.desc, type = p.type, ammount = p.ammount, date = p.date.ToString("dd MMM yyyy"), status = p.status });
            }

            return Json(my, JsonRequestBehavior.AllowGet);
        }




        public JsonResult getCashBalance(string cdsNumber = null)
        {
            var CashBalancc = new List<CashBalancV2>();
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var ComptotalAccount = 0.00;
            var sql = @"
                    SELECT
                  isnull(SUM(totAllShares * currePrice), 0) as MyPotValue,
                  isnull(SUM(totAllShares * PrevPrice), 0) as MyPrevPotValue,
                  ISNULL(SUM((totAllShares * currePrice) - (prevdayQuantity *PrevPrice) ),0) AS MyProfitLoss,
                  (select isnull(sum(Amount), 0) from [CDSC].[dbo].CashTrans where CDS_Number = '" + cdsNumber + @"' ) as CashBal , 
                   (select isnull(sum(Amount), 0) from [CDSC].[dbo].CashTrans where CDS_Number = '" + cdsNumber + @"' and [TransStatus] = '1'  and TransType='SELL') as VirtCashBal ,
                   (select isnull(sum(Amount), 0)-(SELECT  isnull(SUM(AMOUNT),0) FROM CDSC.DBO.CashTrans  WHERE CDS_NUMBER='" + cdsNumber + @"' AND TransType='SELL' and TransStatus='1') from [CDSC].[dbo].CashTrans where CDS_Number = '" + cdsNumber + @"' ) as ActualCashBal
                  FROM [CDSC].[dbo].[PortfolioAll] WHERE CDS_NUMBER = '" + cdsNumber + @"'
                ";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                var ix = 1;
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    CashBalancV2 recordSummary = new CashBalancV2();
                    recordSummary.id = ix.ToString();
                    recordSummary.CashBal = Force2DecimalPlaces(rdr["CashBal"].ToString());
                    recordSummary.VirtCashBal = Force2DecimalPlaces(rdr["VirtCashBal"].ToString());
                    recordSummary.ActualCashBal = Force2DecimalPlaces(rdr["ActualCashBal"].ToString());
                    recordSummary.MyPotValue = Force4DecimalPlaces(rdr["MyPotValue"].ToString());
                    recordSummary.MyProfitLoss = Force4DecimalPlaces(rdr["MyProfitLoss"].ToString());
                    recordSummary.MyPrevPotValue = Force4DecimalPlaces(rdr["MyPrevPotValue"].ToString());
                    ComptotalAccount = double.Parse(rdr["CashBal"].ToString()) + double.Parse(rdr["MyPotValue"].ToString());
                    recordSummary.totalAccount = Force4DecimalPlaces(ComptotalAccount.ToString());
                    CashBalancc.Add(recordSummary);
                }
            }
            return Json(CashBalancc, JsonRequestBehavior.AllowGet);
        }


        public JsonResult getCashBalanceAsMember(string ccdsNumber = null, string mcdsNumber = null)
        {
            var CashBalancc = new List<CashBalancV2>();
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var ComptotalAccount = 0.00;
            var sql = "declare @ccdsnumber nvarchar(max) = '"+ccdsNumber+"', @mcdsnumber nvarchar(max) = '"+mcdsNumber+ "' SELECT isnull(SUM(totAllShares * currePrice), 0) as MyPotValue,isnull(SUM(totAllShares * PrevPrice), 0) as MyPrevPotValue, ISNULL(SUM((totAllShares * currePrice) - (prevdayQuantity *PrevPrice) ),0) AS MyProfitLoss, (select isnull(sum(Amount), 0) from [CDSC].[dbo].CashTransgroups where CDS_Number = @mcdsnumber and CDS_NumberGroup= @ccdsnumber ) as CashBal , (select isnull(sum(Amount), 0) from [CDSC].[dbo].CashTransgroups where CDS_Number = @mcdsnumber and CDS_NumberGroup=@ccdsnumber and [TransStatus] = '1' and TransType='SELL' ) as VirtCashBal , (select isnull(sum(Amount), 0)-(SELECT isnull(SUM(AMOUNT),0) FROM CDSC.DBO.CashTransgroups WHERE CDS_NUMBER=@mcdsnumber and CDS_NumberGroup=@ccdsnumber AND TransType='SELL' and TransStatus='1') from [CDSC].[dbo].CashTransgroups where CDS_Number = @mcdsnumber and CDS_NumberGroup=@ccdsnumber ) as ActualCashBal FROM [CDSC].[dbo].[PortfolioAll_clubs] WHERE CDS_NUMBER = @mcdsnumber";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                var ix = 1;
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    CashBalancV2 recordSummary = new CashBalancV2();
                    recordSummary.id = ix.ToString();
                    recordSummary.CashBal = Force2DecimalPlaces(rdr["CashBal"].ToString());
                    recordSummary.VirtCashBal = Force2DecimalPlaces(rdr["VirtCashBal"].ToString());
                    recordSummary.ActualCashBal = Force2DecimalPlaces(rdr["ActualCashBal"].ToString());
                    recordSummary.MyPotValue = Force4DecimalPlaces(rdr["MyPotValue"].ToString());
                    recordSummary.MyProfitLoss = Force4DecimalPlaces(rdr["MyProfitLoss"].ToString());
                    recordSummary.MyPrevPotValue = Force4DecimalPlaces(rdr["MyPrevPotValue"].ToString());
                    ComptotalAccount = double.Parse(rdr["CashBal"].ToString()) + double.Parse(rdr["MyPotValue"].ToString());
                    recordSummary.totalAccount = Force4DecimalPlaces(ComptotalAccount.ToString());
                    CashBalancc.Add(recordSummary);
                }
            }
            return Json(CashBalancc, JsonRequestBehavior.AllowGet);
        }

        public JsonResult getCashBalanceForex(string cdsNumber = null)
        {
            var CashBalancc = new List<CashBalancV22>();
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var ComptotalAccount = 0.00;
            var sql = @" select isnull(sum(Amount), 0) as ActualCashBal from [CDSC].[dbo].CashTrans_forex where CDS_Number = '" + cdsNumber + @"' and [TransStatus] = '1' ";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                var ix = 1;
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    CashBalancV22 recordSummary = new CashBalancV22();
                    recordSummary.ActualCashBal = Force2DecimalPlaces(rdr["ActualCashBal"].ToString());
                    CashBalancc.Add(recordSummary);
                }
            }
            return Json(CashBalancc, JsonRequestBehavior.AllowGet);
        }
        public JsonResult MarketWatchbidoffer()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcherNeww = new List<MarketWatchNeww>();

            //var sql = "SELECT * FROM [testcds_ROUTER].[dbo].[MarketWatch]";
            var sql = "SELECT a.*, b.fnam as full_company_name FROM [testcds_ROUTER].[dbo].[MarketWatch] a, testcds_ROUTER.dbo.para_company b WHERE a.company = b.Company";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatchNeww recordSummary = new MarketWatchNeww();
                    recordSummary.market_company = rdr["company"].ToString();
                    recordSummary.market_bbv = rdr["Volume"].ToString();
                    recordSummary.market_bp = Force4DecimalPlaces(rdr["Bid"].ToString());
                    recordSummary.market_va = rdr["Volume Sell"].ToString();
                    recordSummary.market_ap = Force4DecimalPlaces(rdr["Ask"].ToString());
                    recordSummary.market_vwap = Force4DecimalPlaces(rdr["Average Price"].ToString());
                    recordSummary.market_lp = Force4DecimalPlaces(rdr["Lastmatched"].ToString());
                    recordSummary.market_lv = rdr["lastvolume"].ToString();
                    recordSummary.market_tv = rdr["TotalVolume"].ToString();
                    recordSummary.market_to = Force4DecimalPlaces(rdr["Turnover"].ToString());
                    recordSummary.market_open = Force4DecimalPlaces(rdr["Open"].ToString());
                    recordSummary.market_high = Force4DecimalPlaces(rdr["High"].ToString());
                    recordSummary.market_low = Force4DecimalPlaces(rdr["Low"].ToString());
                    recordSummary.market_change = Force4DecimalPlaces(rdr["Change"].ToString());
                    recordSummary.market_per_change = Force4DecimalPlaces(Math.Round(double.Parse(rdr["percchange"].ToString()), 4).ToString());
                    recordSummary.details = rdr["company"].ToString();
                    recordSummary.FullCompanyName = rdr["full_company_name"].ToString();
                    recordSummary.Category = rdr["Category"].ToString();
                    //get bids
                    var retBids = _AtsDbContext.LiveTradingMasters.OrderByDescending(y => y.BasePrice).Where(x => x.OrderType == "BUY" && x.Company == recordSummary.market_company).Select(v => new
                    {
                        idd = v.OrderNo,
                        volumed = v.Quantity,
                        priced = v.BasePrice
                    });
                    var bidPriceser = new List<bidPrices_correct>();

                    foreach (var p in retBids)
                    {
                        bidPrices_correct recordSum1 = new bidPrices_correct();
                        recordSum1.id = p.idd.ToString();
                        recordSum1.price = Force4DecimalPlaces(p.priced.ToString());
                        recordSum1.volume = p.volumed.ToString();
                        bidPriceser.Add(recordSum1);
                        recordSummary.bids = bidPriceser;
                    }


                    //get bids

                    //get offers
                    var retOffers = _AtsDbContext.LiveTradingMasters.OrderBy(y => y.BasePrice).Where(x => x.OrderType == "SELL" && x.Company == recordSummary.market_company).Select(v => new
                    {
                        ido = v.OrderNo,
                        volumeo = v.Quantity,
                        priceo = v.BasePrice
                    });
                    var offerPriceser = new List<offerPrices>();

                    foreach (var p in retOffers)
                    {
                        offerPrices recordSum2 = new offerPrices();
                        recordSum2.id = p.ido.ToString();
                        recordSum2.price = Force4DecimalPlaces(p.priceo.ToString());
                        recordSum2.volume = p.volumeo.ToString();
                        offerPriceser.Add(recordSum2);
                        recordSummary.asks = offerPriceser;
                    }


                    //get offers

                    marketWatcherNeww.Add(recordSummary);
                }
            }
            return Json(marketWatcherNeww, JsonRequestBehavior.AllowGet);
        }

        public JsonResult MarketWatchByCategory(string category)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
            var marketWatcherNeww = new List<MarketWatchNeww>();

            //var sql = "SELECT * FROM [testcds_ROUTER].[dbo].[MarketWatch]";
            var sql = "SELECT a.*, b.fnam as full_company_name FROM [testcds_ROUTER].[dbo].[MarketWatch] a, testcds_ROUTER.dbo.para_company b WHERE a.company = b.Company and a.category ='" + category + "'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MarketWatchNeww recordSummary = new MarketWatchNeww();
                    recordSummary.market_company = rdr["company"].ToString();
                    recordSummary.market_bbv = rdr["Volume"].ToString();
                    recordSummary.market_bp = Force4DecimalPlaces(rdr["Bid"].ToString());
                    recordSummary.market_va = rdr["Volume Sell"].ToString();
                    recordSummary.market_ap = Force4DecimalPlaces(rdr["Ask"].ToString());
                    recordSummary.market_vwap = Force4DecimalPlaces(rdr["Average Price"].ToString());
                    recordSummary.market_lp = Force4DecimalPlaces(rdr["Lastmatched"].ToString());
                    recordSummary.market_lv = rdr["lastvolume"].ToString();
                    recordSummary.market_tv = rdr["TotalVolume"].ToString();
                    recordSummary.market_to = Force4DecimalPlaces(rdr["Turnover"].ToString());
                    recordSummary.market_open = Force4DecimalPlaces(rdr["Open"].ToString());
                    recordSummary.market_high = Force4DecimalPlaces(rdr["High"].ToString());
                    recordSummary.market_low = Force4DecimalPlaces(rdr["Low"].ToString());
                    recordSummary.market_change = Force4DecimalPlaces(rdr["Change"].ToString());
                    recordSummary.market_per_change = Force4DecimalPlaces(Math.Round(double.Parse(rdr["percchange"].ToString()), 4).ToString());
                    recordSummary.details = rdr["company"].ToString();
                    recordSummary.FullCompanyName = rdr["full_company_name"].ToString();
                    recordSummary.Category = rdr["Category"].ToString();
                    //get bids
                    var retBids = _AtsDbContext.LiveTradingMasters.OrderByDescending(y => y.BasePrice).Where(x => x.OrderType == "BUY" && x.Company == recordSummary.market_company).Select(v => new
                    {
                        idd = v.OrderNo,
                        volumed = v.Quantity,
                        priced = v.BasePrice
                    });
                    var bidPriceser = new List<bidPrices_correct>();

                    foreach (var p in retBids)
                    {
                        bidPrices_correct recordSum1 = new bidPrices_correct();
                        recordSum1.id = p.idd.ToString();
                        recordSum1.price = Force4DecimalPlaces(p.priced.ToString());
                        recordSum1.volume = p.volumed.ToString();
                        bidPriceser.Add(recordSum1);
                        recordSummary.bids = bidPriceser;
                    }


                    //get bids

                    //get offers
                    var retOffers = _AtsDbContext.LiveTradingMasters.OrderBy(y => y.BasePrice).Where(x => x.OrderType == "SELL" && x.Company == recordSummary.market_company).Select(v => new
                    {
                        ido = v.OrderNo,
                        volumeo = v.Quantity,
                        priceo = v.BasePrice
                    });
                    var offerPriceser = new List<offerPrices>();

                    foreach (var p in retOffers)
                    {
                        offerPrices recordSum2 = new offerPrices();
                        recordSum2.id = p.ido.ToString();
                        recordSum2.price = Force4DecimalPlaces(p.priceo.ToString());
                        recordSum2.volume = p.volumeo.ToString();
                        offerPriceser.Add(recordSum2);
                        recordSummary.asks = offerPriceser;
                    }


                    //get offers

                    marketWatcherNeww.Add(recordSummary);
                }
            }
            return Json(marketWatcherNeww, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getIPOISSUES()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var para_hold = new List<para_holding>();

            var sql = "SELECT * FROM para_holding WHERE IPOSTATUS = '0' ORDER BY ID_ DESC";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    para_holding recordSummary = new para_holding();

                    recordSummary.Category = rdr["Category"].ToString();
                    recordSummary.Issuer_Code = rdr["Issuer_Code"].ToString();
                    recordSummary.Debt_Type = rdr["Debt_Type"].ToString();
                    recordSummary.Security_Description = rdr["Security_Description"].ToString();
                    recordSummary.GlobalLimit = Decimal.Parse(rdr["GlobalLimit"].ToString());
                    recordSummary.IndividualLimit = Decimal.Parse(rdr["IndividualLimit"].ToString());
                    recordSummary.DailyLimit = Decimal.Parse(rdr["DailyLimit"].ToString());
                    recordSummary.BidRatio = Decimal.Parse(rdr["BidRatio"].ToString());
                    recordSummary.IPOSTATUS = int.Parse(rdr["IPOSTATUS"].ToString());
                    recordSummary.globLowerlimit = Decimal.Parse(rdr["globLowerlimit"].ToString());
                    recordSummary.InterestRate = Decimal.Parse(rdr["InterestRate"].ToString());
                    //recordSummary.IPOClosedDate = DateTime.Parse(rdr["IPOClosedDate"].ToString());
                    //recordSummary.Transaction_Limit = Decimal.Parse(rdr["Transaction_Limit"].ToString());
                    //recordSummary.firstlimit = Decimal.Parse(rdr["FirstLimit"].ToString());
                    //recordSummary.multiples = Decimal.Parse(rdr["Multiples"].ToString());
                    para_hold.Add(recordSummary);
                }
            }
            return Json(para_hold, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetMyOrders(string cdsNumber = null)
        {
            // var retID = 0;
            var rets = _AtsDbContext.Pre_Order_Live.Where(x => x.CDS_AC_No == cdsNumber.Trim()).OrderByDescending(x => x.OrderNo).Select(c => new
            {
                //id = retID+1,
                id = c.OrderNo,
                counter = c.Company,
                type = c.OrderType,
                volume = c.Quantity.ToString(),
                price = c.BasePrice.ToString(),
                date_ = c.Create_date.ToString(),
                status = c.OrderStatus,
                desc = c.trading_platform + " - " + c.Broker_Code
            });
            List<Pre_Order_Lives> my = new List<Pre_Order_Lives>();
            foreach (var p in rets)
            {
                my.Add(new Pre_Order_Lives() { date = p.date_, id = p.id.ToString(), counter = p.counter.ToString(), type = p.type.ToString(), volume = p.volume.ToString(), price = p.price.ToString(), status = p.status.ToString(), desc = p.desc.ToString() });
            }
            return Json(my, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetMyOrders1(string cdsNumber = null)
        {
            // var retID = 0;
            var order = (from c in _AtsDbContext.Pre_Order_Live.Where(x => x.CDS_AC_No == cdsNumber.Trim())
                         join t in _AtsDbContext.para_company on c.Company equals t.Company
                         let companyFullName = t.fnam
                         let id = c.OrderNo
                         let counter = c.Company
                         let type = c.OrderType
                         let volume = c.Quantity.ToString()
                         let price = c.BasePrice.ToString()
                         let date_ = c.Create_date.ToString()
                         let status = c.OrderStatus
                         let desc = c.trading_platform + " - " + c.Broker_Code
                         let ordernumber = c.OrderNumber
                         select new
                         {
                             id,
                             companyFullName,
                             counter,
                             type,
                             volume,
                             price,
                             date_,
                             status,
                             desc,
                             ordernumber,
                         }).ToList().OrderByDescending(a => a.id);

            List<Pre_Order_Lives> my = new List<Pre_Order_Lives>();
            foreach (var p in order)
            {
                my.Add(new Pre_Order_Lives() { date = p.date_, id = p.id.ToString(), counter = p.counter.ToString(), type = p.type.ToString(), volume = p.volume.ToString(), price = p.price.ToString(), status = p.status.ToString(), desc = p.desc.ToString(), fullname = p.companyFullName.ToString(), ordernumber = p.ordernumber.ToString() });
            }
            //my = my.OrderByDescending(a => a.id).ToList();
            return Json(my, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetMyIPOOrders(string cdsNumber = null)
        {
            // var retID = 0;
            var rets = _cdscDbContext.PreOrderLivesIPOes.Where(x => x.CDS_AC_No == cdsNumber.Trim()).OrderByDescending(x => x.ID).Select(c => new
            {
                //id = retID+1,
                id = c.ID,
                counter = c.Company,
                type = c.OrderType,
                volume = c.Quantity.ToString(),
                price = c.BasePrice.ToString(),
                date = c.Create_date,
                status = c.OrderStatus,
                desc = c.Source + " - " + c.Broker_Code
            });
            List<PreOrderLivesIPOTest> my = new List<PreOrderLivesIPOTest>();
            foreach (var p in rets)
            {
                my.Add(new PreOrderLivesIPOTest() { id = p.id.ToString(), counter = p.counter.ToString(), type = p.type.ToString(), volume = p.volume.ToString(), price = p.price.ToString(), date = p.date.ToString("dd MMM yyyy"), status = p.status.ToString(), desc = p.desc.ToString() });
            }
            return Json(my, JsonRequestBehavior.AllowGet);
        }
        public decimal getTransPrice(decimal transID)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            decimal pricee = 0;
            var sql = "SELECT ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = a.Reference) AND (Account1 = a.CDS_Number)) OR ((ReportID = a.Reference) AND (Account2 = a.CDS_Number))),0) AS THEPRICE FROM CDS_ROUTER.DBO.trans A  WHERE A.Trans_ID='" + transID + "'";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    pricee = decimal.Parse(rdr["THEPRICE"].ToString());
                }
            }
            return pricee;
        }
        public JsonResult getMyPortFolioOriginal(string cdsNumber = null)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var myPortf = new List<MyPortfolio>();

            var sql = "select * from cdsc.dbo.MyportfolioAll d where d.CDS_Number='" + cdsNumber + "'";
            var ix = 1;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MyPortfolio recordSummary = new MyPortfolio();
                    recordSummary.id = ix.ToString();
                    recordSummary.counter = rdr["Company"].ToString();
                    recordSummary.numbershares = rdr["totAllShares"].ToString();
                    recordSummary.lastactivitydate = rdr["LastAcDate"].ToString();
                    recordSummary.currentprice = Force4DecimalPlaces(rdr["currePrice"].ToString());
                    recordSummary.prevprice = Force4DecimalPlaces(rdr["PrevPrice"].ToString());
                    recordSummary.totalportvalue = Force4DecimalPlaces(rdr["TotPottValue"].ToString());
                    recordSummary.totalPrevPortValue = Force4DecimalPlaces(Math.Round((double.Parse(rdr["PrevPrice"].ToString()) * double.Parse(rdr["totAllShares"].ToString())), 4).ToString());

                    recordSummary.returns = Force4DecimalPlaces(Math.Round(double.Parse(rdr["totReturnValue"].ToString()), 4).ToString());
                    //get my buys
                    ////var retBids = _cdDataContext.trans.Where(x => x.CDS_Number == cdsNumber.ToString() && x.Shares > 0 && x.Company == recordSummary.counter).Select(v => new
                    ////{
                    ////    comp = v.Company,
                    ////    volum = v.Shares,
                    ////    pric = v.Shares,
                    ////    totVal = v.Shares
                    ////});
                    var BuysBymes = new List<BuysByme>();
                    var sql2 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares>0";
                    using (SqlConnection connection2 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd2 = new SqlCommand(sql2, connection2);
                        cmd2.CommandType = CommandType.Text;
                        connection2.Open();
                        SqlDataReader rdr2 = cmd2.ExecuteReader();
                        while (rdr2.Read())
                        {
                            BuysByme recordSum1 = new BuysByme();
                            recordSum1.company = rdr2["Company"].ToString();
                            recordSum1.volume = rdr2["Shares"].ToString();
                            recordSum1.price = Force4DecimalPlaces(rdr2["TradePrice"].ToString());
                            recordSum1.totalValue = Force4DecimalPlaces((decimal.Parse(rdr2["TradePrice"].ToString()) * decimal.Parse(rdr2["Shares"].ToString())).ToString());
                            BuysBymes.Add(recordSum1);
                        }
                    }
                    // foreach (var p in retBids)
                    //{

                    //}
                    recordSummary.BuyDetail = BuysBymes;
                    //get my buys

                    //get my sells
                    //var retOffers = _cdDataContext.trans.Where(x => x.CDS_Number == cdsNumber.ToString() && x.Shares < 0 && x.Company == recordSummary.counter).Select(v => new
                    //{
                    //    comp = v.Company,
                    //    volum = v.Shares,
                    //    pric = v.Shares,
                    //    totVal = v.Shares
                    //});
                    //var sellBymes = new List<SellsByme>();

                    //foreach (var p in retOffers)
                    //{
                    //    SellsByme recordSum2 = new SellsByme();
                    //    recordSum2.company = p.comp.ToString();
                    //    recordSum2.volume = p.volum.ToString();
                    //    recordSum2.price = p.pric.ToString();
                    //    recordSum2.totalValue = p.totVal.ToString();
                    //    sellBymes.Add(recordSum2);
                    //}
                    var sellBymes = new List<SellsByme>();
                    var sql3 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares<0";
                    using (SqlConnection connection3 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd3 = new SqlCommand(sql3, connection3);
                        cmd3.CommandType = CommandType.Text;
                        connection3.Open();
                        SqlDataReader rdr3 = cmd3.ExecuteReader();
                        while (rdr3.Read())
                        {
                            SellsByme recordSum2 = new SellsByme();
                            recordSum2.company = rdr3["Company"].ToString();
                            recordSum2.volume = rdr3["Shares"].ToString();
                            recordSum2.price = Force4DecimalPlaces(rdr3["TradePrice"].ToString());
                            recordSum2.totalValue = Force4DecimalPlaces((decimal.Parse(rdr3["TradePrice"].ToString()) * decimal.Parse(rdr3["Shares"].ToString())).ToString());
                            sellBymes.Add(recordSum2);
                        }
                    }
                    recordSummary.SellDetail = sellBymes;
                    //get my sells

                    myPortf.Add(recordSummary);
                    ix = ix + 1;
                }
            }
            return Json(myPortf, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getMyPortFolioNew(string cdsNumber = null)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var myPortf = new List<MyPortfolioNew>();

            //var sql = "select  from cdsc.dbo.PortfolioAll d where d.CDS_Number='" + cdsNumber + "'";

            var sql = "select d.*, ut.fnam as fullCompanyName from cdsc.dbo.PortfolioAll d,testcds_ROUTER.dbo.para_company ut  where d.CDS_Number='" + cdsNumber + "' and d.Company = ut.Company";
            var ix = 1;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //Company CDS_Number  LastAcDate totAllShares    prevdayQuantity currePrice  PrevPrice Uncleared   Net
                    //prev_numbershares
                    MyPortfolioNew recordSummary = new MyPortfolioNew();
                    string curr_Port = Force4DecimalPlaces(Math.Round((double.Parse(rdr["currePrice"].ToString()) * double.Parse(rdr["totAllShares"].ToString())), 4).ToString());
                    string prev_Port = Force4DecimalPlaces(Math.Round((double.Parse(rdr["PrevPrice"].ToString()) * double.Parse(rdr["prevdayQuantity"].ToString())), 4).ToString());
                    double ret_Port = Math.Round(double.Parse(curr_Port), 4) - Math.Round(double.Parse(prev_Port), 4);
                    recordSummary.id = ix.ToString();
                    recordSummary.counter = rdr["Company"].ToString();
                    recordSummary.numbershares = rdr["totAllShares"].ToString();
                    recordSummary.prev_numbershares = rdr["prevdayQuantity"].ToString();
                    recordSummary.lastactivitydate = rdr["LastAcDate"].ToString();
                    recordSummary.currentprice = Force4DecimalPlaces(rdr["currePrice"].ToString());
                    recordSummary.prevprice = Force4DecimalPlaces(rdr["PrevPrice"].ToString());
                    recordSummary.totalportvalue = curr_Port;
                    recordSummary.totalPrevPortValue = prev_Port;
                    recordSummary.returns = Force4DecimalPlaces(ret_Port.ToString());
                    recordSummary.uncleared = Force4DecimalPlaces(rdr["Uncleared"].ToString());
                    recordSummary.net = Force4DecimalPlaces(rdr["Net"].ToString());
                    recordSummary.companyFullName = rdr["fullCompanyName"].ToString();

                    var BuysBymes = new List<BuysByme>();
                    var sql2 = "select ,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares>0";
                    using (SqlConnection connection2 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd2 = new SqlCommand(sql2, connection2);
                        cmd2.CommandType = CommandType.Text;
                        connection2.Open();
                        SqlDataReader rdr2 = cmd2.ExecuteReader();
                        while (rdr2.Read())
                        {
                            BuysByme recordSum1 = new BuysByme();
                            recordSum1.company = rdr2["Company"].ToString();
                            recordSum1.volume = rdr2["Shares"].ToString();
                            recordSum1.price = Force4DecimalPlaces(rdr2["TradePrice"].ToString());
                            recordSum1.totalValue = Force4DecimalPlaces((decimal.Parse(rdr2["TradePrice"].ToString()) * decimal.Parse(rdr2["Shares"].ToString())).ToString());
                            BuysBymes.Add(recordSum1);
                        }
                    }
                    recordSummary.BuyDetail = BuysBymes;
                    var sellBymes = new List<SellsByme>();
                    var sql3 = "select ,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares<0";
                    using (SqlConnection connection3 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd3 = new SqlCommand(sql3, connection3);
                        cmd3.CommandType = CommandType.Text;
                        connection3.Open();
                        SqlDataReader rdr3 = cmd3.ExecuteReader();
                        while (rdr3.Read())
                        {
                            SellsByme recordSum2 = new SellsByme();
                            recordSum2.company = rdr3["Company"].ToString();
                            recordSum2.volume = rdr3["Shares"].ToString();
                            recordSum2.price = Force4DecimalPlaces(rdr3["TradePrice"].ToString());
                            recordSum2.totalValue = Force4DecimalPlaces((decimal.Parse(rdr3["TradePrice"].ToString()) * decimal.Parse(rdr3["Shares"].ToString())).ToString());
                            sellBymes.Add(recordSum2);
                        }
                    }
                    recordSummary.SellDetail = sellBymes;
                    //get my sells

                    myPortf.Add(recordSummary);
                    ix = ix + 1;
                }
            }
            return Json(myPortf, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getMyPortFolio(string cdsNumber = null)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var myPortf = new List<MyPortfolioNew>();

            var sql = "select d.*, ut.fnam as fullCompanyName from cdsc.dbo.PortfolioAll d,testcds_ROUTER.dbo.para_company ut  where d.CDS_Number='" + cdsNumber + "' and d.Company = ut.Company";
            var ix = 1;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MyPortfolioNew recordSummary = new MyPortfolioNew();
                    string curr_Port = Force4DecimalPlaces(Math.Round((double.Parse(rdr["currePrice"].ToString()) * double.Parse(rdr["totAllShares"].ToString())), 4).ToString());
                    string prev_Port = Force4DecimalPlaces(Math.Round((double.Parse(rdr["PrevPrice"].ToString()) * double.Parse(rdr["prevdayQuantity"].ToString())), 4).ToString());
                    double ret_Port = Math.Round(double.Parse(curr_Port), 4) - Math.Round(double.Parse(prev_Port), 4);
                    recordSummary.id = ix.ToString();
                    recordSummary.counter = rdr["Company"].ToString();
                    recordSummary.numbershares = rdr["totAllShares"].ToString();
                    recordSummary.prev_numbershares = rdr["prevdayQuantity"].ToString();
                    recordSummary.lastactivitydate = rdr["LastAcDate"].ToString();
                    recordSummary.currentprice = Force4DecimalPlaces(rdr["currePrice"].ToString());
                    recordSummary.prevprice = Force4DecimalPlaces(rdr["PrevPrice"].ToString());
                    recordSummary.totalportvalue = curr_Port;
                    recordSummary.totalPrevPortValue = prev_Port;
                    recordSummary.returns = Force4DecimalPlaces(ret_Port.ToString());
                    recordSummary.uncleared = Force4DecimalPlaces(rdr["Uncleared"].ToString());
                    recordSummary.net = Force4DecimalPlaces(rdr["Net"].ToString());
                    recordSummary.companyFullName = rdr["fullCompanyName"].ToString();



                    var BuysBymes = new List<BuysByme>();
                    var sql2 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares>0";
                    using (SqlConnection connection2 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd2 = new SqlCommand(sql2, connection2);
                        cmd2.CommandType = CommandType.Text;
                        connection2.Open();
                        SqlDataReader rdr2 = cmd2.ExecuteReader();
                        while (rdr2.Read())
                        {
                            BuysByme recordSum1 = new BuysByme();
                            recordSum1.company = rdr2["Company"].ToString();
                            recordSum1.volume = rdr2["Shares"].ToString();
                            recordSum1.price = Force4DecimalPlaces(rdr2["TradePrice"].ToString());
                            recordSum1.totalValue = Force4DecimalPlaces((decimal.Parse(rdr2["TradePrice"].ToString()) * decimal.Parse(rdr2["Shares"].ToString())).ToString());
                            BuysBymes.Add(recordSum1);
                        }
                    }
                    // foreach (var p in retBids)
                    //{

                    //}
                    recordSummary.BuyDetail = BuysBymes;
                    //get my buys

                    //get my sells
                    //var retOffers = _cdDataContext.trans.Where(x => x.CDS_Number == cdsNumber.ToString() && x.Shares < 0 && x.Company == recordSummary.counter).Select(v => new
                    //{
                    //    comp = v.Company,
                    //    volum = v.Shares,
                    //    pric = v.Shares,
                    //    totVal = v.Shares
                    //});
                    //var sellBymes = new List<SellsByme>();

                    //foreach (var p in retOffers)
                    //{
                    //    SellsByme recordSum2 = new SellsByme();
                    //    recordSum2.company = p.comp.ToString();
                    //    recordSum2.volume = p.volum.ToString();
                    //    recordSum2.price = p.pric.ToString();
                    //    recordSum2.totalValue = p.totVal.ToString();
                    //    sellBymes.Add(recordSum2);
                    //}
                    var sellBymes = new List<SellsByme>();
                    var sql3 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares<0";
                    using (SqlConnection connection3 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd3 = new SqlCommand(sql3, connection3);
                        cmd3.CommandType = CommandType.Text;
                        connection3.Open();
                        SqlDataReader rdr3 = cmd3.ExecuteReader();
                        while (rdr3.Read())
                        {
                            SellsByme recordSum2 = new SellsByme();
                            recordSum2.company = rdr3["Company"].ToString();
                            recordSum2.volume = rdr3["Shares"].ToString();
                            recordSum2.price = Force4DecimalPlaces(rdr3["TradePrice"].ToString());
                            recordSum2.totalValue = Force4DecimalPlaces((decimal.Parse(rdr3["TradePrice"].ToString()) * decimal.Parse(rdr3["Shares"].ToString())).ToString());
                            sellBymes.Add(recordSum2);
                        }
                    }
                    recordSummary.SellDetail = sellBymes;
                    //get my sells

                    myPortf.Add(recordSummary);
                    ix = ix + 1;
                }
            }
            return Json(myPortf, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getMyPortFolio1(string cdsNumber = null)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var myPortf = new List<MyPortfolio>();

            var sql = "select d.*, ut.fnam as fullCompanyName from cdsc.dbo.MyportfolioAll d,testcds_ROUTER.dbo.para_company ut  where d.CDS_Number='" + cdsNumber + "' and d.Company = ut.Company";
            var ix = 1;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MyPortfolio recordSummary = new MyPortfolio();
                    recordSummary.id = ix.ToString();
                    recordSummary.counter = rdr["Company"].ToString();
                    recordSummary.numbershares = rdr["totAllShares"].ToString();
                    recordSummary.lastactivitydate = rdr["LastAcDate"].ToString();
                    recordSummary.currentprice = Force4DecimalPlaces(rdr["currePrice"].ToString());
                    recordSummary.prevprice = Force4DecimalPlaces(rdr["PrevPrice"].ToString());
                    recordSummary.totalportvalue = Force4DecimalPlaces(rdr["TotPottValue"].ToString());
                    recordSummary.uncleared = Force4DecimalPlaces(rdr["Uncleared"].ToString());
                    recordSummary.net = Force4DecimalPlaces(rdr["Net"].ToString());
                    recordSummary.totalPrevPortValue = Force4DecimalPlaces(Math.Round((double.Parse(rdr["PrevPrice"].ToString()) * double.Parse(rdr["totAllShares"].ToString())), 4).ToString());
                    recordSummary.companyFullName = rdr["fullCompanyName"].ToString();
                    recordSummary.returns = Force4DecimalPlaces(Math.Round(double.Parse(rdr["totReturnValue"].ToString()), 4).ToString());
                    //get my buys
                    ////var retBids = _cdDataContext.trans.Where(x => x.CDS_Number == cdsNumber.ToString() && x.Shares > 0 && x.Company == recordSummary.counter).Select(v => new
                    ////{
                    ////    comp = v.Company,
                    ////    volum = v.Shares,
                    ////    pric = v.Shares,
                    ////    totVal = v.Shares
                    ////});
                    var BuysBymes = new List<BuysByme>();
                    var sql2 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares>0";
                    using (SqlConnection connection2 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd2 = new SqlCommand(sql2, connection2);
                        cmd2.CommandType = CommandType.Text;
                        connection2.Open();
                        SqlDataReader rdr2 = cmd2.ExecuteReader();
                        while (rdr2.Read())
                        {
                            BuysByme recordSum1 = new BuysByme();
                            recordSum1.company = rdr2["Company"].ToString();
                            recordSum1.volume = rdr2["Shares"].ToString();
                            recordSum1.price = Force4DecimalPlaces(rdr2["TradePrice"].ToString());
                            recordSum1.totalValue = Force4DecimalPlaces((decimal.Parse(rdr2["TradePrice"].ToString()) * decimal.Parse(rdr2["Shares"].ToString())).ToString());
                            BuysBymes.Add(recordSum1);
                        }
                    }
                    // foreach (var p in retBids)
                    //{

                    //}
                    recordSummary.BuyDetail = BuysBymes;
                    //get my buys

                    //get my sells
                    //var retOffers = _cdDataContext.trans.Where(x => x.CDS_Number == cdsNumber.ToString() && x.Shares < 0 && x.Company == recordSummary.counter).Select(v => new
                    //{
                    //    comp = v.Company,
                    //    volum = v.Shares,
                    //    pric = v.Shares,
                    //    totVal = v.Shares
                    //});
                    //var sellBymes = new List<SellsByme>();

                    //foreach (var p in retOffers)
                    //{
                    //    SellsByme recordSum2 = new SellsByme();
                    //    recordSum2.company = p.comp.ToString();
                    //    recordSum2.volume = p.volum.ToString();
                    //    recordSum2.price = p.pric.ToString();
                    //    recordSum2.totalValue = p.totVal.ToString();
                    //    sellBymes.Add(recordSum2);
                    //}
                    var sellBymes = new List<SellsByme>();
                    var sql3 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares<0";
                    using (SqlConnection connection3 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd3 = new SqlCommand(sql3, connection3);
                        cmd3.CommandType = CommandType.Text;
                        connection3.Open();
                        SqlDataReader rdr3 = cmd3.ExecuteReader();
                        while (rdr3.Read())
                        {
                            SellsByme recordSum2 = new SellsByme();
                            recordSum2.company = rdr3["Company"].ToString();
                            recordSum2.volume = rdr3["Shares"].ToString();
                            recordSum2.price = Force4DecimalPlaces(rdr3["TradePrice"].ToString());
                            recordSum2.totalValue = Force4DecimalPlaces((decimal.Parse(rdr3["TradePrice"].ToString()) * decimal.Parse(rdr3["Shares"].ToString())).ToString());
                            sellBymes.Add(recordSum2);
                        }
                    }
                    recordSummary.SellDetail = sellBymes;
                    //get my sells

                    myPortf.Add(recordSummary);
                    ix = ix + 1;
                }
            }
            return Json(myPortf, JsonRequestBehavior.AllowGet);
        }
        public string getAccountFullname(string any = null)
        {
            var getBrk = "select ISNULL(ac.Surname,'') + ' ' + ISNULL(ac.Forenames,'') as fullName from [CDS_ROUTER].[dbo].Accounts_Clients ac where ac.CDS_Number='" + any + "'";
            var theFullName = "";
            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    theFullName = rdr["fullName"].ToString();
                }
                return theFullName;
            }
        }
        public JsonResult getPortfolioStatement(string cdsNumber = null, string company = null)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var myPortf = new List<MyPortStatement>();
            var addStr = "";
            if (company != null)
            {
                addStr = " and d.company='" + company + "'";
            }
            var sql = "select *,[DealShares]*[Average Price] as PurchaceValue,([Average Price]-[DEAL_PRICE])*[DealShares] as Returnss from cdsc.dbo.MyPortStatement d where d.CDS_Number='" + cdsNumber + "' " + addStr + "";
            var ix = 1;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MyPortStatement recordSummary = new MyPortStatement();
                    recordSummary.id = ix.ToString();
                    recordSummary.counter = rdr["Company"].ToString();
                    recordSummary.date = rdr["LastActDate"].ToString();
                    recordSummary.pricepershare = rdr["DEAL_PRICE"].ToString();
                    recordSummary.volume = rdr["DealShares"].ToString();
                    recordSummary.purchasevalue = rdr["PurchaceValue"].ToString();
                    recordSummary.currentmarketprice = rdr["Average Price"].ToString();
                    recordSummary.returns = rdr["Returnss"].ToString();

                    myPortf.Add(recordSummary);
                    ix = ix + 1;
                }
            }
            return Json(myPortf, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetGraphPrices(string company = null)
        {
            var rets = _AtsDbContext.CompanyLivePrices.Where(x => x.COMPANY == company.Trim()).OrderByDescending(x => x.id).Select(c => new
            {
                price = c.CurrentPrice,
                vol = c.ShareVOL
            }).Take(5);
            List<CompanyLivePricess> my = new List<CompanyLivePricess>();
            foreach (var p in rets)
            {
                my.Add(new CompanyLivePricess() { CurrentPrice = p.price.ToString(), currentVolume = p.vol.ToString() });
            }
            return Json(my, JsonRequestBehavior.AllowGet);
        }
        public string OrderPosting(string company, string security, string orderTrans,
          string orderType, string quantity, string price, string cdsNumber,
          string broker, string source)

        {
            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "";
            double basePrice = 0;
            var theOrderTrans = "";

            try
            {
                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }


                if (orderType != null && orderType.Equals("Market"))
                {
                    orderPref = "M";
                    basePrice = 0;
                }
                else
                {
                    basePrice = double.Parse(price);
                    orderPref = "L";
                }


                long orderNumber = 0;
                var myCompany = "";
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }

                var theCompnay =
                    atsDbContext.para_company.OrderByDescending(x => x.ID)
                        .Where(x => x.Company == company)
                        .FirstOrDefault(x => x.Company == company);

                if (theCompnay == null)
                {
                    return "Select a valid company";
                }

                myCompany = theCompnay.Company;
                var theCds = cdsNumber + "";

                //                var theBroker = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
                {
                    return "Enter CDS Number";
                }


                var theBroker1 = cdsDbContext.Client_Companies.FirstOrDefault(x => x.Company_Code == broker);
                if (theBroker1 == null)
                {
                    return "Enter valid broker";
                }


                decimal shares = 0;
                if (orderTrans.ToString().ToUpper().Equals("SELL"))
                {
                    var shareAvail =
                        cdsDbContext.trans.FirstOrDefault(x => x.CDS_Number == cdsNumber && x.Company == myCompany);

                    if (shareAvail != null)
                    {
                        var theShare =
                            cdsDbContext.trans.Where(x => x.CDS_Number == cdsNumber && x.Company == myCompany)
                                .Select(x => x.Shares)
                                .Sum();
                        if (theShare <= 0)
                        {
                            return "You have insufficient shares, check with your broker";
                        }
                        if (theShare < int.Parse(quantity))
                        {
                            return "You have insufficient shares, check with your broker";
                        }

                    }
                    else
                    {
                        return "You have insufficient shares, check with your broker";
                    }
                }


                //IF BUY ORDER
                var totalAmountToSpent = decimal.Parse(quantity) * decimal.Parse(price) * decimal.Parse("1.01693");


                if (orderTrans.ToString().ToUpper().Equals("BUY"))
                {
                    var moneyAvail =
                        tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                    if (moneyAvail != null)
                    {
                        var theCashBal =
                            tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                                .Select(x => x.Amount)
                                .Sum();
                        if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                        {
                            return "You have insufficient balance in your Cash account";
                        }
                    }
                    else
                    {
                        return "You have insufficient balance in your Cash account";
                    }
                }
                //SAVING TO DB


                var orderStatus = "OPEN";
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                var expiryDate = DateTime.Now;
                var theQuantity = 0;


                if (quantity != null)
                {
                    theQuantity = int.Parse(quantity);
                }


                var brokerCode = "";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = "Day Order (DO)";
                var orderQualifier = "None";
                //var brokerRef = theBroker1.Company_Code + "" + orderNumber;
                var contraBrokerId = "";
                var brokerRef = broker + orderNumber;
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "$";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                try
                {
                    var orderLive = new Pre_Order_Live
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        Client_Type = "",
                        Tax = 0,
                        Shareholder = cdsNumber,
                        ClientName = name,
                        TotalShareHolding = 0,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Deal_Begin_Date = dealBeginDate,
                        Expiry_Date = expiryDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        AvailableShares = 0,
                        OrderPref = orderPref,
                        OrderAttribute = orderAttrib,
                        Marketboard = marketBoard,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        ContraBrokerId = contraBrokerId,
                        MaxPrice = maxPrice,
                        MiniPrice = minPrice,
                        Flag_oldorder = flagOldOrder,
                        OrderNumber = orderNum,
                        Currency = currency,
                        trading_platform = GetTradingPlaform(myCompany),
                        FOK = false,

                        Affirmation = true
                    };
                    //save to cdsc tempPreorderLive too
                    var orderPreorderCdsc = new PreOrderLives
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        OrderNumber = orderNum,
                        Source = source
                    };
                    //save to cdsc tempPreorderLive too
                    var orderCashTrans = new CashTrans
                    {
                        Description = "BUY - Order",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -totalAmountToSpent,
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };

                    try
                    {
                        //                      var emailAdd = theBroker.Email;
                        atsDbContext.Pre_Order_Live.Add(orderLive);
                        atsDbContext.SaveChanges();
                        //                      SendMail2(emailAdd, "Your order was successfully posted", "Order Posting");
                        tempDbContext.PreOrderLives.Add(orderPreorderCdsc);
                        tempDbContext.SaveChanges();

                        if (orderTrans.ToString().ToUpper().Equals("BUY"))
                        {
                            tempDbContext.CashTrans.Add(orderCashTrans);
                            tempDbContext.SaveChanges();
                        }

                        return "1";
                    }
                    catch (Exception e)
                    {
                        return "Error Occured trying to send order please try again" + e;
                    }
                }
                catch (Exception e)
                {
                    return "Assigning values => " + e.ToString();
                }

            }
            catch (Exception ex)
            {
                return "All errors => " + ex.ToString();
            }
        }
        public string GetBrokerFromCDS(string cds)
        {
            var getBrk =
                "SELECT TOP 1 BrokerCode FROM Accounts_Clients WHERE CDS_Number = '" +
                cds.Trim() + "'";

            var ret = "";

            using (var connection = new SqlConnection(connectionStringCDS_Router))
            {
                var cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                var rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        ret += rdr["BrokerCode"];
                    }
                    try
                    {
                        return ret;
                    }
                    catch (Exception)
                    {
                        return "1";
                    }
                }
                return "0";
            }
        }
        public string OrderPostingMobile(string company, string security, string orderTrans,
          string orderType, string quantity, string price, string cdsNumber,
          string broker, string source)

        {
            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "";
            double basePrice = 0;
            var theOrderTrans = "";

            try
            {
                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }


                if (orderType != null && orderType.Equals("Market"))
                {
                    orderPref = "M";
                    basePrice = 0;
                }
                else
                {
                    basePrice = double.Parse(price);
                    orderPref = "L";
                }


                long orderNumber = 0;
                var myCompany = "";
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }

                var theCompnay =
                    atsDbContext.para_company.OrderByDescending(x => x.ID)
                        .Where(x => x.fnam == company)
                        .FirstOrDefault(x => x.fnam == company);

                if (theCompnay == null)
                {
                    return "Select a valid company";
                }

                myCompany = theCompnay.Company;

                var theCds = cdsNumber + "";

                var theBroker = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
                {
                    return "Enter CDS Number";
                }


                var theBroker1 = cdsDbContext.Client_Companies.FirstOrDefault(x => x.Company_Code == broker);
                //if (theBroker1 == null)
                //{
                //    return "Enter valid broker";
                //}


                decimal shares = 0;
                if (orderTrans.ToString().ToUpper().Equals("SELL"))
                {
                    var shareAvail =
                        cdsDbContext.trans.FirstOrDefault(x => x.CDS_Number == cdsNumber && x.Company == myCompany);

                    if (shareAvail != null)
                    {
                        var theShare = decimal.Parse(getCurrentBalance(company, cdsNumber));
                        //cdsDbContext.trans.Where(x => x.CDS_Number == cdsNumber && x.Company == myCompany)
                        //    .Select(x => x.Shares)
                        //    .Sum();
                        if (theShare <= 0)
                        {
                            return "You have insufficient shares, check with your broker";
                        }
                        if (theShare < int.Parse(quantity))
                        {
                            return "You have insufficient shares, check with your broker";
                        }

                    }
                    else
                    {
                        return "You have insufficient shares, check with your broker";
                    }
                }


                //IF BUY ORDER
                var totalAmountToSpent = decimal.Parse(quantity) * decimal.Parse(price) * decimal.Parse("1.01693");
                if (orderTrans.ToString().ToUpper().Equals("BUY"))
                {
                    var moneyAvail =
                        tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                    if (moneyAvail != null)
                    {
                        var theCashBal =
                            tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                                .Select(x => x.Amount)
                                .Sum();
                        if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                        {
                            return "You have insufficient balance in your Cash account";
                        }
                    }
                    else
                    {
                        return "You have insufficient balance in your Cash account";
                    }
                }
                //SAVING TO DB


                var orderStatus = "OPEN";
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                var expiryDate = DateTime.Now;
                var theQuantity = 0;


                if (quantity != null)
                {
                    theQuantity = int.Parse(quantity);
                }


                var brokerCode = "";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = "Day Order (DO)";
                var brokerRef = broker + orderNumber;
                var contraBrokerId = "";
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "$";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                try
                {
                    var orderLive = new Pre_Order_Live
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        Client_Type = "",
                        Tax = 0,
                        Shareholder = cdsNumber,
                        ClientName = name,
                        TotalShareHolding = 0,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Deal_Begin_Date = dealBeginDate,
                        Expiry_Date = expiryDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        AvailableShares = 0,
                        OrderPref = orderPref,
                        OrderAttribute = orderAttrib,
                        Marketboard = marketBoard,
                        TimeInForce = timeInForce,
                        OrderQualifier = "None",
                        BrokerRef = brokerRef,
                        ContraBrokerId = contraBrokerId,
                        MaxPrice = maxPrice,
                        MiniPrice = minPrice,
                        Flag_oldorder = flagOldOrder,
                        OrderNumber = orderNum,
                        Currency = currency,
                        FOK = false,
                        trading_platform = GetTradingPlaform(myCompany),
                        Affirmation = true
                    };
                    //save to cdsc tempPreorderLive too
                    var orderPreorderCdsc = new PreOrderLives
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        TimeInForce = timeInForce,
                        OrderQualifier = "None",
                        BrokerRef = brokerRef,
                        OrderNumber = orderNum,
                        Source = source
                    };
                    //save to cdsc tempPreorderLive too
                    var orderCashTrans = new CashTrans
                    {
                        Description = "BUY - Order",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -totalAmountToSpent,
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };

                    try
                    {
                        //                      var emailAdd = theBroker.Email;
                        atsDbContext.Pre_Order_Live.Add(orderLive);
                        atsDbContext.SaveChanges();
                        //                      SendMail2(emailAdd, "Your order was successfully posted", "Order Posting");

                        /*
                        *Saving to CDSC Table 
                        */
                        tempDbContext.PreOrderLives.Add(orderPreorderCdsc);
                        tempDbContext.SaveChanges();

                        if (orderTrans.ToString().ToUpper().Equals("BUY"))
                        {
                            tempDbContext.CashTrans.Add(orderCashTrans);
                            tempDbContext.SaveChanges();
                        }

                        return "Your Order has been successfully placed";
                    }
                    catch (Exception e)
                    {
                        return e.ToString();
                    }
                }
                catch (Exception e)
                {
                    return "Assigning values => " + e.ToString();
                }

            }
            catch (Exception ex)
            {
                return "All errors => " + ex.ToString();
            }
        }
        public string OrderPostingMobile1(string company, string security, string orderTrans,
          string orderType, string quantity, string price, string cdsNumber,
          string broker, string expiresOn, string source)

        {
            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "";
            double basePrice = 0;
            var theOrderTrans = "";

            try
            {
                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }


                if (orderType != null && orderType.Equals("Market"))
                {
                    orderPref = "M";
                    basePrice = 0;
                }
                else
                {
                    basePrice = double.Parse(price);
                    orderPref = "L";
                }


                long orderNumber = 0;
                var myCompany = "";
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }

                var theCompnay =
                    atsDbContext.para_company.OrderByDescending(x => x.ID)
                        .Where(x => x.fnam == company)
                        .FirstOrDefault(x => x.fnam == company);

                if (theCompnay == null)
                {
                    return "Select a valid company";
                }

                myCompany = theCompnay.Company;

                var theCds = cdsNumber + "";

                var theBroker = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
                {
                    return "Enter CDS Number";
                }


                var theBroker1 = cdsDbContext.Client_Companies.FirstOrDefault(x => x.Company_Code == broker);
                //if (theBroker1 == null)
                //{
                //    return "Enter valid broker";
                //}


                decimal shares = 0;
                if (orderTrans.ToString().ToUpper().Equals("SELL"))
                {
                    var shareAvail =
                        cdsDbContext.trans.FirstOrDefault(x => x.CDS_Number == cdsNumber && x.Company == myCompany);

                    if (shareAvail != null)
                    {
                        var theShare =
                            cdsDbContext.trans.Where(x => x.CDS_Number == cdsNumber && x.Company == myCompany)
                                .Select(x => x.Shares)
                                .Sum();
                        if (theShare <= 0)
                        {
                            return "You have insufficient shares, check with your broker";
                        }
                        if (theShare < int.Parse(quantity))
                        {
                            return "You have insufficient shares, check with your broker";
                        }

                    }
                    else
                    {
                        return "You have insufficient shares, check with your broker";
                    }
                }


                //IF BUY ORDER
                var totalAmountToSpent = decimal.Parse(quantity) * decimal.Parse(price) * decimal.Parse("1.01693");
                if (orderTrans.ToString().ToUpper().Equals("BUY"))
                {
                    var moneyAvail =
                        tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                    if (moneyAvail != null)
                    {
                        var theCashBal =
                            tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                                .Select(x => x.Amount)
                                .Sum();
                        if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                        {
                            return "You have insufficient balance in your Cash account";
                        }
                    }
                    else
                    {
                        return "You have insufficient balance in your Cash account";
                    }
                }
                //SAVING TO DB


                var orderStatus = "OPEN";
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                //var expiryDate =  DateTime.Now; 
                var expiryDate = DateTime.Now;
                DateTime testExpiryDate;

                if ((expiresOn != null || expiresOn != "") && (DateTime.TryParse(expiresOn, out testExpiryDate)))//if expires on date has been provided
                {
                    //expiryDate = Convert.ToDateTime(expiresOn);
                    expiryDate = DateTime.Parse(expiresOn);
                }
                else
                {
                    expiryDate = DateTime.Now;
                }

                var theQuantity = 0;


                if (quantity != null)
                {
                    theQuantity = int.Parse(quantity);
                }


                var brokerCode = "";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = "Day Order (DO)";
                var brokerRef = broker + orderNumber;
                var contraBrokerId = "";
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "$";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                try
                {
                    var orderLive = new Pre_Order_Live
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        Client_Type = "",
                        Tax = 0,
                        Shareholder = cdsNumber,
                        ClientName = name,
                        TotalShareHolding = 0,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Deal_Begin_Date = dealBeginDate,
                        Expiry_Date = expiryDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        AvailableShares = 0,
                        OrderPref = orderPref,
                        OrderAttribute = orderAttrib,
                        Marketboard = marketBoard,
                        TimeInForce = timeInForce,
                        OrderQualifier = "None",
                        BrokerRef = brokerRef,
                        ContraBrokerId = contraBrokerId,
                        MaxPrice = maxPrice,
                        MiniPrice = minPrice,
                        Flag_oldorder = flagOldOrder,
                        OrderNumber = orderNum,
                        Currency = currency,
                        FOK = false,
                        trading_platform = GetTradingPlaform(myCompany),
                        Affirmation = true
                    };
                    //save to cdsc tempPreorderLive too
                    var orderPreorderCdsc = new PreOrderLives
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        TimeInForce = timeInForce,
                        OrderQualifier = "None",
                        BrokerRef = brokerRef,
                        OrderNumber = orderNum,
                        Source = source
                    };
                    //save to cdsc tempPreorderLive too
                    var orderCashTrans = new CashTrans
                    {
                        Description = "BUY - Order",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -totalAmountToSpent,
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };

                    try
                    {
                        //                      var emailAdd = theBroker.Email;
                        atsDbContext.Pre_Order_Live.Add(orderLive);
                        atsDbContext.SaveChanges();
                        //                      SendMail2(emailAdd, "Your order was successfully posted", "Order Posting");

                        /*
                        *Saving to CDSC Table 
                        */
                        tempDbContext.PreOrderLives.Add(orderPreorderCdsc);
                        tempDbContext.SaveChanges();

                        if (orderTrans.ToString().ToUpper().Equals("BUY"))
                        {
                            tempDbContext.CashTrans.Add(orderCashTrans);
                            tempDbContext.SaveChanges();
                        }

                        return "Your Order has been successfully placed";
                    }
                    catch (Exception e)
                    {
                        //return e.ToString();
                        return "Timeout, please check your Internet connection.";
                    }
                }
                catch (Exception e)
                {
                    return "An error has occured in posting your order, please try again.";
                }

            }
            catch (Exception ex)
            {
                return "An error has occured in posting your order, please try again.";
            }
        }
        public string OrderPostingIPO(string company, string security, string orderTrans,
          string orderType, string quantity, string price, string cdsNumber,
          string broker, string source)

        {
            var tot = Math.Round(decimal.Parse(price) * int.Parse(quantity), 2);
            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "";
            double basePrice = 0;
            var theOrderTrans = "";

            try
            {
                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }


                if (orderType != null && orderType.Equals("Market"))
                {
                    orderPref = "M";
                    basePrice = 0;
                }
                else
                {
                    basePrice = double.Parse(price);
                    orderPref = "L";
                }


                long orderNumber = 0;
                var myCompany = "";
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }

                //var theCompnay =
                //    atsDbContext.para_company.OrderByDescending(x => x.ID)
                //        .Where(x => x.Company == company)
                //        .FirstOrDefault(x => x.Company == company);

                //if (theCompnay == null)
                //{
                //    return "Select a valid company";
                //}

                myCompany = company;
                var theCds = cdsNumber + "";

                //                var theBroker = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
                {
                    return "Enter CDS Number";
                }


                var theBroker1 = cdsDbContext.Client_Companies.FirstOrDefault(x => x.Company_Code == broker);
                if (theBroker1 == null)
                {
                    return "Enter valid broker";
                }

                var returnVal = LIMITS_CHECK(myCompany, cdsNumber, quantity);
                if (returnVal != "0")
                {
                    return returnVal;
                }

                decimal shares = 0;
                if (orderTrans.ToString().ToUpper().Equals("SELL"))
                {
                    var shareAvail =
                        cdsDbContext.trans.FirstOrDefault(x => x.CDS_Number == cdsNumber && x.Company == myCompany);

                    if (shareAvail != null)
                    {
                        var theShare =
                            cdsDbContext.trans.Where(x => x.CDS_Number == cdsNumber && x.Company == myCompany)
                                .Select(x => x.Shares)
                                .Sum();
                        if (theShare <= 0)
                        {
                            return "You have insufficient shares, check with your broker";
                        }
                    }
                    else
                    {
                        return "You have insufficient shares, check with your broker";
                    }
                }


                //IF BUY ORDER
                var totalAmountToSpent = decimal.Parse(quantity) * decimal.Parse(price);
                if (orderTrans.ToString().ToUpper().Equals("BUY"))
                {
                    var moneyAvail =
                        tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                    if (moneyAvail != null)
                    {
                        var theCashBal =
                            tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                                .Select(x => x.Amount)
                                .Sum();
                        if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                        {
                            return "You have insufficient balance in your Cash account";
                        }
                    }
                    else
                    {
                        return "You have insufficient balance in your Cash account";
                    }
                }
                //SAVING TO DB


                var orderStatus = "OPEN";
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                var expiryDate = DateTime.Now;
                var theQuantity = 0;


                if (quantity != null)
                {
                    theQuantity = int.Parse(quantity);
                }


                var brokerCode = "";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = "Day Order (DO)";
                var orderQualifier = "None";
                var brokerRef = broker + orderNumber;
                var contraBrokerId = "";
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "USD";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                try
                {
                    var orderLive = new Pre_Order_Live
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = theBroker1.Company_Code,
                        Client_Type = "",
                        Tax = 0,
                        Shareholder = cdsNumber,
                        ClientName = name,
                        TotalShareHolding = 0,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Deal_Begin_Date = dealBeginDate,
                        Expiry_Date = expiryDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        //                                                                    AvailableShares = availableShares,
                        OrderPref = orderPref,
                        OrderAttribute = orderAttrib,
                        Marketboard = marketBoard,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        ContraBrokerId = contraBrokerId,
                        MaxPrice = maxPrice,
                        MiniPrice = minPrice,
                        Flag_oldorder = flagOldOrder,
                        OrderNumber = orderNum,
                        Currency = currency,
                        FOK = false,
                        Affirmation = true
                    };
                    //save to cdsc tempPreorderLive too
                    var orderPreorderCdsc = new PreOrderLivesIPOes
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = theBroker1.Company_Code,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        OrderNumber = orderNum,
                        Source = source
                    };

                    //save to cdsc tempPreorderLive too
                    var orderCashTrans = new CashTrans
                    {
                        Description = "BUY - IPO",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -totalAmountToSpent,
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };
                    try
                    {
                        //                      var emailAdd = theBroker.Email;
                        //atsDbContext.Pre_Order_Live.Add(orderLive);
                        //atsDbContext.SaveChanges();
                        //                      SendMail2(emailAdd, "Your order was successfully posted", "Order Posting");
                        tempDbContext.PreOrderLivesIPOes.Add(orderPreorderCdsc);
                        tempDbContext.SaveChanges();

                        tempDbContext.CashTrans.Add(orderCashTrans);
                        tempDbContext.SaveChanges();

                        var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            SqlCommand cmdn = new SqlCommand();
                            cmdn.Connection = connection;
                            cmdn.CommandType = CommandType.StoredProcedure;
                            cmdn.CommandText = "AReceiveBidsIPO";
                            cmdn.Parameters.AddWithValue("@Bank", "0");
                            cmdn.Parameters.AddWithValue("@Branch", "0");
                            cmdn.Parameters.AddWithValue("@Accountnumber", "0");
                            cmdn.Parameters.AddWithValue("@No_of_Notes_Applied", quantity);
                            cmdn.Parameters.AddWithValue("@AmountPaid", tot);
                            cmdn.Parameters.AddWithValue("@PaymentRefNo", "Escrow");
                            cmdn.Parameters.AddWithValue("@ClientType", "LI");
                            cmdn.Parameters.AddWithValue("@BrokerReference", "OMSEC");
                            cmdn.Parameters.AddWithValue("@DividendDisposalPreference", "M");
                            cmdn.Parameters.AddWithValue("@MNO_", "ONLINE");
                            cmdn.Parameters.AddWithValue("@Identification", cdsNumber);
                            cmdn.Parameters.AddWithValue("@TelephoneNumber", cdsNumber);
                            cmdn.Parameters.AddWithValue("@CDSC_Number", cdsNumber);
                            cmdn.Parameters.AddWithValue("@ReceiptNumber", "Escrow");
                            cmdn.Parameters.AddWithValue("@Company", company);
                            //cmdn.Parameters.AddWithValue("@Custodian", "0");
                            //cmdn.Parameters.AddWithValue("@TransNum", "0");
                            //cmdn.Parameters.AddWithValue("@PledgeIndicator", "0");
                            //cmdn.Parameters.AddWithValue("@PledgeeBPID", cdsNumber);
                            connection.Open();
                            if (cmdn.ExecuteNonQuery() > 0)
                            {
                                connection.Close();
                                return "1";
                            }
                            else
                            {
                                connection.Close();
                                return "Error saving IPO";
                            }
                        }
                        //return "1";
                    }
                    catch (Exception e)
                    {
                        return e.ToString();
                    }
                }
                catch (Exception e)
                {
                    return "Assigning values => " + e.ToString();
                }

            }
            catch (Exception ex)
            {
                return "All errors => " + ex.ToString();
            }
        }
        public string OrderIPOPostingPOSTANDROIDTwo(string company, string quantity, string price, string cdsNumber)
        {
            var tot = Math.Round(decimal.Parse(price) * int.Parse(quantity), 2);


            var returnVal = LIMITS_CHECK(company, cdsNumber, quantity);
            if (returnVal != "0")
            {
                return returnVal;
            }
            //IF BUY ORDER
            var totalAmountToSpent = decimal.Parse(quantity) * decimal.Parse(price);
            var tempDbContext = new cdscDbContext();
            var moneyAvail =
                    tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

            if (moneyAvail != null)
            {
                var theCashBal =
                    tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                        .Select(x => x.Amount)
                        .Sum();
                if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                {
                    return "You have insufficient balance in your Cash account";
                }
            }
            else
            {
                return "You have insufficient balance in your Cash account";
            }

            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                //String mycds_ = GetCdsNumberFROMMOBILE(mobile);
                SqlCommand cmdn = new SqlCommand();
                cmdn.Connection = connection;
                cmdn.CommandType = CommandType.StoredProcedure;
                cmdn.CommandText = "AReceiveBidsIPO";
                cmdn.Parameters.AddWithValue("@Bank", "0");
                cmdn.Parameters.AddWithValue("@Branch", "0");
                cmdn.Parameters.AddWithValue("@Accountnumber", "0");
                cmdn.Parameters.AddWithValue("@No_of_Notes_Applied", quantity);
                cmdn.Parameters.AddWithValue("@AmountPaid", tot);
                cmdn.Parameters.AddWithValue("@PaymentRefNo", "Escrow");
                cmdn.Parameters.AddWithValue("@ClientType", "LI");
                cmdn.Parameters.AddWithValue("@BrokerReference", "OMSEC");
                cmdn.Parameters.AddWithValue("@DividendDisposalPreference", "M");
                cmdn.Parameters.AddWithValue("@MNO_", "ANDROID");
                cmdn.Parameters.AddWithValue("@Identification", cdsNumber);
                cmdn.Parameters.AddWithValue("@TelephoneNumber", "");
                cmdn.Parameters.AddWithValue("@CDSC_Number", cdsNumber);
                cmdn.Parameters.AddWithValue("@ReceiptNumber", "Escrow");
                cmdn.Parameters.AddWithValue("@Company", company);
                //cmdn.Parameters.AddWithValue("@Custodian", "0");
                //cmdn.Parameters.AddWithValue("@TransNum", "0");
                //cmdn.Parameters.AddWithValue("@PledgeIndicator", "0");
                //cmdn.Parameters.AddWithValue("@PledgeeBPID", cdsNumber);
                connection.Open();
                if (cmdn.ExecuteNonQuery() > 0)
                {
                    connection.Close();
                    //save to cdsc tempPreorderLive too
                    var orderCashTrans = new CashTrans
                    {
                        Description = "IPO - BUY",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -totalAmountToSpent,
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };

                    tempDbContext.CashTrans.Add(orderCashTrans);
                    tempDbContext.SaveChanges();
                    return "Order placed successfully";
                }
                else
                {
                    connection.Close();
                    return "Error placing order";
                }
            }

        }
        public string GetCdsNumber(string cdsNumber)
        {
            var getBrk =
                "SELECT TOP 1 [CDS_Number], [Surname] , [Forenames] FROM [CDS_ROUTER].[dbo].[Accounts_Clients] where CDS_Number = '" +
                cdsNumber + "'";
            var order = new Accounts_Clients();
            var ret = "";

            using (var connection = new SqlConnection(connectionStringCDS_Router))
            {
                var cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                var rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        //                        order.CDS_Number = rdr["CDS_Number"].ToString();
                        ret += rdr["Surname"].ToString() + " " + rdr["Forenames"].ToString();

                        //                        order.Surname = rdr["Surname"].ToString();
                        //                        order.Forenames = rdr["Forenames"].ToString();
                        //                        listOfOrders.Add(order);
                    }

                    try
                    {
                        //                        var jsonResult = Json(listOfOrders, JsonRequestBehavior.AllowGet);
                        //                        jsonResult.MaxJsonLength = int.MaxValue;
                        return ret;
                    }
                    catch (Exception)
                    {
                        return "1";
                    }
                }
                else
                {
                    return "0";
                }
            }
        }
        public JsonResult GetCompaniies(string company = null)
        {
            var atsDbContext = new AtsDbContext();
            //Selecting distinct
            var companies = atsDbContext.para_company.Select(c =>
                new
                {
                    CompayCode = c.Company,
                    CompanyName = c.fnam
                });
            return Json(companies, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetSecurities(String exchange, string company = null)
        {
            var atsDbContext = new AtsDbContext();
            var statement =
                atsDbContext.para_company.OrderByDescending(x => x.ID).Where(x => x.fnam == company && x.exchange == exchange).Select(c => new
                {
                    Id = c.ID,
                    Instrument = c.Instrument,
                    IsinNo = c.Company,
                    InitialPrice = c.InitialPrice
                });
            return Json(statement, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetMyCompanies(string exchange, string company = null)
        {
            var atsDbContext = new AtsDbContext();
            //Selecting distinct
            var companies =
                atsDbContext.para_company.Where(x => x.exchange == exchange).GroupBy(x => x.fnam).Select(x => x.FirstOrDefault()).Select(c =>
                new
                {
                    Id = c.ID,
                    compInitial = c.Company,
                    Name = c.fnam,
                    InitialPrice = c.InitialPrice
                });
            return Json(companies, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetCompanyFullName(string exchange)
        {
            var atsDbContext = new AtsDbContext();
            //Selecting distinct
            var companies =
                atsDbContext.para_company.Where(x => x.exchange == exchange).GroupBy(x => x.fnam).Select(x => x.FirstOrDefault()).Select(c =>
                new
                {
                    Id = c.ID,
                    company = c.Company,
                    Name = c.fnam,
                    InitialPrice = c.InitialPrice
                });
            return Json(companies, JsonRequestBehavior.AllowGet);
        }
     /*   public string Widthdraw(string cdsnumber, string ammount)
        {
            var tempDbContext = new cdscDbContext();
            try
            {

                var moneyAvail =
                        tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsnumber && x.TransStatus.Trim() == "1");
                decimal? theCashBalSell = 0;
                decimal? theCashBal = 0;
                string message = "";
                if (moneyAvail != null)
                {


                    var result = tempDbContext.Database.SqlQuery<Balancess>("SELECT amt  FROM New_Balz  where cds_number = '" + cdsnumber + "'").FirstOrDefault();
                    //get withdraw balance
                    var withd = _cdDataContext.CTRADELIMITS.ToList().Where(a => a.LimitType.ToLower().Replace(" ", "") == "withdraw").FirstOrDefault();

                    // var limits = tempDbContext.Database.SqlQuery<CTRADELIMITS>("SELECT * FROM[CDS_ROUTER].[dbo].[CTRADELIMITS] where LimitType = 'WITHDRAW'").FirstOrDefault();
                    //message = "Balance from db " + theCashBal + " , cashbal " + theCashBal + " amount"+ammount;
                    if (Convert.ToDecimal(ammount) < Convert.ToDecimal(withd.Minimum))
                    {
                        return "You  amount to withdraw is below the limit";
                    }

                    theCashBal = result.amt;

                    if (String.IsNullOrEmpty(theCashBal.ToString()) == true)
                    {
                        theCashBal = 0;
                    }

                    //message = "Balance from db " + theCashBal + " , cashbal " + theCashBal + " amount"+ammount;
                    if (theCashBal < (Convert.ToDecimal(withd.Minimum)) || theCashBal < (Convert.ToDecimal(ammount)))
                    {
                        return "You have insufficient balance in your Cash account";
                    }

                }
                else
                {
                    return "You have insufficient balance in your Cash account";
                }

                var isCompany = _cdDataContext.Accounts_Clients_Web.Where(a => a.CDS_Number == cdsnumber);


                DateTime nowDate = DateTime.Now;
                decimal myAmount = Convert.ToDecimal(ammount);
                var hasWithdrawal = _cdscDbContext.CashTrans

.Where(b => b.Amount == -myAmount)
                                                              .Where(a => a.CDS_Number == cdsnumber)
                                                            .Where(c => c.DateCreated >= DbFunctions.CreateDateTime(nowDate.Year, nowDate.Month, nowDate.Day, nowDate.Hour - 1, nowDate.Minute, nowDate.Second))


                                                            .ToList();


                if (hasWithdrawal.Count == 0)
                {
                    if (isCompany.First().AccountType.ToLower().Equals("c"))
                    {
                        //Selecting distinct
                        var tempCashTrans = new CashTransTemp
                        {
                            Description = "Withdrawal",
                            TransType = "Withdraw",
                            TransStatus = "0",
                            Amount = (Decimal.Parse(ammount)) * -1,
                            CDS_Number = cdsnumber,
                            DateCreated = DateTime.Now,
                            Paid = false,
                            Reference = "None"
                        };
                        tempDbContext.CashTransTemps.Add(tempCashTrans);
                        tempDbContext.SaveChanges();
                        return "Withdraw request sent and pending authorization.";
                    }
                    else
                    {
                        //Selecting distinct
                        var orderCashTrans = new CashTrans
                        {
                            Description = "Withdrawal",
                            TransType = "Withdraw",
                            TransStatus = "1",
                            Amount = -(Decimal.Parse(ammount)),
                            CDS_Number = cdsnumber,
                            DateCreated = DateTime.Now
                        };
                        tempDbContext.CashTrans.Add(orderCashTrans);
                        tempDbContext.SaveChanges();
                        // return message;
                        return "Withdraw Successful";
                    }
                }
                else
                {
                    return "Withdraw not Successful";
                }
            }
            catch (Exception ex)
            {
                return "Failed to make withdrawal" + ex;
            }
            //return Json(companies, JsonRequestBehavior.AllowGet);
        }*/


        public string WidthdrawCashOnCommodities(string cdsnumber, string ammount)
        {
            var tempDbContext = new cdscDbContext();
            try
            {

                var moneyAvail =
                        tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsnumber && x.TransStatus.Trim() == "1");
                decimal? theCashBalSell = 0;
                decimal? theCashBal = 0;
                string message = "";
                if (moneyAvail != null)
                {


                    var result = tempDbContext.Database.SqlQuery<Balancess>("SELECT amt  FROM New_Balz  where cds_number = '" + cdsnumber + "'").FirstOrDefault();
                    //get withdraw balance
                    var withd = _cdDataContext.CTRADELIMITS.ToList().Where(a => a.LimitType.ToLower().Replace(" ", "") == "withdraw").FirstOrDefault();

                    // var limits = tempDbContext.Database.SqlQuery<CTRADELIMITS>("SELECT * FROM[CDS_ROUTER].[dbo].[CTRADELIMITS] where LimitType = 'WITHDRAW'").FirstOrDefault();
                    //message = "Balance from db " + theCashBal + " , cashbal " + theCashBal + " amount"+ammount;
                    if (Convert.ToDecimal(ammount) < Convert.ToDecimal(withd.Minimum))
                    {
                        return "You  amount to withdraw is below the limit";
                    }

                    theCashBal = result.amt;

                    if (String.IsNullOrEmpty(theCashBal.ToString()) == true)
                    {
                        theCashBal = 0;
                    }

                    //message = "Balance from db " + theCashBal + " , cashbal " + theCashBal + " amount"+ammount;
                    if (theCashBal < (Convert.ToDecimal(withd.Minimum)) || theCashBal < (Convert.ToDecimal(ammount)))
                    {
                        return "You have insufficient balance in your Cash account";
                    }

                }
                else
                {
                    return "You have insufficient balance in your Cash account";
                }

                var isCompany = _cdDataContext.Accounts_Clients_Web.Where(a => a.CDS_Number == cdsnumber);


                DateTime nowDate = DateTime.Now;
                decimal myAmount = Convert.ToDecimal(ammount);
                var hasWithdrawal = _cdscDbContext.CashTrans.Where(b => b.Amount == -myAmount)
                                                              .Where(a => a.CDS_Number == cdsnumber)
                                                            .Where(c => c.DateCreated >= DbFunctions.CreateDateTime(nowDate.Year, nowDate.Month, nowDate.Day, nowDate.Hour - 1, nowDate.Minute, nowDate.Second))
                                                            .ToList();


                if (hasWithdrawal.Count == 0)
                {

                    //Selecting distinct
                    var orderCashTrans = new CommodityWithdrawalCashTrans
                    {
                        Description = "Withdrawal",
                        TransType = "Withdraw",
                        TransStatus = "0",
                        Amount = -(Decimal.Parse(ammount)),
                        CDS_Number = cdsnumber,
                        DateCreated = DateTime.Now
                    };
                    tempDbContext.CommodityWithdrawalCashTrans.Add(orderCashTrans);
                    tempDbContext.SaveChanges();
                    // return message;
                    return "Withdraw Successful";

                }
                else
                {
                    return "Withdraw not Successful";
                }
            }
            catch (Exception ex)
            {
                return "Failed to make withdrawal" + ex;
            }
            //return Json(companies, JsonRequestBehavior.AllowGet);
        }
        public string WidthdrawForex(string cdsnumber, string ammount)
        {
            var tempDbContext = new cdscDbContext();
            try
            {

                var moneyAvail =
                        tempDbContext.CashTrans_forex.FirstOrDefault(x => x.CDS_Number == cdsnumber && x.TransStatus.Trim() == "1");

                if (moneyAvail != null)
                {

                    var theCashBal =
                        tempDbContext.CashTrans_forex.Where(x => x.CDS_Number == cdsnumber && x.TransStatus.Trim() == "1")
                            .Select(x => x.Amount)
                            .Sum();
                    if (theCashBal <= 10 || theCashBal < (Decimal.Parse(ammount)))
                    {
                        return "You have insufficient balance in your Cash account";
                    }
                }
                else
                {
                    return "You have insufficient balance in your Cash account";
                }

                //Selecting distinct
                var orderCashTrans = new CashTrans_forex
                {
                    Description = "Withdrawal",
                    TransType = "Withdraw",
                    TransStatus = "1",
                    Amount = -(Decimal.Parse(ammount)),
                    CDS_Number = cdsnumber,
                    Currency = "USD",
                    DateCreated = DateTime.Now
                };
                tempDbContext.CashTrans_forex.Add(orderCashTrans);
                tempDbContext.SaveChanges();
                return "Conversion Successfull";
            }
            catch (Exception ex)
            {
                return "Failed to make conversion" + ex;
            }
            //return Json(companies, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetCompaniesListForGraph(string exchange)
        {
            var atsDbContext = new AtsDbContext();
            //Selecting distinct
            var companies =
                atsDbContext.para_company.Where(x => x.exchange == exchange).GroupBy(x => x.fnam).Select(x => x.FirstOrDefault()).Select(c =>
                new
                {
                    Id = c.ID,
                    Name = c.Company,
                    InitialPrice = c.InitialPrice,
                    Instrument = c.Instrument,

                });
            return Json(companies, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetCompaniesListForGraphAll()
        {
            var atsDbContext = new AtsDbContext();
            //Selecting distinct
            var companies =
                atsDbContext.para_company.GroupBy(x => x.fnam).Select(x => x.FirstOrDefault()).Select(c =>
                new
                {
                    Id = c.ID,
                    Name = c.Company,
                    InitialPrice = c.InitialPrice,
                    Instrument = c.Instrument,

                });
            return Json(companies, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetCompaniesMaPriceList(string cmpny)
        {
            var atsDbContext = new AtsDbContext();
            //Selecting distinct
            var companies =
                atsDbContext.para_company.Where(x => x.Company == cmpny).Select(c =>
                new
                {
                    InitialPrice = c.InitialPrice
                });
            return Json(companies, JsonRequestBehavior.AllowGet);
        }
        public string GetTradingPlaform(string company)
        {
            var getBrk =
                "SELECT exchange FROM para_company where Company  = '" +
                company.Trim() + "'";

            var ret = "";

            using (var connection = new SqlConnection(connectionStringATS))
            {
                var cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                var rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        ret += rdr["exchange"];
                    }

                    try
                    {
                        return ret;
                    }
                    catch (Exception)
                    {
                        return "FINSEC";
                    }
                }
                return "FINSEC";
            }
        }
        public JsonResult GetCompaniesPriceList(string company)
        {
            var getBrk = @"  select DISTINCT CONVERT(date , b.price_date) as date_ ,(select TOP 1 a.[price_close] from Prices a WHERE CONVERT(date , a.price_date)=CONVERT(date , b.price_date) and a.company_name=b.company_name ORDER BY a.price_date DESC) AS PriceClose
  from prices b
  WHERE b.company_name = '" + company + @"'";

            var listOfBrokers = new List<MYPriceGRAPH>();
            using (SqlConnection connection = new SqlConnection(connectionStringATS))
            {
                SqlCommand cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MYPriceGRAPH broker = new MYPriceGRAPH();
                    broker.Price = rdr["PriceClose"].ToString();
                    broker.Date = DateTime.Parse(rdr["date_"].ToString()).ToString("dd/MM/yyyy");
                    listOfBrokers.Add(broker);
                }

                try
                {
                    var jsonResult = Json(listOfBrokers, JsonRequestBehavior.AllowGet);
                    jsonResult.MaxJsonLength = int.MaxValue;
                    return jsonResult;
                }
                catch (Exception)
                {
                    return Json("Data set too large", JsonRequestBehavior.AllowGet);
                }
            }

        }
        public JsonResult GetCompaniesPriceFromList(string company)
        {
            var getBrk = @" select TOP 1 DISTINCT CONVERT(date , b.price_date) as date_ ,(select TOP 1 a.[price_close] from Prices a WHERE CONVERT(date , a.price_date)=CONVERT(date , b.price_date) and a.company_name=b.company_name ORDER BY a.price_date ASC) AS PriceClose
  from prices b
  WHERE b.company_name = '" + company + @"'";

            var listOfBrokers = new List<MYPriceGRAPH>();
            using (SqlConnection connection = new SqlConnection(connectionStringATS))
            {
                SqlCommand cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MYPriceGRAPH broker = new MYPriceGRAPH();
                    broker.Price = rdr["PriceClose"].ToString();
                    broker.Date = DateTime.Parse(rdr["date_"].ToString()).ToString("dd/MM/yyyy");
                    listOfBrokers.Add(broker);
                }

                try
                {
                    var jsonResult = Json(listOfBrokers, JsonRequestBehavior.AllowGet);
                    jsonResult.MaxJsonLength = int.MaxValue;
                    return jsonResult;
                }
                catch (Exception)
                {
                    return Json("Data set too large", JsonRequestBehavior.AllowGet);
                }
            }

        }
        private string LIMITS_CHECK(string isin, string cds_acc, string quantity)
        {
            string return_str = "";
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("declare @cdsnumber nvarchar(50)='" + cds_acc + "' declare @issue nvarchar(50)='" + isin + "' select Bidratio, IPOSTATUS, IndividualLimit, GlobalLimit, globLowerlimit, DailyLimit,Transaction_Limit,FirstLimit,isnull((select cds_number from Accounts_Clients where CDS_Number=@cdsnumber),'NotExisting') as [CDSExist], (SELECT isnull(SUM(isnull(No_of_Notes_Applied,0)),0) as BidToDate FROM [Bond_Payment_Audit] where Company =@issue) as [Bidstodate],(SELECT isnull(SUM(isnull(No_of_Notes_Applied,0)),0) as BidToDate FROM [Bond_Payment_Audit] where Company =@issue and CDSC_Number=@cdsnumber) as [InvestorTotalBidsGlobal],(SELECT isnull(SUM(isnull(No_of_Notes_Applied,0)),0) as BidToDate FROM [Bond_Payment_Audit] where Company =@issue and CDSC_Number=@cdsnumber and convert(date,date_created)=convert(date,getdate())) as InvestorTotalToday, isnull((select Mobile from Accounts_Clients where CDS_Number=@cdsnumber),'NotExisting') as [Telephone], isnull((select IDNoPP from Accounts_Clients where CDS_Number=@cdsnumber),'NotExisting') as [Idnumber]  from para_holding WITH (NOLOCK) where NewIssuerCode=@issue", con))
                {
                    DataSet dsi = new DataSet();
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    adp.Fill(dsi, "para_holding");
                    if (dsi.Tables[0].Rows.Count > 0)
                    {
                        DataRow dr = dsi.Tables[0].Rows[0];
                        if (Convert.ToInt32(dr["IPOSTATUS"]) == 1)
                        {
                            return_str = "Primary Issuance Has Been Closed";
                        }
                        else if (dr["CDSExist"].ToString() == "NotExisting")
                        {
                            return_str = "CDS Account Number does Not Exist";
                        }
                        else if (Convert.ToInt64(dr["Bidstodate"]) >= Convert.ToInt64(dr["GlobalLimit"]))
                        {
                            return_str = "Global Limit Already Reached";
                        }
                        else if (Convert.ToInt64(dr["Bidstodate"]) + Convert.ToInt64(quantity) > Convert.ToInt64(dr["GlobalLimit"]))
                        {
                            return_str = "Quantity will exceed Global Limit";
                        }
                        else if (Convert.ToInt64(dr["InvestorTotalBidsGlobal"]) >= Convert.ToInt64(dr["IndividualLimit"]))
                        {
                            return_str = "Individual Limit Already Reached";
                        }
                        else if (Convert.ToInt64(dr["InvestorTotalBidsGlobal"]) + Convert.ToInt64(quantity) > Convert.ToInt64(dr["IndividualLimit"]))
                        {
                            return_str = "Individual Limit will be exceeded";

                        }
                        else if (Convert.ToInt64(dr["InvestorTotalToday"]) >= Convert.ToInt64(dr["DailyLimit"]))
                        {
                            return_str = "Daily Limit Already Reached";

                        }
                        else if (Convert.ToInt64(dr["InvestorTotalToday"]) + Convert.ToInt64(quantity) > Convert.ToInt64(dr["DailyLimit"]))
                        {
                            return_str = "Daily Limit will be exceeded";

                        }
                        //else if (Convert.ToInt64(dr["InvestorTotalBidsGlobal"]) == 0 & Convert.ToInt64(quantity) < Convert.ToInt64(dr["FirstLimit"]))
                        //{
                        //    return_str = "First Bid. The Amount Entered is Less than the First Bid limit which is " + dr["FirstLimit"].ToString();

                        //}
                        else if (Convert.ToInt64(quantity) < Convert.ToInt64(dr["globLowerlimit"]))
                        {
                            return_str = "The Amount Entered is Less than the Lower Bid limit which is " + dr["globLowerlimit"].ToString();

                        }
                        else
                        {
                            return_str = "0";
                        }
                    }
                    else
                    {
                        return_str = "Limits Not set";

                    }
                }
            }
            return return_str;
        }
        public static string Force4DecimalPlaces(string input)
        {
            decimal parsed = decimal.Parse(input, CultureInfo.InvariantCulture);
            string intermediate = parsed.ToString("0.0000", CultureInfo.InvariantCulture);
            return decimal.Parse(intermediate, CultureInfo.InvariantCulture).ToString();
        }
        public static string Force2DecimalPlaces(string input)
        {
            decimal parsed = decimal.Parse(input, CultureInfo.InvariantCulture);
            string intermediate = parsed.ToString("0.00", CultureInfo.InvariantCulture);
            return decimal.Parse(intermediate, CultureInfo.InvariantCulture).ToString();
        }
        public string GetCdsNumberFROMIDNUM(string idnumb)
        {
            var getBrk =
                "SELECT TOP 1 [CDS_Number] FROM [CDS_ROUTER].[dbo].[Accounts_Clients] where IDNoPP = '" +
                idnumb + "'";
            var order = new Accounts_Clients();
            var ret = "";
            using (var connection = new SqlConnection(connectionStringCDS_Router))
            {
                var cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                var rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        ret += rdr["CDS_Number"].ToString();
                    }

                    try
                    {
                        return ret;
                    }
                    catch (Exception)
                    {
                        return "1";
                    }
                }
                else
                {
                    return "0";
                }
            }
        }
        public string getCurrentBalance(string company, string cdsnumber)
        {
            var getBrk =
                "select isnull(Net,0) as NetShares from cdsc.dbo.MyportfolioAll d where d.CDS_Number='" +
                cdsnumber.Trim() + "' AND D.COMPANY = '" + company.Trim() + "'";

            var ret = "";

            using (var connection = new SqlConnection(connectionStringATS))
            {
                var cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                var rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        ret = rdr["NetShares"].ToString();
                    }

                    try
                    {
                        return ret;
                    }
                    catch (Exception)
                    {
                        return "0";
                    }
                }
                return "0";
            }
        }

        ///////////////////////////////////////////////////////////////////////////////V2 METHODS////////////////////////////////////////////////////////////////////


        public static string getHashSha256(string text)
        {
            byte[] bytes = Encoding.Unicode.GetBytes(text);
            SHA256Managed hashstring = new SHA256Managed();
            byte[] hash = hashstring.ComputeHash(bytes);
            string hashString = string.Empty;
            foreach (byte x in hash)
            {
                hashString += String.Format("{0:x2}", x);
            }
            return hashString;
        }
        public static String sha256_hash(String value)
        {
            StringBuilder Sb = new StringBuilder();

            using (SHA256 hash = SHA256Managed.Create())
            {
                Encoding enc = Encoding.UTF8;
                Byte[] result = hash.ComputeHash(enc.GetBytes(value));

                foreach (Byte b in result)
                    Sb.Append(b.ToString("x2"));
            }

            return Sb.ToString();
        }
        public JsonResult NewLoginEncry(string username = null, string password = null)
        {

            if (username != null || password != null)
            {
                var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
                var CompShares = new List<VatenkeciNewV2>();

                //var sql = "SELECT t.* , ut.BrokerCode . ISNULL(ut.min_value_threshold , 10) as min_value_threshold  FROM [CDSC].[dbo].[Vatenkecis] t , [CDS_ROUTER].[dbo].[Accounts_Clients] ut where (t.Email ='" + username + "' or t.CdsNumber = '" + username + "')  and (t.CdsNumber = ut.CDS_Number)  and t.Active = '1' ";
                var sql = "SELECT t.* , ut.BrokerCode ,ISNULL(vt.min_value_threshold , 10) as min_value_threshold  FROM [CDSC].[dbo].[Vatenkecis] t , [CDS_ROUTER].[dbo].[Accounts_Clients] ut left join [CDS_ROUTER].[dbo].[Client_Companies] vt on ut.BrokerCode = vt.Company_Code where (t.Email ='" + username + "' or t.CdsNumber = '" + username + "')  and (t.CdsNumber = ut.CDS_Number)  and t.Active = '1' ";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    String getstatus_;

                    string encyptedPassword = EncryptIt(password.Trim());

                    while (rdr.Read())
                    {
                        //if (sha256_hash(rdr["Password"].ToString()).Equals(password))
                        if (encyptedPassword.Equals(rdr["Password"].ToString()))
                        {
                            VatenkeciNewV2 recordSummary = new VatenkeciNewV2();
                            recordSummary.id = int.Parse(rdr["id"].ToString());
                            recordSummary.username = rdr["username"].ToString();
                            recordSummary.email = rdr["email"].ToString();
                            recordSummary.broker = rdr["BrokerCode"].ToString();
                            recordSummary.cds = rdr["CdsNumber"].ToString();
                            //recordSummary.Active = rdr["Active"].ToString();
                            recordSummary.Active = rdr["Active"].ToString();
                            recordSummary.min_value_threshold = rdr["min_value_threshold"].ToString();
                            getstatus_ = testAccountinJoint(rdr["CdsNumber"].ToString());
                            recordSummary.has_company = getstatus_;
                            CompShares.Add(recordSummary);
                        }
                        else
                        {
                            return Json(7, JsonRequestBehavior.AllowGet);
                        }
                    }
                }

                if (CompShares.Any())
                {
                    return Json(CompShares, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(0, JsonRequestBehavior.AllowGet);
                }
            }
            return Json(0, JsonRequestBehavior.AllowGet);

        }
        // GET: Subscriber
        public string sendemail(string emailAdd, string subject, string emailbody)
        {
            try
            {
                SmtpClient client = new SmtpClient();
                client.Port = 587;
                client.Host = "smtp.office365.com"; //outlook.office365.com
                client.EnableSsl = true;
                ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                client.Timeout = 30000;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new System.Net.NetworkCredential("info@ctrade.co.zw", "asdfghjkl.2017");
                client.TargetName = "STARTTLS/smtp.office365.com";
                MailMessage mm = new MailMessage();
                mm.BodyEncoding = Encoding.UTF8;
                mm.From = new MailAddress("info@ctrade.co.zw");
                mm.To.Add(emailAdd);
                mm.Subject = subject;
                mm.Body = emailbody;
                mm.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
                client.Send(mm);
                return "Message Sent";
            }
            catch (Exception e)
            {
                return "Error occured please try again" + e;
            }
        }
        [HttpPost]
        public string sendmail(FormCollection formCollection)
        {
            string emailAdd = formCollection["emailAdd"];
            string subject = formCollection["subject"];
            string emailbody = formCollection["emailbody"];
            try
            {
                SmtpClient client = new SmtpClient();
                client.Port = 587;
                client.Host = "smtp.gmail.com";
                client.EnableSsl = true;
                ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                client.Timeout = 10000;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new System.Net.NetworkCredential("escrowctrade@gmail.com", "asdfghjkl2017");

                MailMessage mm = new MailMessage();
                mm.BodyEncoding = Encoding.UTF8;
                mm.From = new MailAddress("escrowctrade@gmail.com");
                mm.To.Add(emailAdd);
                mm.Subject = subject;
                mm.Body = emailbody;
                mm.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;

                client.Send(mm);
                return "Email Send";
            }
            catch (Exception ex)
            {
                return "Error sending email ";
            }
            //try
            //{

            //    MailMessage Mail = new MailMessage();
            //    Mail.Subject = subject;
            //    Mail.To.Add("" + emailAdd + "");
            //    // Mail.From = New MailAddress("corpservesharepower@googlemail.com")
            //    Mail.From = new MailAddress("notifications@ctrade.co.zw");
            //    Mail.Body = emailbody;
            //    // Dim SMTP As New SmtpClient("smtp.googlemail.com")
            //    System.Net.ServicePointManager.ServerCertificateValidationCallback = (object se, System.Security.Cryptography.X509Certificates.X509Certificate cert, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslerror) => true;
            //    //Dim SMTP As New SmtpClient("64.233.167.16")
            //    SmtpClient SMTP = new SmtpClient("192.168.3.241");
            //    SMTP.EnableSsl = true;
            //    //Mail.Attachments.Add(new Attachment(AttachName));
            //    //SMTP.Credentials = New System.Net.NetworkCredential("corpservesharepower@googlemail.com", "pavilion$")
            //    SMTP.Credentials = new System.Net.NetworkCredential("notifications@ctrade.co.zw", "asdfghjkl2017");
            //    SMTP.Port = 587;
            //    // SMTP.Port = SMTPport
            //    SMTP.Send(Mail);
            //    return "Email Send";
            //}
            //catch (Exception ex)
            //{
            //    return "Error sending email " + ex;
            //}
        }
        public JsonResult getMyPortFolioOLD(string cdsNumber = null)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var myPortf = new List<MyPortfolio>();

            var sql = "select * from cdsc.dbo.MyportfolioAll d where d.CDS_Number='" + cdsNumber + "'";
            var ix = 1;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MyPortfolio recordSummary = new MyPortfolio();
                    recordSummary.id = ix.ToString();
                    recordSummary.counter = rdr["Company"].ToString();
                    recordSummary.numbershares = rdr["totAllShares"].ToString();
                    recordSummary.lastactivitydate = rdr["LastAcDate"].ToString();
                    recordSummary.currentprice = Force4DecimalPlaces(rdr["currePrice"].ToString());
                    recordSummary.prevprice = Force4DecimalPlaces(rdr["PrevPrice"].ToString());
                    recordSummary.totalportvalue = Force4DecimalPlaces(rdr["TotPottValue"].ToString());
                    recordSummary.totalPrevPortValue = Force4DecimalPlaces(Math.Round((double.Parse(rdr["PrevPrice"].ToString()) * double.Parse(rdr["totAllShares"].ToString())), 4).ToString());
                    recordSummary.returns = Force4DecimalPlaces(Math.Round(double.Parse(rdr["totReturnValue"].ToString()), 4).ToString());
                    recordSummary.uncleared = Force4DecimalPlaces(rdr["Uncleared"].ToString());
                    recordSummary.net = Force4DecimalPlaces(rdr["Net"].ToString());

                    var BuysBymes = new List<BuysByme>();
                    var sql2 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares>0";
                    using (SqlConnection connection2 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd2 = new SqlCommand(sql2, connection2);
                        cmd2.CommandType = CommandType.Text;
                        connection2.Open();
                        SqlDataReader rdr2 = cmd2.ExecuteReader();
                        while (rdr2.Read())
                        {
                            BuysByme recordSum1 = new BuysByme();
                            recordSum1.company = rdr2["Company"].ToString();
                            recordSum1.volume = rdr2["Shares"].ToString();
                            recordSum1.price = Force4DecimalPlaces(rdr2["TradePrice"].ToString());
                            recordSum1.totalValue = Force4DecimalPlaces((decimal.Parse(rdr2["TradePrice"].ToString()) * decimal.Parse(rdr2["Shares"].ToString())).ToString());
                            BuysBymes.Add(recordSum1);
                        }
                    }
                    // foreach (var p in retBids)
                    //{

                    //}
                    recordSummary.BuyDetail = BuysBymes;
                    //get my buys

                    //get my sells
                    //var retOffers = _cdDataContext.trans.Where(x => x.CDS_Number == cdsNumber.ToString() && x.Shares < 0 && x.Company == recordSummary.counter).Select(v => new
                    //{
                    //    comp = v.Company,
                    //    volum = v.Shares,
                    //    pric = v.Shares,
                    //    totVal = v.Shares
                    //});
                    //var sellBymes = new List<SellsByme>();

                    //foreach (var p in retOffers)
                    //{
                    //    SellsByme recordSum2 = new SellsByme();
                    //    recordSum2.company = p.comp.ToString();
                    //    recordSum2.volume = p.volum.ToString();
                    //    recordSum2.price = p.pric.ToString();
                    //    recordSum2.totalValue = p.totVal.ToString();
                    //    sellBymes.Add(recordSum2);
                    //}
                    var sellBymes = new List<SellsByme>();
                    var sql3 = "select *,ISNULL((SELECT TOP (1) TradePrice FROM CDS_ROUTER.dbo.tblMatchedOrders AS q WHERE ((ReportID = d.Reference) AND (Account1 = d.CDS_Number)) OR ((ReportID = d.Reference) AND (Account2 = d.CDS_Number))),1) AS TradePrice from cds_router.dbo.trans d where d.CDS_Number='" + cdsNumber + "' and d.Company='" + recordSummary.counter + "' and d.Shares<0";
                    using (SqlConnection connection3 = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd3 = new SqlCommand(sql3, connection3);
                        cmd3.CommandType = CommandType.Text;
                        connection3.Open();
                        SqlDataReader rdr3 = cmd3.ExecuteReader();
                        while (rdr3.Read())
                        {
                            SellsByme recordSum2 = new SellsByme();
                            recordSum2.company = rdr3["Company"].ToString();
                            recordSum2.volume = rdr3["Shares"].ToString();
                            recordSum2.price = Force4DecimalPlaces(rdr3["TradePrice"].ToString());
                            recordSum2.totalValue = Force4DecimalPlaces((decimal.Parse(rdr3["TradePrice"].ToString()) * decimal.Parse(rdr3["Shares"].ToString())).ToString());
                            sellBymes.Add(recordSum2);
                        }
                    }
                    recordSummary.SellDetail = sellBymes;
                    //get my sells

                    myPortf.Add(recordSummary);
                    ix = ix + 1;
                }
            }
            return Json(myPortf, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getMarketCap()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var myPortf = new List<market_cap_>();

            var sql = "select TOP 2 * from cdsc.dbo.market_cap ";
            var ix = 1;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    market_cap_ recordSummary = new market_cap_();
                    recordSummary.id = ix.ToString();
                    recordSummary.exchange = rdr["exchange"].ToString().Trim();
                    recordSummary.market_cap = rdr["market_cap"].ToString().Trim();
                    recordSummary.trades = rdr["trades"].ToString().Trim();
                    recordSummary.turnover = rdr["turnover"].ToString().Trim();
                    myPortf.Add(recordSummary);
                    ix = ix + 1;
                }
            }
            return Json(myPortf, JsonRequestBehavior.AllowGet);
        }
        public string OrderPostingMakeNew(string company, string security, string orderTrans,
           string orderType, string quantity, string price, string cdsNumber,
           string broker, string source, string tif, string date_ = null, string corp_name = null, string corp_id = null)

        {

            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "L";
            Double basePrice = Double.Parse(price, CultureInfo.InvariantCulture); //;
            var theOrderTrans = "";

            try
            {
                var user_acc = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);
                //check for CRT
                var chk_cdc = cdsDbContext.Database.SqlQuery<Accounts_Clients_Web>("SELECT * FROM Accounts_Clients_Web where CDS_Number='" + cdsNumber + "' ").ToList().FirstOrDefault();
                var acc_type = user_acc.AccountType;

                try
                {
                    //check if account is locked
                    if (user_acc.AccountState.ToLower().Replace(" ", "") == "locked")
                    {
                        return "Your account is locked.Please Contact C-Trade Team.";
                    }
                }
                catch (Exception)
                {


                }

                //check if user is sanctioned
                if (SanctionedExsistsval(user_acc.Forenames + " " + user_acc.Surname) == 1)
                {
                    return "Order Posting failed.Please Contact C-Trade Team.";
                }

                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }


                long orderNumber = 0;
                var myCompany = "";
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }

                var theCompnay =
                    atsDbContext.para_company.OrderByDescending(x => x.ID)
                        .Where(x => x.Company == company)
                        .FirstOrDefault(x => x.Company == company);

                if (theCompnay == null)
                {
                    return "Select a valid company";
                }

                //if (int.Parse(quantity) < 50)
                //{
                //    return "Please Enter Quantity Above 50 ";
                //}

                myCompany = theCompnay.Company;
                var theCds = cdsNumber + "";

                //                var theBroker = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
                {
                    return "Enter CDS Number";
                }


                var theBroker1 = cdsDbContext.Client_Companies.FirstOrDefault(x => x.Company_Code == broker);
                if (theBroker1 == null)
                {
                    return "Enter valid broker";
                }


                //decimal shares = 0;

                //if (acc_type == "i")
                //{
                if (orderTrans.ToString().ToUpper().Equals("SELL"))
                {

                    var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                    var sql = "select * from cdsc.dbo.PortfolioAll d where d.CDS_Number=@cdsNumber and Company =@myCompany ";
                    var shareAvail = 0;
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@cdsNumber", cdsNumber);
                        cmd.Parameters.AddWithValue("@myCompany", myCompany);
                        connection.Open();
                        SqlDataReader rdr = cmd.ExecuteReader();
                        while (rdr.Read())
                        {
                            if (security.Trim().ToString() == "UNIT TRUST")
                            {
                                shareAvail = int.Parse(rdr["totAllShares"].ToString());
                            }
                            else
                            {
                                shareAvail = int.Parse(rdr["Net"].ToString());
                            }
                        }
                    }
                    decimal? finsec = 0;
                    try
                    {
                        finsec = FinsecSharessBal(cdsNumber, myCompany);
                    }
                    catch (Exception e)
                    {
                        writetofile("Finsec error" + e.ToString());
                        finsec = 0;
                    }
                    if (string.IsNullOrEmpty(shareAvail.ToString()) == true)
                    {
                        shareAvail = 0;
                    }

                    var trading = GetTradingPlaform(myCompany).ToLower();
                    //if (shareAvail < int.Parse(quantity))
                    //{
                    //    return "You have insufficient units in your account.";
                    //}
                    if (string.IsNullOrEmpty(finsec.ToString()) == false && trading == "finsec")
                    {
                        writetofile("Finsec =" + finsec + "      Quantity =" + quantity);
                        if (finsec < decimal.Parse(quantity))
                        {
                            return "You have insufficient units in your account. shareAvail" + shareAvail + "int.Parse(quantity) " + decimal.Parse(quantity);
                        }
                        else
                        {
                            shareAvail = Convert.ToInt32(finsec);
                        }
                    }
                    else
                    {
                        if (shareAvail < int.Parse(quantity))
                        {
                            return decimal.Parse(quantity) + "You have insufficient units in your account.shareAvail" + shareAvail;
                        }
                    }
                }
                //}

                //IF BUY ORDER
                var totalAmountToSpent = Double.Parse("0.0000");
                var theQuantity = 0.0000;
                if (quantity != null)
                {
                    theQuantity = Double.Parse(quantity);
                }
                if (GetTradingPlaform(myCompany).Equals("ZSE"))
                {
                    totalAmountToSpent = theQuantity * Double.Parse(price) * Double.Parse("1.01693");
                }
                else
                {
                    totalAmountToSpent = theQuantity * Double.Parse(price) * Double.Parse("1.01693");
                }
                if (!acc_type.Equals("c"))
                {
                    if (orderTrans.ToString().ToUpper().Equals("BUY"))
                    {
                        var moneyAvail =
                            tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                        if (moneyAvail != null)
                        {
                            var theCashBal =
                                tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                                    .Select(x => x.Amount)
                                    .Sum();
                            if (theCashBal <= 0 || Convert.ToDouble(theCashBal)  < totalAmountToSpent)
                            {
                                return "You have insufficient funds in your cash account theCashBal" + theCashBal + " totalAmountToSpent:" + totalAmountToSpent;
                            }
                        }
                        else
                        {
                            return "You have insufficient funds in your cash account moneyAvail" + moneyAvail;
                        }
                    }
                }
                //SAVING TO DB
                var orderStatus = "OPEN";
                if (acc_type == "c")
                {
                    orderStatus = "NOT AUTHORISED";
                }
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                var expiryDate = DateTime.Now; ;
                if (date_ == null)
                {
                    expiryDate = DateTime.ParseExact(date_, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                else
                {
                    expiryDate = DateTime.Now; ;
                }
                var brokerCode = "";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = tif;
                var orderQualifier = "None";
                //var brokerRef = theBroker1.Company_Code + "" + orderNumber;
                var contraBrokerId = "";
                var brokerRef = broker + orderNumber;
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "$";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                if (company.ToLower().Equals("usd"))
                {
                    security = "FOREX";
                }

                try
                {
                    if (string.IsNullOrEmpty(chk_cdc.CDC_Number) == false)
                    {
                        source = "CDC";
                        cdsNumber = chk_cdc.CDC_Number;
                    }


                    var orderLive = new Pre_Order_Live
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        Client_Type = acc_type,
                        Tax = 0,
                        Shareholder = cdsNumber,
                        ClientName = name,
                        TotalShareHolding = 0,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Deal_Begin_Date = dealBeginDate,
                        Expiry_Date = expiryDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        AvailableShares = 0,
                        OrderPref = orderPref,
                        OrderAttribute = orderAttrib,
                        Marketboard = marketBoard,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        ContraBrokerId = contraBrokerId,
                        MaxPrice = maxPrice,
                        MiniPrice = minPrice,
                        Flag_oldorder = flagOldOrder,
                        OrderNumber = orderNum,
                        Currency = currency,
                        trading_platform = GetTradingPlaform(myCompany),
                        Source = source,
                        FOK = false,
                        Affirmation = true,
                        Custodian = chk_cdc.BIC
                    };

                    //save to cdsc tempPreorderLive too
                    CashTrans orderCashTrans = null;

                    orderCashTrans = new CashTrans
                    {
                        Description = "BUY - Order",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount =Convert.ToDecimal(totalAmountToSpent),
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };

                    try
                    {

                        atsDbContext.Pre_Order_Live.Add(orderLive);
                        atsDbContext.SaveChanges();
                        if (orderTrans.ToString().ToUpper().Equals("BUY"))
                        {

                            tempDbContext.CashTrans.Add(orderCashTrans);
                            tempDbContext.SaveChanges();
                        }


                        return "1";
                    }
                    catch (Exception e)
                    {
                        return e.Message + " \n " + e.StackTrace; //"Error occured please contact support at ctrade@escrowgroup.org";
                    }
                }
                catch (Exception e)
                {
                    return e.Message + " \n " + e.StackTrace; //"Error occured please contact support at ctrade@escrowgroup.org";
                }

            }
            catch (Exception ex)
            {
                return ex.Message + " \n " + ex.StackTrace; //"Error occured please contact support at ctrade@escrowgroup.org";
            }
        }
        public string OrderPostingMakeNewTrust(string company, string security, string orderTrans,
     string orderType, string quantity, string price, string cdsNumber,
     string broker, string source, string tif, string date_ = null, string corp_name = null, string corp_id = null)

        {

            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "L";
            Double basePrice = Double.Parse(price, CultureInfo.InvariantCulture); //;
            var theOrderTrans = "";

            try
            {
                var user_acc = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);
                //check for CRT
                var chk_cdc = cdsDbContext.Database.SqlQuery<Accounts_Clients_Web>("SELECT * FROM Accounts_Clients_Web where CDS_Number='" + cdsNumber + "' ").ToList().FirstOrDefault();
                var acc_type = user_acc.AccountType;

                try
                {
                    //check if account is locked
                    if (user_acc.AccountState.ToLower().Replace(" ", "") == "locked")
                    {
                        return "Your account is locked.Please Contact C-Trade Team.";
                    }
                }
                catch (Exception)
                {


                }

                //check if user is sanctioned
                if (SanctionedExsistsval(user_acc.Forenames + " " + user_acc.Surname) == 1)
                {
                    return "Order Posting failed.Please Contact C-Trade Team.";
                }

                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }


                long orderNumber = 0;
                var myCompany = "";
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }

                var theCompnay =
                    atsDbContext.para_company.OrderByDescending(x => x.ID)
                        .Where(x => x.fnam.ToLower().Replace(" ", "") == company.ToLower().Replace(" ", ""))
                        .FirstOrDefault(x => x.Company == company);

                if (theCompnay == null)
                {
                    return "Select a valid company";
                }

                //if (int.Parse(quantity) < 50)
                //{
                //    return "Please Enter Quantity Above 50 ";
                //}

                myCompany = theCompnay.Company;
                var theCds = cdsNumber + "";

                //                var theBroker = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
                {
                    return "Enter CDS Number";
                }


                var theBroker1 = cdsDbContext.Client_Companies.FirstOrDefault(x => x.Company_Code == broker);
                if (theBroker1 == null)
                {
                    return "Enter valid broker";
                }


                //decimal shares = 0;

                //if (acc_type == "i")
                //{
                if (orderTrans.ToString().ToUpper().Equals("SELL"))
                {

                    var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                    var sql = "select * from cdsc.dbo.PortfolioAll d where d.CDS_Number=@cdsNumber and Company =@myCompany ";
                    var shareAvail = 0;
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@cdsNumber", cdsNumber);
                        cmd.Parameters.AddWithValue("@myCompany", myCompany);
                        connection.Open();
                        SqlDataReader rdr = cmd.ExecuteReader();
                        while (rdr.Read())
                        {
                            if (security.Trim().ToString() == "UNITTRUST")
                            {
                                shareAvail = int.Parse(rdr["totAllShares"].ToString());
                            }
                            else
                            {
                                shareAvail = int.Parse(rdr["Net"].ToString());
                            }
                            //break;
                        }
                    }
                    decimal? finsec = 0;
                    try
                    {
                        finsec = FinsecSharessBal(cdsNumber, myCompany);
                    }
                    catch (Exception)
                    {

                        finsec = 0;
                    }
                    if (string.IsNullOrEmpty(shareAvail.ToString()) == true)
                    {
                        shareAvail = 0;
                    }

                    var trading = GetTradingPlaform(myCompany).ToLower();
                    //if (shareAvail < int.Parse(quantity))
                    //{
                    //    return "You have insufficient units in your account.";
                    //}
                    if (string.IsNullOrEmpty(finsec.ToString()) == false && trading == "finsec")
                    {
                        if (finsec < int.Parse(quantity))
                        {
                            return "You have insufficient units in your account.";
                        }
                        else
                        {
                            shareAvail = Convert.ToInt32(finsec);
                        }
                    }
                    else
                    {
                        if (shareAvail < int.Parse(quantity))
                        {
                            return "You have insufficient units in your account.";
                        }
                    }
                }
                //}

                //IF BUY ORDER
                var totalAmountToSpent = decimal.Parse("0.0");
                var theQuantity = 0;
                if (quantity != null)
                {
                    theQuantity = int.Parse(quantity);
                }
                if (GetTradingPlaform(myCompany).Equals("ZSE"))
                {
                    totalAmountToSpent = theQuantity * decimal.Parse(price) * decimal.Parse("1.01693");
                }
                else
                {
                    totalAmountToSpent = theQuantity * decimal.Parse(price) * decimal.Parse("1.01693");
                }
                if (!acc_type.Equals("c"))
                {
                    if (orderTrans.ToString().ToUpper().Equals("BUY"))
                    {
                        var moneyAvail = tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                        if (moneyAvail != null)
                        {
                            var theCashBal = tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber).Select(x => x.Amount).Sum();
                            if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                            {
                                return "You have insufficient funds in your cash account theCashBal:" + theCashBal + " totalAmountToSpent:" + totalAmountToSpent;
                            }
                        }
                        else
                        {
                            return "You have insufficient funds in your cash account moneyAvail " + moneyAvail + " totalAmountToSpent: " + totalAmountToSpent;
                        }
                    }
                }
                //SAVING TO DB
                var orderStatus = "OPEN";
                if (acc_type == "c")
                {
                    orderStatus = "NOT AUTHORISED";
                }
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                var expiryDate = DateTime.Now; ;
                if (date_ == null)
                {
                    expiryDate = DateTime.ParseExact(date_, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                else
                {
                    expiryDate = DateTime.Now; ;
                }
                var brokerCode = "";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = tif;
                var orderQualifier = "None";
                //var brokerRef = theBroker1.Company_Code + "" + orderNumber;
                var contraBrokerId = "";
                var brokerRef = broker + orderNumber;
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "$";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                if (company.ToLower().Equals("usd"))
                {
                    security = "FOREX";
                }

                try
                {
                    if (string.IsNullOrEmpty(chk_cdc.CDC_Number) == false)
                    {
                        source = "CDC";
                        cdsNumber = chk_cdc.CDC_Number;
                    }


                    var orderLive = new Pre_Order_Live
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        Client_Type = acc_type,
                        Tax = 0,
                        Shareholder = cdsNumber,
                        ClientName = name,
                        TotalShareHolding = 0,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Deal_Begin_Date = dealBeginDate,
                        Expiry_Date = expiryDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        AvailableShares = 0,
                        OrderPref = orderPref,
                        OrderAttribute = orderAttrib,
                        Marketboard = marketBoard,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        ContraBrokerId = contraBrokerId,
                        MaxPrice = maxPrice,
                        MiniPrice = minPrice,
                        Flag_oldorder = flagOldOrder,
                        OrderNumber = orderNum,
                        Currency = currency,
                        trading_platform = GetTradingPlaform(myCompany),
                        Source = source,
                        FOK = false,
                        Affirmation = true,
                        Custodian = chk_cdc.BIC
                    };

                    //save to cdsc tempPreorderLive too
                    CashTrans orderCashTrans = null;

                    orderCashTrans = new CashTrans
                    {
                        Description = "BUY - Order",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -totalAmountToSpent,
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };

                    try
                    {

                        atsDbContext.Pre_Order_Live.Add(orderLive);
                        atsDbContext.SaveChanges();
                        if (orderTrans.ToString().ToUpper().Equals("BUY"))
                        {

                            tempDbContext.CashTrans.Add(orderCashTrans);
                            tempDbContext.SaveChanges();
                        }


                        return "1";
                    }
                    catch (Exception e)
                    {
                        return e.Message + " \n " + e.StackTrace; //"Error occured please contact support at ctrade@escrowgroup.org";
                    }
                }
                catch (Exception e)
                {
                    return e.Message + " \n " + e.StackTrace; //"Error occured please contact support at ctrade@escrowgroup.org";
                }

            }
            catch (Exception ex)
            {
                return ex.Message + " \n " + ex.StackTrace; //"Error occured please contact support at ctrade@escrowgroup.org";
            }
        }

        public string OrderPostingMakeNewGroup(string company, string security, string orderTrans,
         string orderType, string quantity, string price, string cdsNumber,
         string broker, string source, string tif, string date_ = null, string corp_name = null, string corp_id = null)

        {

            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "L";
            Double basePrice = Double.Parse(price, CultureInfo.InvariantCulture); //;
            var theOrderTrans = "";

            try
            {
                var acc_type = "1";
                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }


                long orderNumber = 0;
                var myCompany = "";
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }

                var theCompnay =
                    atsDbContext.para_company.OrderByDescending(x => x.ID)
                        .Where(x => x.Company == company)
                        .FirstOrDefault(x => x.Company == company);

                if (theCompnay == null)
                {
                    return "Select a valid company";
                }

                //if (int.Parse(quantity) < 50)
                //{
                //    return "Please Enter Quantity Above 50 ";
                //}

                myCompany = theCompnay.Company;
                var theCds = cdsNumber;

                var theBroker1 = cdsDbContext.Client_Companies.FirstOrDefault(x => x.Company_Code == broker);
                if (theBroker1 == null)
                {
                    return "Enter valid broker";
                }


                //decimal shares = 0;

                //if (acc_type == "i")
                //{
                if (orderTrans.ToString().ToUpper().Equals("SELL"))
                {

                    var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                    var sql = "select * from cdsc.dbo.PortfolioAll d where d.CDS_Number=@cdsNumber and Company =@myCompany ";
                    var shareAvail = 0;
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@cdsNumber", cdsNumber);
                        cmd.Parameters.AddWithValue("@myCompany", myCompany);
                        connection.Open();
                        SqlDataReader rdr = cmd.ExecuteReader();
                        while (rdr.Read())
                        {
                            shareAvail = int.Parse(rdr["Net"].ToString());
                            //break;
                        }
                    }
                    decimal? finsec = 0;
                    try
                    {
                        finsec = FinsecSharessBal(cdsNumber, myCompany);
                    }
                    catch (Exception)
                    {

                        finsec = 0;
                    }
                    if (string.IsNullOrEmpty(shareAvail.ToString()) == true)
                    {
                        shareAvail = 0;
                    }

                    var trading = GetTradingPlaform(myCompany).ToLower();
                    //if (shareAvail < int.Parse(quantity))
                    //{
                    //    return "You have insufficient units in your account.";
                    //}
                    if (string.IsNullOrEmpty(finsec.ToString()) == false && trading == "finsec")
                    {
                        if (finsec < int.Parse(quantity))
                        {
                            return "You have insufficient units in your account.";
                        }
                        else
                        {
                            shareAvail = Convert.ToInt32(finsec);
                        }
                    }
                    else
                    {
                        if (shareAvail < int.Parse(quantity))
                        {
                            return "You have insufficient units in your account.";
                        }
                    }
                }
                //}

                //IF BUY ORDER
                var totalAmountToSpent = decimal.Parse("0.0");
                var theQuantity = 0;
                if (quantity != null)
                {
                    theQuantity = int.Parse(quantity);
                }
                if (GetTradingPlaform(myCompany).Equals("ZSE"))
                {
                    totalAmountToSpent = theQuantity * decimal.Parse(price) * decimal.Parse("1.01693");
                }
                else
                {
                    totalAmountToSpent = theQuantity * decimal.Parse(price) * decimal.Parse("1.01693");
                }
                if (!acc_type.Equals("c"))
                {
                    if (orderTrans.ToString().ToUpper().Equals("BUY"))
                    {
                        var moneyAvail =
                            tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                        if (moneyAvail != null)
                        {
                            var theCashBal =
                                tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                                    .Select(x => x.Amount)
                                    .Sum();
                            if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                            {
                                return "You have insufficient funds in your cash account";
                            }
                        }
                        else
                        {
                            return "You have insufficient funds in your cash account";
                        }
                    }
                }
                //SAVING TO DB
                var orderStatus = "OPEN";
                if (acc_type == "c")
                {
                    orderStatus = "NOT AUTHORISED";
                }
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                var expiryDate = DateTime.Now; ;
                if (date_ == null)
                {
                    expiryDate = DateTime.ParseExact(date_, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                else
                {
                    expiryDate = DateTime.Now; ;
                }
                var brokerCode = "";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = tif;
                var orderQualifier = "None";
                //var brokerRef = theBroker1.Company_Code + "" + orderNumber;
                var contraBrokerId = "";
                var brokerRef = broker + orderNumber;
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "$";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                if (company.ToLower().Equals("usd"))
                {
                    security = "FOREX";
                }

                try
                {
                    var orderLive = new Pre_Order_Live
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        Client_Type = acc_type,
                        Tax = 0,
                        Shareholder = cdsNumber,
                        ClientName = name,
                        TotalShareHolding = 0,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Deal_Begin_Date = dealBeginDate,
                        Expiry_Date = expiryDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        AvailableShares = 0,
                        OrderPref = orderPref,
                        OrderAttribute = orderAttrib,
                        Marketboard = marketBoard,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        ContraBrokerId = contraBrokerId,
                        MaxPrice = maxPrice,
                        MiniPrice = minPrice,
                        Flag_oldorder = flagOldOrder,
                        OrderNumber = orderNum,
                        Currency = currency,
                        trading_platform = GetTradingPlaform(myCompany),
                        Source = source,
                        FOK = false,

                        Affirmation = true
                    };

                    //save to cdsc tempPreorderLive too
                    CashTrans orderCashTrans = null;

                    orderCashTrans = new CashTrans
                    {
                        Description = "BUY - Order",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -totalAmountToSpent,
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };

                    try
                    {

                        atsDbContext.Pre_Order_Live.Add(orderLive);
                        atsDbContext.SaveChanges();
                        if (orderTrans.ToString().ToUpper().Equals("BUY"))
                        {

                            tempDbContext.CashTrans.Add(orderCashTrans);
                            tempDbContext.SaveChanges();
                        }


                        return "1";
                    }
                    catch (Exception e)
                    {
                        return "Error occured please contact support at ctrade@escrowgroup.org";
                    }
                }
                catch (Exception e)
                {
                    return "Error occured please contact support at ctrade@escrowgroup.org";
                }

            }
            catch (Exception ex)
            {
                return "Error occured please contact support at ctrade@escrowgroup.org";
            }
        }

        public string OrderPostingAutoTrade(string company, string security, string orderTrans,
           string orderType, string quantity, string price, string cdsNumber,
           string broker, string source, string tif, string date_ = null, string ostatus = null)

        {

            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "L";
            Double basePrice = Double.Parse(price, CultureInfo.InvariantCulture); //;
            var theOrderTrans = "";

            try
            {
                var user_acc = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);
                var acc_type = user_acc.AccountType;
                //SanctionedList
                //check if user is sanctioned
                if (SanctionedExsistsval(user_acc.Forenames + " " + user_acc.Surname) == 1)
                {
                    return "Order Posting failed.Please Contact C-Trade Team.";
                }
                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }


                long orderNumber = 0;
                var myCompany = "";
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }

                var theCompnay =
                    atsDbContext.para_company.OrderByDescending(x => x.ID)
                        .Where(x => x.Company == company)
                        .FirstOrDefault(x => x.Company == company);

                if (theCompnay == null)
                {
                    return "Select a valid company";
                }

                //if (int.Parse(quantity) < 50)
                //{
                //    return "Please Enter Quantity Above 50 ";
                //}

                myCompany = theCompnay.Company;
                var theCds = cdsNumber + "";

                //                var theBroker = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
                {
                    return "Enter CDS Number";
                }


                var theBroker1 = cdsDbContext.Client_Companies.FirstOrDefault(x => x.Company_Code == broker);
                if (theBroker1 == null)
                {
                    return "Enter valid broker";
                }


                //decimal shares = 0;

                //if (acc_type == "i")
                //{
                //if (orderTrans.ToString().ToUpper().Equals("SELL"))
                //{

                //    var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                //    var sql = "select * from cdsc.dbo.PortfolioAll d where d.CDS_Number='" + cdsNumber + "' and Company = '" + myCompany + "' ";
                //    var shareAvail = 0;
                //    using (SqlConnection connection = new SqlConnection(connectionString))
                //    {
                //        SqlCommand cmd = new SqlCommand(sql, connection);
                //        cmd.CommandType = CommandType.Text;
                //        connection.Open();
                //        SqlDataReader rdr = cmd.ExecuteReader();
                //        while (rdr.Read())
                //        {
                //            shareAvail = int.Parse(rdr["Net"].ToString());
                //            //break;
                //        }
                //    }
                //    if (shareAvail < int.Parse(quantity))
                //    {
                //        return "You have insufficient units in your account.";
                //    }

                //}
                ////}

                ////IF BUY ORDER
                //var totalAmountToSpent = decimal.Parse("0.0");
                //var theQuantity = 0;
                //if (quantity != null)
                //{
                //    theQuantity = int.Parse(quantity);
                //}
                //if (GetTradingPlaform(myCompany).Equals("ZSE"))
                //{
                //    totalAmountToSpent = theQuantity * decimal.Parse(price) * decimal.Parse("1.01693");
                //}
                //else
                //{
                //    totalAmountToSpent = theQuantity * decimal.Parse(price) * decimal.Parse("1.01693");
                //}
                //if (acc_type == "i")
                //{
                //    if (orderTrans.ToString().ToUpper().Equals("BUY"))
                //    {
                //        var moneyAvail =
                //            tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                //        if (moneyAvail != null)
                //        {
                //            var theCashBal =
                //                tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                //                    .Select(x => x.Amount)
                //                    .Sum();
                //            if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                //            {
                //                return "You have insufficient funds in your cash account";
                //            }
                //        }
                //        else
                //        {
                //            return "You have insufficient funds in your cash account";
                //        }
                //    }
                //}
                //SAVING TO DB
                var orderStatus = ostatus;
                if (acc_type == "c")
                {
                    orderStatus = "NOT AUTHORISED";
                }
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                var expiryDate = DateTime.Now; ;
                if (date_ == null)
                {
                    expiryDate = DateTime.ParseExact(date_, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                else
                {
                    expiryDate = DateTime.Now; ;
                }
                var brokerCode = "";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = tif;
                var orderQualifier = "None";
                //var brokerRef = theBroker1.Company_Code + "" + orderNumber;
                var contraBrokerId = "";
                var brokerRef = broker + orderNumber;
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "$";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                if (company.ToLower().Equals("usd"))
                {
                    security = "FOREX";
                }

                try
                {
                    var orderLive = new Pre_Order_Live
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        Client_Type = acc_type,
                        Tax = 0,
                        Shareholder = cdsNumber,
                        ClientName = name,
                        TotalShareHolding = 0,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Deal_Begin_Date = dealBeginDate,
                        Expiry_Date = expiryDate,
                        Quantity = int.Parse(quantity),
                        BasePrice = basePrice,
                        AvailableShares = 0,
                        OrderPref = orderPref,
                        OrderAttribute = orderAttrib,
                        Marketboard = marketBoard,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        ContraBrokerId = contraBrokerId,
                        MaxPrice = maxPrice,
                        MiniPrice = minPrice,
                        Flag_oldorder = flagOldOrder,
                        OrderNumber = orderNum,
                        Currency = currency,
                        trading_platform = GetTradingPlaform(myCompany),
                        FOK = false,

                        Affirmation = true
                    };

                    //save to cdsc tempPreorderLive too
                    CashTrans orderCashTrans = null;

                    orderCashTrans = new CashTrans
                    {
                        Description = "BUY - Order",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -1,
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };

                    try
                    {

                        atsDbContext.Pre_Order_Live.Add(orderLive);
                        atsDbContext.SaveChanges();
                        if (orderTrans.ToString().ToUpper().Equals("BUY"))
                        {

                            tempDbContext.CashTrans.Add(orderCashTrans);
                            //tempDbContext.SaveChanges();
                        }


                        return "1";
                    }
                    catch (Exception e)
                    {
                        return "error 1 " + e.ToString();
                    }
                }
                catch (Exception e)
                {
                    return "Error 2 " + e.ToString();
                }

            }
            catch (Exception ex)
            {
                return "Error 3 " + ex.ToString();
            }
        }

        public string OrderPostingInvestmentGroup(string company, string security, string orderTrans,
          string orderType, string quantity, string price, string cdsNumber,
          string broker, string source, string tif, string clubphone, string date_ = null)

        {

            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "L";
            Double basePrice = Double.Parse(price, CultureInfo.InvariantCulture); //;
            var theOrderTrans = "";

            try
            {
                var user_acc = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);
                var acc_type = user_acc.AccountType;
                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }


                long orderNumber = 0;
                var myCompany = "";
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }

                var theCompnay =
                    atsDbContext.para_company.OrderByDescending(x => x.ID)
                        .Where(x => x.fnam == company)
                        .FirstOrDefault(x => x.fnam == company);

                if (theCompnay == null)
                {
                    return "Select a valid company";
                }

                //if (int.Parse(quantity) < 50)
                //{
                //    return "Please Enter Quantity Above 50 ";
                //}

                myCompany = theCompnay.Company;
                var theCds = cdsNumber + "";

                //                var theBroker = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
                {
                    return "Enter CDS Number";
                }


                var theBroker1 = cdsDbContext.Client_Companies.FirstOrDefault(x => x.Company_Code == broker);
                if (theBroker1 == null)
                {
                    return "Enter valid broker";
                }


                //decimal shares = 0;

                //if (acc_type == "i")
                //{
                if (orderTrans.ToString().ToUpper().Equals("SELL"))
                {

                    var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                    var sql = "select * from cdsc.dbo.PortfolioAll d where d.CDS_Number='" + cdsNumber + "' and Company = '" + myCompany + "' ";
                    var shareAvail = 0;
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        connection.Open();
                        SqlDataReader rdr = cmd.ExecuteReader();
                        while (rdr.Read())
                        {
                            shareAvail = int.Parse(rdr["Net"].ToString());
                            //break;
                        }
                    }
                    if (shareAvail < int.Parse(quantity))
                    {
                        return "You have insufficient units in your account.";
                    }

                }
                //}

                //IF BUY ORDER
                var totalAmountToSpent = decimal.Parse("0.0");
                var theQuantity = 0;
                var checkaccounts = from club in _cdscDbContext.club_members
                                    where club.club_phone == clubphone
                                    select club;
                var membercontribution = decimal.Parse("0.0");

                if (quantity != null)
                {
                    theQuantity = int.Parse(quantity);
                }

                if (GetTradingPlaform(myCompany).Equals("ZSE"))
                {
                    totalAmountToSpent = theQuantity * decimal.Parse(price) * decimal.Parse("1.01693");
                }
                else
                {
                    totalAmountToSpent = theQuantity * decimal.Parse(price) * decimal.Parse("1.01693");
                }

                if (!acc_type.Equals(""))
                {
                    if (orderTrans.ToString().ToUpper().Equals("BUY"))
                    {

                        bool commit = true;

                        var membercount = checkaccounts.Count();

                        if (int.Parse(quantity) % membercount != 0)
                        {
                            return "Number of shares placed not equally distributable amongst club members";
                        }

                        membercontribution = totalAmountToSpent / membercount;

                        foreach (var chk in checkaccounts)
                        {

                            if (chkAmounts(chk.member_cds_number) < membercontribution)
                            {
                                commit = false;
                            }
                        }

                        if (commit == false)
                        {
                            return "One or more members do not have sufficient funds";
                        }
                    }
                }
                //SAVING TO DB
                var orderStatus = "OPEN";
                if (acc_type == "c")
                {
                    orderStatus = "NOT AUTHORISED";
                }
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                var expiryDate = DateTime.Now; ;
                if (date_ == null)
                {
                    expiryDate = DateTime.ParseExact(date_, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                else
                {
                    expiryDate = DateTime.Now; ;
                }
                var brokerCode = "";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = tif;
                var orderQualifier = "None";
                //var brokerRef = theBroker1.Company_Code + "" + orderNumber;
                var contraBrokerId = "";
                var brokerRef = broker + orderNumber;
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "$";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                if (company.ToLower().Equals("usd"))
                {
                    security = "FOREX";
                }

                try
                {
                    var orderLive = new Pre_Order_Live
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        Client_Type = acc_type,
                        Tax = 0,
                        Shareholder = cdsNumber,
                        ClientName = name,
                        TotalShareHolding = 0,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Deal_Begin_Date = dealBeginDate,
                        Expiry_Date = expiryDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        AvailableShares = 0,
                        OrderPref = orderPref,
                        OrderAttribute = orderAttrib,
                        Marketboard = marketBoard,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        ContraBrokerId = contraBrokerId,
                        MaxPrice = maxPrice,
                        MiniPrice = minPrice,
                        Flag_oldorder = flagOldOrder,
                        OrderNumber = orderNum,
                        Currency = currency,
                        trading_platform = GetTradingPlaform(myCompany),
                        FOK = false,

                        Affirmation = true
                    };

                    //save to cdsc tempPreorderLive too
                    CashTrans orderCashTrans = null;

                    foreach (var chk in checkaccounts)
                    {

                        orderCashTrans = new CashTrans
                        {
                            Description = "BUY - Order",
                            TransType = "BUY",
                            TransStatus = "1",
                            Amount = -membercontribution,
                            CDS_Number = chk.member_cds_number,
                            DateCreated = DateTime.Now
                        };

                        tempDbContext.CashTrans.Add(orderCashTrans);

                    }

                    try
                    {

                        atsDbContext.Pre_Order_Live.Add(orderLive);
                        atsDbContext.SaveChanges();
                        if (orderTrans.ToString().ToUpper().Equals("BUY"))
                        {

                            tempDbContext.SaveChanges();
                        }


                        return "Your order has been posted successfully";
                    }
                    catch (Exception e)
                    {
                        return "1 " + e.ToString();
                    }
                }
                catch (Exception e)
                {
                    return "2 " + e.ToString();
                }

            }
            catch (Exception ex)
            {
                return "3 " + ex.ToString();
            }
        }
        public decimal? chkAmounts(string cds)
        {
            decimal? cashAmt = _cdscDbContext.CashTrans.Where(a => a.CDS_Number == cds && a.TransStatus == "1").Sum(a => a.Amount);

            if (cashAmt == null)
            {
                return 0;
            }

            return cashAmt;
        }
        public string OrderPostingIPO(string company, string security, string orderTrans,
    string orderType, string quantity, string price, string cdsNumber,
    string broker, string source, string corp_name = null, string corp_id = null)

        {
            var tot = Math.Round(decimal.Parse(price) * int.Parse(quantity), 2);
            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "L";
            Double basePrice = Double.Parse(price, CultureInfo.InvariantCulture);
            var theOrderTrans = "";

            try
            {
                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }





                long orderNumber = 0;
                var myCompany = "";
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }

                //var theCompnay =
                //    atsDbContext.para_company.OrderByDescending(x => x.ID)
                //        .Where(x => x.Company == company)
                //        .FirstOrDefault(x => x.Company == company);

                //if (theCompnay == null)
                //{
                //    return "Select a valid company";
                //}

                myCompany = company;
                var theCds = cdsNumber + "";

                //                var theBroker = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
                {
                    return "Enter CDS Number";
                }


                var theBroker1 = cdsDbContext.Client_Companies.FirstOrDefault(x => x.Company_Code == broker);
                if (theBroker1 == null)
                {
                    return "Enter valid broker";
                }

                var returnVal = LIMITS_CHECK(myCompany, cdsNumber, quantity);
                if (returnVal != "0")
                {
                    return returnVal;
                }

                //decimal shares = 0;
                if (corp_name == null)
                {
                    if (orderTrans.ToString().ToUpper().Equals("SELL"))
                    {

                        var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                        var sql = "select * from cdsc.dbo.PortfolioAll d where d.CDS_Number='" + cdsNumber + "' and Company = '" + myCompany + "' ";
                        var shareAvail = 0;
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            SqlCommand cmd = new SqlCommand(sql, connection);
                            cmd.CommandType = CommandType.Text;
                            connection.Open();
                            SqlDataReader rdr = cmd.ExecuteReader();
                            while (rdr.Read())
                            {
                                shareAvail = int.Parse(rdr["Net"].ToString());
                                //break;
                            }
                        }
                        if (shareAvail < int.Parse(quantity))
                        {
                            return "You have insufficient shares, please contact Support at ctrade@escrowgroup.org";
                        }

                    }
                }


                //IF BUY ORDER
                var totalAmountToSpent = decimal.Parse(quantity) * decimal.Parse(price);
                if (corp_name == null)
                {
                    if (orderTrans.ToString().ToUpper().Equals("BUY"))
                    {
                        var moneyAvail =
                            tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                        if (moneyAvail != null)
                        {
                            var theCashBal =
                                tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                                    .Select(x => x.Amount)
                                    .Sum();
                            if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                            {
                                return "You have insufficient balance in your Cash account";
                            }
                        }
                        else
                        {
                            return "You have insufficient balance in your Cash account";
                        }
                    }
                }
                //SAVING TO DB


                var orderStatus = "OPEN";
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                var expiryDate = DateTime.Now;
                var theQuantity = 0;


                if (quantity != null)
                {
                    theQuantity = int.Parse(quantity);
                }


                var brokerCode = "";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = "Day Order (DO)";
                var orderQualifier = "None";
                var brokerRef = broker + orderNumber;
                var contraBrokerId = "";
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "USD";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                try
                {

                    //save to cdsc tempPreorderLive too
                    var orderPreorderCdsc = new PreOrderLivesIPOesV2
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = theBroker1.Company_Code,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Expiry_Date = createdDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        OrderNumber = orderNum,
                        Source = source,
                        corp_name = corp_name,
                        corp_id = corp_id,
                        authorised_status = "not authorised"
                    };

                    //save to cdsc tempPreorderLive too
                    var orderCashTrans = new CashTrans
                    {
                        Description = "BUY - IPO",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -totalAmountToSpent,
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };
                    try
                    {
                        //                      var emailAdd = theBroker.Email;
                        //atsDbContext.Pre_Order_Live.Add(orderLive);
                        //atsDbContext.SaveChanges();
                        //                      SendMail2(emailAdd, "Your order was successfully posted", "Order Posting");



                        if (corp_name == null)
                        {
                            tempDbContext.CashTrans.Add(orderCashTrans);
                            tempDbContext.SaveChanges();

                            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                SqlCommand cmdn = new SqlCommand();
                                cmdn.Connection = connection;
                                cmdn.CommandType = CommandType.StoredProcedure;
                                cmdn.CommandText = "AReceiveBidsIPO";
                                cmdn.Parameters.AddWithValue("@Bank", "0");
                                cmdn.Parameters.AddWithValue("@Branch", "0");
                                cmdn.Parameters.AddWithValue("@Accountnumber", "0");
                                cmdn.Parameters.AddWithValue("@No_of_Notes_Applied", quantity);
                                cmdn.Parameters.AddWithValue("@AmountPaid", tot);
                                cmdn.Parameters.AddWithValue("@PaymentRefNo", "Escrow");
                                cmdn.Parameters.AddWithValue("@ClientType", "LI");
                                cmdn.Parameters.AddWithValue("@BrokerReference", "OMSEC");
                                cmdn.Parameters.AddWithValue("@DividendDisposalPreference", "M");
                                cmdn.Parameters.AddWithValue("@MNO_", "ONLINE");
                                cmdn.Parameters.AddWithValue("@Identification", cdsNumber);
                                cmdn.Parameters.AddWithValue("@TelephoneNumber", cdsNumber);
                                cmdn.Parameters.AddWithValue("@CDSC_Number", cdsNumber);
                                cmdn.Parameters.AddWithValue("@ReceiptNumber", "Escrow");
                                cmdn.Parameters.AddWithValue("@Company", company);
                                //cmdn.Parameters.AddWithValue("@Custodian", "0");
                                //cmdn.Parameters.AddWithValue("@TransNum", "0");
                                //cmdn.Parameters.AddWithValue("@PledgeIndicator", "0");
                                //cmdn.Parameters.AddWithValue("@PledgeeBPID", cdsNumber);
                                connection.Open();
                                if (cmdn.ExecuteNonQuery() > 0)
                                {
                                    connection.Close();
                                    return "1";
                                }
                                else
                                {
                                    connection.Close();
                                    return "Error saving IPO";
                                }
                            }
                        }
                        else
                        {
                            tempDbContext.PreOrderLivesIPOesV2.Add(orderPreorderCdsc);
                            tempDbContext.SaveChanges();
                            return "1";
                        }

                        //return "1";
                    }
                    catch (Exception e)
                    {
                        return "Error occured please try again";
                    }
                }
                catch (Exception e)
                {
                    return "Error occured please try again";
                }

            }
            catch (Exception ex)
            {
                return "Error occured please try again";
            }
        }
        public string OrderIPOPostingPOSTANDROID(string company, string quantity, string price, string cdsNumber, string corp_name = null, string corp_id = null)
        {
            var tot = Math.Round(decimal.Parse(price) * int.Parse(quantity), 2);


            var returnVal = LIMITS_CHECK(company, cdsNumber, quantity);
            if (returnVal != "0")
            {
                return returnVal;
            }
            //IF BUY ORDER
            var totalAmountToSpent = decimal.Parse(quantity) * decimal.Parse(price);
            var tempDbContext = new cdscDbContext();
            var moneyAvail =
                    tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

            var orderStatus = "OPEN";
            var createdDate = DateTime.Now;
            var dealBeginDate = DateTime.Now;
            var expiryDate = DateTime.Now;
            var theQuantity = 0;
            Double basePrice = Double.Parse(price, CultureInfo.InvariantCulture);
            var timeInForce = "Day Order (DO)";
            var orderQualifier = "None";
            //save to cdsc tempPreorderLive too
            var orderPreorderCdsc = new PreOrderLivesIPOesV2
            {
                OrderType = "Buy",
                Company = company,
                SecurityType = "Equity",
                CDS_AC_No = cdsNumber,
                Broker_Code = "OMSEC",
                OrderStatus = "OPEN",
                Create_date = createdDate,
                Expiry_Date = createdDate,
                Quantity = theQuantity,
                BasePrice = basePrice,
                TimeInForce = timeInForce,
                OrderQualifier = orderQualifier,
                BrokerRef = "OMSEC",
                OrderNumber = "12",
                Source = "Online",
                corp_name = corp_name,
                corp_id = corp_id,
                authorised_status = "not authorised"
            };


            if (corp_name == null)
            {
                if (moneyAvail != null)
                {
                    var theCashBal =
                        tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                            .Select(x => x.Amount)
                            .Sum();
                    if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                    {
                        return "You have insufficient balance in your Cash account";
                    }
                }
                else
                {
                    return "You have insufficient balance in your Cash account";
                }


                var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    //String mycds_ = GetCdsNumberFROMMOBILE(mobile);
                    SqlCommand cmdn = new SqlCommand();
                    cmdn.Connection = connection;
                    cmdn.CommandType = CommandType.StoredProcedure;
                    cmdn.CommandText = "AReceiveBidsIPO";
                    cmdn.Parameters.AddWithValue("@Bank", "0");
                    cmdn.Parameters.AddWithValue("@Branch", "0");
                    cmdn.Parameters.AddWithValue("@Accountnumber", "0");
                    cmdn.Parameters.AddWithValue("@No_of_Notes_Applied", quantity);
                    cmdn.Parameters.AddWithValue("@AmountPaid", tot);
                    cmdn.Parameters.AddWithValue("@PaymentRefNo", "Escrow");
                    cmdn.Parameters.AddWithValue("@ClientType", "LI");
                    cmdn.Parameters.AddWithValue("@BrokerReference", "OMSEC");
                    cmdn.Parameters.AddWithValue("@DividendDisposalPreference", "M");
                    cmdn.Parameters.AddWithValue("@MNO_", "ANDROID");
                    cmdn.Parameters.AddWithValue("@Identification", cdsNumber);
                    cmdn.Parameters.AddWithValue("@TelephoneNumber", "");
                    cmdn.Parameters.AddWithValue("@CDSC_Number", cdsNumber);
                    cmdn.Parameters.AddWithValue("@ReceiptNumber", "Escrow");
                    cmdn.Parameters.AddWithValue("@Company", company);
                    //cmdn.Parameters.AddWithValue("@Custodian", "0");
                    //cmdn.Parameters.AddWithValue("@TransNum", "0");
                    //cmdn.Parameters.AddWithValue("@PledgeIndicator", "0");
                    //cmdn.Parameters.AddWithValue("@PledgeeBPID", cdsNumber);
                    connection.Open();
                    if (cmdn.ExecuteNonQuery() > 0)
                    {
                        connection.Close();
                        //save to cdsc tempPreorderLive too
                        var orderCashTrans = new CashTrans
                        {
                            Description = "IPO - BUY",
                            TransType = "BUY",
                            TransStatus = "1",
                            Amount = -totalAmountToSpent,
                            CDS_Number = cdsNumber,
                            DateCreated = DateTime.Now
                        };

                        tempDbContext.CashTrans.Add(orderCashTrans);
                        tempDbContext.SaveChanges();
                        return "Order placed successfully";
                    }
                    else
                    {
                        connection.Close();
                        return "Error placing order";
                    }
                }
            }
            else
            {
                tempDbContext.PreOrderLivesIPOesV2.Add(orderPreorderCdsc);
                tempDbContext.SaveChanges();
                return "Company Primary Order placed successfully";
            }

        }
        public JsonResult getCompDetails(string cdsNumber, string email)
        {
            var getBrk = "SELECT [comp_authorizer],[comp_initiator] FROM[CDSC].[dbo].[Vatenkecis] where Email = '" + email + "'   and CdsNumber = '" + cdsNumber + "' ";

            var order = new compdetails();
            var list = new List<compdetails>();
            using (var connection = new SqlConnection(connectionStringCDS_Router))
            {
                var cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                var rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        order.comp_authorizer = rdr["comp_authorizer"].ToString();
                        order.comp_initiator = rdr["comp_initiator"].ToString();

                        list.Add(order);
                    }

                    try
                    {
                        var jsonResult = Json(list, JsonRequestBehavior.AllowGet);
                        jsonResult.MaxJsonLength = int.MaxValue;
                        return jsonResult;
                    }
                    catch (Exception)
                    {
                        return Json("Error loading details", JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json("Error loading details", JsonRequestBehavior.AllowGet);
                }
            }
        }
        public JsonResult getAllDetails(string cdsNumber)
        {
            var getBrk = "SELECT  TOP 1  ISNULL(ut.min_value_threshold , 10) as min_value_threshold , " +
                            " t.* From[CDS_ROUTER].[dbo].[Accounts_Clients] t left join[CDS_ROUTER].[dbo].[Client_Companies] ut on " +
                            " ut.Company_Code = t.BrokerCode " +
                            " where t. CDS_Number = '" + cdsNumber + "' ";

            var order = new Accounts_Clients_MYPROF();
            var listOfBrokers = new List<Accounts_Clients_MYPROF>();
            using (var connection = new SqlConnection(connectionStringCDS_Router))
            {
                var cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                var rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        order.BrokerCode = rdr["BrokerCode"].ToString();
                        order.AccountType = rdr["AccountType"].ToString();
                        order.Title = rdr["Title"].ToString();
                        order.Nationality = rdr["Nationality"].ToString();
                        order.Add_1 = rdr["Add_1"].ToString();
                        order.Country = rdr["Country"].ToString();
                        order.Mobile = rdr["Mobile"].ToString();
                        order.Email = rdr["Email"].ToString();
                        order.Custodian = rdr["Custodian"].ToString();
                        order.Cash_Bank = rdr["Cash_Bank"].ToString();
                        order.Cash_Branch = rdr["Cash_Branch"].ToString();
                        order.Cash_AccountNo = rdr["Cash_AccountNo"].ToString();
                        order.idnopp = rdr["idnopp"].ToString();
                        order.mobile_number = rdr["mobile_number"].ToString();
                        order.CDS_Number = rdr["CDS_Number"].ToString();
                        order.Surname = rdr["Surname"].ToString();
                        order.Forenames = rdr["Forenames"].ToString();
                        order.min_value_threshold = rdr["min_value_threshold"].ToString();
                        listOfBrokers.Add(order);
                    }

                    try
                    {
                        var jsonResult = Json(listOfBrokers, JsonRequestBehavior.AllowGet);
                        jsonResult.MaxJsonLength = int.MaxValue;
                        return jsonResult;
                    }
                    catch (Exception)
                    {
                        return Json("Error loading details", JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json("Error loading details", JsonRequestBehavior.AllowGet);
                }
            }
        }
        public JsonResult GetBrokers(string company = null)
        {
            var getBrk =
                "  select Company_Code as Code, ISNULL(min_value_threshold , 10) as min_value_threshold , upper(Company_name) as Name  FROM [CDS_ROUTER].[dbo].[Client_Companies] where Company_type='BROKER'";


            var listOfBrokers = new List<Broker>();
            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Broker broker = new Broker();
                    broker.Code = rdr["Code"].ToString();
                    broker.threshold = rdr["min_value_threshold"].ToString();
                    broker.Name = rdr["Name"].ToString();
                    listOfBrokers.Add(broker);
                }

                try
                {
                    var jsonResult = Json(listOfBrokers, JsonRequestBehavior.AllowGet);
                    jsonResult.MaxJsonLength = int.MaxValue;
                    return jsonResult;
                }
                catch (Exception)
                {
                    return Json("Data set too large", JsonRequestBehavior.AllowGet);
                }
            }
        }
        public JsonResult GetCatalyst(string company_type)
        {
            var getBrk =
                "  select Company_Code as Code, ISNULL(min_value_threshold , 1) as min_value_threshold , upper(Company_name) as Name  FROM [CDS_ROUTER].[dbo].[Client_Companies] where Company_type='" + company_type + "'";


            var listOfBrokers = new List<Broker>();
            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Broker broker = new Broker
                    {
                        Code = rdr["Code"].ToString(),
                        threshold = rdr["min_value_threshold"].ToString(),
                        Name = rdr["Name"].ToString()
                    };
                    listOfBrokers.Add(broker);
                }

                try
                {
                    var jsonResult = Json(listOfBrokers, JsonRequestBehavior.AllowGet);
                    jsonResult.MaxJsonLength = int.MaxValue;
                    return jsonResult;
                }
                catch (Exception)
                {
                    return Json("Data set too large", JsonRequestBehavior.AllowGet);
                }
            }
        }
        public JsonResult GetCustodian(string company = null)
        {
            var getBrk =
                "select Company_Code as Code, ISNULL(min_value_threshold , 10) as  min_value_threshold, upper(Company_name) as Name  FROM [CDS_ROUTER].[dbo].[Client_Companies] where Company_type='CUSTODIAN'";

            var listOfBrokers = new List<Broker>();
            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Broker broker = new Broker();
                    broker.Code = rdr["Code"].ToString();
                    broker.threshold = rdr["min_value_threshold"].ToString();
                    broker.Name = rdr["Name"].ToString();
                    listOfBrokers.Add(broker);
                }

                try
                {
                    var jsonResult = Json(listOfBrokers, JsonRequestBehavior.AllowGet);
                    jsonResult.MaxJsonLength = int.MaxValue;
                    return jsonResult;
                }
                catch (Exception)
                {
                    return Json("Data set too large", JsonRequestBehavior.AllowGet);
                }
            }
        }
        public JsonResult GetCompaniesandPrices()
        {
            var atsDbContext = new AtsDbContext();
            //Selecting distinct
            var companies =
                atsDbContext.para_company.GroupBy(x => x.fnam).Select(x => x.FirstOrDefault()).Select(c =>
                new
                {
                    Id = c.ID,
                    Name = c.Company,
                    InitialPrice = c.InitialPrice,
                    Instrument = c.Instrument,
                    fnam = c.fnam,
                    WebCompanyName = c.fnam + "(" + c.Company + ") - $" + c.InitialPrice,
                    WebCompanyValue = c.Company + "," + c.InitialPrice,
                });
            return Json(companies, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetCompaniesandPricesEXCHANGE(string exchange)
        {
            var companies = new List<CompanyPrices>();
            //load finsec 
            if (exchange.ToLower() == "zse")
            {
                var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
                var sql = @"SELECT cast(ut.id as nvarchar) as 'Id' ,qt.fnam + '(' + ut.Ticker + ') - $' + cast(ut.Current_price as nvarchar) as 'WebCompanyName', ut.Ticker + ',' + cast(ut.Current_price as nvarchar) as 'WebCompanyValue'
                        FROM[CDS_ROUTER].[dbo].[ZSE_market_data] ut , testcds_ROUTER.dbo.para_company qt
                        WHERE ut.Ticker = qt.Company";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        CompanyPrices recordSummary = new CompanyPrices();
                        recordSummary.Id = rdr["Id"].ToString();
                        recordSummary.WebCompanyName = rdr["WebCompanyName"].ToString();
                        recordSummary.WebCompanyValue = rdr["WebCompanyValue"].ToString();
                        companies.Add(recordSummary);
                    }
                }

            }
            else if (exchange.ToLower() == "finsec")
            {
                var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
                var sql = @"  SELECT cast(1 as nvarchar) as 'Id' ,b.fnam + '(' + b.company + ') - $' + cast(cast([Average Price] as numeric(18,4)) as nvarchar) as 'WebCompanyName', b.company + ',' + cast(cast([Average Price] as numeric(18,4)) as nvarchar) as 'WebCompanyValue' FROM [testcds_ROUTER].[dbo].[MarketWatch] a, testcds_ROUTER.dbo.para_company b WHERE a.company = b.Company";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        CompanyPrices recordSummary = new CompanyPrices();
                        recordSummary.Id = rdr["Id"].ToString();
                        recordSummary.WebCompanyName = rdr["WebCompanyName"].ToString();
                        recordSummary.WebCompanyValue = rdr["WebCompanyValue"].ToString();
                        companies.Add(recordSummary);
                    }
                }
            }

            //load zse

            /*
            var atsDbContext = new AtsDbContext();
            //Selecting distinct
            var companies =
                atsDbContext.para_company.Where(x => x.exchange == exchange).GroupBy(x => x.fnam).Select(x => x.FirstOrDefault()).Select(c =>
                new
                {
                    Id = c.ID,
                    WebCompanyName = c.fnam + "(" + c.Company + ") - $" + c.InitialPrice,
                    WebCompanyValue = c.Company + "," + c.InitialPrice,
                });
                */
            return Json(companies, JsonRequestBehavior.AllowGet);
        }
        public string testOrder(String quantity, String ammt)
        {
            var totalAmountToSpent = decimal.Parse(quantity) * decimal.Parse(ammt) * decimal.Parse("1.01693");
            return totalAmountToSpent + " ";
        }
        public string GetCustodianNumberFROMCDSNo(string cds)
        {
            var getBrk =
                "SELECT TOP 1 Custodian FROM [CDS_ROUTER].[dbo].[Accounts_Clients] where CDS_Number = '" +
                cds + "'";
            var order = new Accounts_Clients();
            var ret = "";
            using (var connection = new SqlConnection(connectionStringCDS_Router))
            {
                var cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                var rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        ret += rdr["Custodian"].ToString();
                    }

                    try
                    {
                        return ret;
                    }
                    catch (Exception)
                    {
                        return "1";
                    }
                }
                else
                {
                    return "0";
                }
            }
        }
        public string testAccountinJoint(string cdsNo)
        {

            try
            {
                var getBrk =
                    "select * from CDS_ROUTER.DBO.Accounts_Joint WHERE PermissionPost = 'yes' and ( cds_number = '" + cdsNo + "' or email = '" + cdsNo + "' )  ";

                using (var connection = new SqlConnection(connectionStringCDS_Router))
                {
                    var cmd = new SqlCommand(getBrk, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    var rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        return "true";
                    }
                    else
                    {
                        return "false";
                    }
                }
            }
            catch (Exception ex)
            {

                return "false";
            }
        }
        public JsonResult myCompanylistToPOST(string cds_number = null)
        {

            if (cds_number == null)
            {
                cds_number = "none";
            }

            var getBrk =
                "SELECT t.cds_number as account_number ,  t.CDSNo as company_code , ut.Surname as company_name FROM [CDS_ROUTER].[dbo].[Accounts_Joint] t , [CDS_ROUTER].[dbo].[Accounts_Audit] ut WHERE t.CDSNo = ut.CDS_Number and t.PermissionPost = 'yes' and t.cds_number = '" + cds_number + "'";

            var listOfBrokers = new List<MyCompanyLists>();
            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(getBrk, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MyCompanyLists broker = new MyCompanyLists();
                    broker.CompanyCode = rdr["company_code"].ToString();
                    broker.CompanyName = rdr["company_name"].ToString();
                    broker.AccountNumber = rdr["account_number"].ToString();
                    listOfBrokers.Add(broker);
                }

                try
                {
                    var jsonResult = Json(listOfBrokers, JsonRequestBehavior.AllowGet);
                    jsonResult.MaxJsonLength = int.MaxValue;
                    return jsonResult;
                }
                catch (Exception)
                {
                    return Json("Data set too large", JsonRequestBehavior.AllowGet);
                }
            }
        }
        public JsonResult getCompanyOrdersLists(string cds_number = null)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
            var preorder_live = new List<PreOrderLivess_new>();

            var sql =
                "SELECT t.* , ut.[fnam] FROM [CDSC].[dbo].[PreOrderLives] t , [testcds_ROUTER].[dbo].[para_company] ut WHERE t.Company  = ut.[Company] and t.corp_id = '" + cds_number + "' order by t.ID desc ";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //SELECT t.* , ut.[fnam]  
                    //FROM[CDSC].[dbo].[PreOrderLives] t , [testcds_ROUTER].[dbo].[para_company]
                    //ut where t.Company  = ut.[Company]
                    //ID, OrderType, Company, SecurityType, CDS_AC_No, Broker_Code, OrderStatus, Expiry_date, Create_date, Quantity, BasePrice, 
                    //TimeInForce, OrderQualifier, BrokerRef, OrderNumber, Source, corp_name, corp_id, authorised_status

                    PreOrderLivess_new recordSummary = new PreOrderLivess_new();
                    recordSummary.id = rdr["ID"].ToString();
                    recordSummary.price = rdr["BasePrice"].ToString();
                    recordSummary.volume = rdr["Quantity"].ToString();
                    recordSummary.type = rdr["OrderType"].ToString();
                    recordSummary.desc = GetTradingPlaform(rdr["Company"].ToString()) + "-" + rdr["Broker_Code"].ToString();
                    recordSummary.counter = rdr["Company"].ToString();
                    recordSummary.date = rdr["Create_date"].ToString();
                    recordSummary.status = rdr["authorised_status"].ToString();
                    recordSummary.fullname = rdr["fnam"].ToString();
                    preorder_live.Add(recordSummary);
                }
            }

            if (preorder_live.Any())
            {
                return Json(preorder_live, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("No data was found", JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult GetMyOrderslists(string cdsNumber = null)
        {
            string cdcnumber = "";
            try
            {
                var cdc = _cdDataContext.Accounts_Clients_Web.ToList().Where(a => a.CDS_Number.ToLower().Replace(" ", "") == cdsNumber.ToLower().Replace(" ", "")).FirstOrDefault();
                cdcnumber = cdc.CDC_Number;
            }
            catch (Exception)
            {


            }
            var sql = @" SELECT 
	                (select top 1 qt.fnam from [testCDS_ROUTER].[dbo].[para_company] qt where qt.Company=ut.Company) fnam ,	ut.*,t.* 
	                FROM [testcds_ROUTER].[dbo].[Pre_Order_Live] ut
	                left outer join
	                [CDS_ROUTER].[dbo].[ZSE_market_data] t on t.Ticker=ut.Company
	                  where CDS_AC_No ='" + cdsNumber.Trim() + @"' order by ut.OrderNo desc
                ";
            if (string.IsNullOrEmpty(cdcnumber) == false)
            {
                sql = @" SELECT 
	                (select top 1 qt.fnam from [testCDS_ROUTER].[dbo].[para_company] qt where qt.Company=ut.Company) fnam ,	ut.*,t.* 
	                FROM [testcds_ROUTER].[dbo].[Pre_Order_Live] ut
	                left outer join
	                [CDS_ROUTER].[dbo].[ZSE_market_data] t on t.Ticker=ut.Company
	                  where CDS_AC_No in ('" + cdsNumber.Trim() + @"','" + cdcnumber.Trim() + @"') order by ut.OrderNo desc
                ";
            }
            List<Pre_Order_Lives_new> my = new List<Pre_Order_Lives_new>();
            using (SqlConnection connection = new SqlConnection(connectionStringATS))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    if (rdr["Company"].ToString() != "OMZIL")
                    {
                        my.Add(new Pre_Order_Lives_new()
                        {
                            date = rdr["Create_date"].ToString(),
                            id = rdr["OrderNo"].ToString(),
                            counter = rdr["Company"].ToString(),
                            type = rdr["OrderType"].ToString(),
                            volume = rdr["Quantity"].ToString(),
                            price = rdr["BasePrice"].ToString(),
                            status = rdr["OrderStatus"].ToString(),
                            desc = rdr["trading_platform"].ToString() + " - " + rdr["Broker_Code"].ToString(),
                            fullname = rdr["fnam"].ToString(),
                            current_price = rdr["Current_price"].ToString(),
                            askprice = rdr["Best_Ask"].ToString(),
                            askvolume = rdr["Ask_Volume"].ToString(),
                            bidprice = rdr["Best_bid"].ToString(),
                            bidvolume = rdr["Bid_Volume"].ToString(),
                            AmountValue = rdr["AmountValue"].ToString(),

                            security_type = rdr["SecurityType"].ToString()


                        });
                    }

                }
                var connectionStrings = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;

                var sqls = @"SELECT ut.* , t.* , qt.fnam FROM  [testCDS_ROUTER].[dbo].[Pre_Order_Live] ut ,
                    [testCDS_ROUTER].[dbo].[para_company] qt ,  [testcds_ROUTER].[dbo].[marketwatch] t 
                    WHERE ut.Company = qt.Company and t.company = ut.Company and ut.CDS_AC_No = '" + cdsNumber.Trim() + @"' order by  ut.OrderNo DESC 
                ";

                using (SqlConnection connections = new SqlConnection(connectionStrings))
                {
                    SqlCommand cmds = new SqlCommand(sqls, connections);
                    cmds.CommandType = CommandType.Text;
                    connections.Open();
                    SqlDataReader rdrs = cmds.ExecuteReader();
                    while (rdrs.Read())
                    {
                        if (rdrs["Company"].ToString() == "OMZIL")
                        {
                            my.Add(new Pre_Order_Lives_new()
                            {
                                date = rdrs["Create_date"].ToString(),
                                id = rdrs["OrderNo"].ToString(),
                                counter = rdrs["Company"].ToString(),
                                type = rdrs["OrderType"].ToString(),
                                volume = rdrs["Quantity"].ToString(),
                                price = rdrs["BasePrice"].ToString(),
                                status = rdrs["OrderStatus"].ToString(),
                                desc = rdrs["trading_platform"].ToString() + " - " + rdrs["Broker_Code"].ToString(),
                                fullname = rdrs["fnam"].ToString(),
                                current_price = rdrs["Average Price"].ToString(),
                                askprice = rdrs["Ask"].ToString(),
                                askvolume = rdrs["Volume Sell"].ToString(),
                                bidprice = rdrs["Bid"].ToString(),
                                bidvolume = rdrs["Volume"].ToString(),
                                security_type = rdrs["SecurityType"].ToString()

                            });
                        }
                    }
                }



                try
                {
                    var jsonResult = Json(my, JsonRequestBehavior.AllowGet);
                    jsonResult.MaxJsonLength = int.MaxValue;
                    return jsonResult;
                }

                catch (Exception)
                {
                    return Json("Error loading data", JsonRequestBehavior.AllowGet);
                }
            }

        }
        public JsonResult GetEquityOrders(string cdsNumber = null)
        {


            var sql = @"  SELECT 
	                (select top 1 qt.fnam from [testCDS_ROUTER].[dbo].[para_company] qt where qt.Company=ut.Company) fnam ,	ut.*,t.* 
	                FROM [testcds_ROUTER].[dbo].[Pre_Order_Live] ut
	                left outer join
	                [CDS_ROUTER].[dbo].[ZSE_market_data] t on t.Ticker=ut.Company
	                  where CDS_AC_No ='" + cdsNumber.Trim() + @"' order by ut.OrderNo desc
                ";

            List<Pre_Order_Lives_new> my = new List<Pre_Order_Lives_new>();
            using (SqlConnection connection = new SqlConnection(connectionStringATS))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    if (rdr["Company"].ToString() != "OMZIL")
                    {
                        my.Add(new Pre_Order_Lives_new()
                        {
                            date = rdr["Create_date"].ToString(),
                            id = rdr["OrderNo"].ToString(),
                            counter = rdr["Company"].ToString(),
                            type = rdr["OrderType"].ToString(),
                            volume = rdr["Quantity"].ToString(),
                            price = rdr["BasePrice"].ToString(),
                            status = rdr["OrderStatus"].ToString(),
                            desc = rdr["trading_platform"].ToString() + " - " + rdr["Broker_Code"].ToString(),
                            fullname = rdr["fnam"].ToString(),
                            current_price = rdr["Current_price"].ToString(),
                            askprice = rdr["Best_Ask"].ToString(),
                            askvolume = rdr["Ask_Volume"].ToString(),
                            bidprice = rdr["Best_bid"].ToString(),
                            bidvolume = rdr["Bid_Volume"].ToString(),
                            security_type = rdr["SecurityType"].ToString()

                        });
                    }

                }
                var connectionStrings = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;

                var sqls = @"SELECT ut.* , t.* , qt.fnam FROM  [testCDS_ROUTER].[dbo].[Pre_Order_Live] ut ,
                    [testCDS_ROUTER].[dbo].[para_company] qt ,  [testcds_ROUTER].[dbo].[marketwatch] t 
                    WHERE ut.Company = qt.Company and t.company = ut.Company and ut.CDS_AC_No = '" + cdsNumber.Trim() + @"' order by  ut.OrderNo DESC 
                ";

                using (SqlConnection connections = new SqlConnection(connectionStrings))
                {
                    SqlCommand cmds = new SqlCommand(sqls, connections);
                    cmds.CommandType = CommandType.Text;
                    connections.Open();
                    SqlDataReader rdrs = cmds.ExecuteReader();
                    while (rdrs.Read())
                    {
                        if (rdrs["Company"].ToString() == "OMZIL")
                        {
                            my.Add(new Pre_Order_Lives_new()
                            {
                                date = rdrs["Create_date"].ToString(),
                                id = rdrs["OrderNo"].ToString(),
                                counter = rdrs["Company"].ToString(),
                                type = rdrs["OrderType"].ToString(),
                                volume = rdrs["Quantity"].ToString(),
                                price = rdrs["BasePrice"].ToString(),
                                status = rdrs["OrderStatus"].ToString(),
                                desc = rdrs["trading_platform"].ToString() + " - " + rdrs["Broker_Code"].ToString(),
                                fullname = rdrs["fnam"].ToString(),
                                current_price = rdrs["Average Price"].ToString(),
                                askprice = rdrs["Ask"].ToString(),
                                askvolume = rdrs["Volume Sell"].ToString(),
                                bidprice = rdrs["Bid"].ToString(),
                                bidvolume = rdrs["Volume"].ToString(),
                                security_type = rdrs["SecurityType"].ToString()

                            });
                        }
                    }
                }



                try
                {
                    var jsonResult = Json(my, JsonRequestBehavior.AllowGet);
                    jsonResult.MaxJsonLength = int.MaxValue;
                    return jsonResult;
                }
                catch (Exception)
                {
                    return Json("Error loading data", JsonRequestBehavior.AllowGet);
                }
            }

        }
        public JsonResult getqueslists(string cdsNumber = null)
        {


            var sql = @"SELECT TOP 1 * FROM [CDSC].[dbo].[signup_qsn] where cds_number = '" + cdsNumber.Trim() + @"' ";

            List<Signup_qsn> my = new List<Signup_qsn>();
            using (SqlConnection connection = new SqlConnection(connectionStringATS))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    my.Add(new Signup_qsn()
                    {
                        id = rdr["id"].ToString(),
                        cds_number = rdr["cds_number"].ToString(),
                        qsn_one = rdr["qsn_one"].ToString(),
                        qsn_two = rdr["qsn_two"].ToString(),
                        qsn_three = rdr["qsn_three"].ToString(),


                    });

                }

                try
                {
                    var jsonResult = Json(my, JsonRequestBehavior.AllowGet);
                    jsonResult.MaxJsonLength = int.MaxValue;
                    return jsonResult;
                }
                catch (Exception)
                {
                    return Json("Error loading data", JsonRequestBehavior.AllowGet);
                }
            }

        }
        public String insertQuestions(string cdsNumber = null, string qsn_one = null, string qsn_two = null, string qsn_three = null)
        {


            var sql = @"INSERT INTO [CDSC].[dbo].[signup_qsn]
                               ([cds_number]
                               ,[qsn_one]
                               ,[qsn_two]
                               ,[qsn_three])
                         VALUES
                               ('" + cdsNumber.Trim() + @"'
                               ,'" + qsn_one.Trim() + @"'
                               ,'" + qsn_two.Trim() + @"'
                               ,'" + qsn_three.Trim() + @"') ";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionStringATS))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                    return "Inserted questions successfully";


                }

            }
            catch (Exception ex)
            {
                return "Error loading data" + sql + ex;
            }

        }

        /***********************************CHANDALALA TINASHE**************************************************************/


        public string generateSessionID()
        {

            Random rnd = new Random();

            var randomNumber = (rnd.Next(000000000, 999999999)).ToString();


            return randomNumber;
        }

        //close session
        public string closeSession(string cdsNumber) {



          var  sql = @"UPDATE [CDS].[dbo].[SystemUsers]
                SET [Active_Session] = " + "'" + "" + "'" + "WHERE [Role] = " + "'" + cdsNumber + "'";

            try
            {



                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        connection.Close();
                        return "closed";
                    }
                    else
                    {
                        connection.Close();
                        return "false";
                    }

                }

            }
            catch (Exception ex)
            {

                return ex.Message;
            }


        }

        //create session
        public string createSession(string cdsNumber)
        {

            var sessionID = generateSessionID();
            //generate session ID
            var sql = @"UPDATE [CDS].[dbo].[SystemUsers]
                SET [Active_Session] = " + "'" + sessionID + "'" + "WHERE [Role] = " + "'" + cdsNumber + "'";

            try
            {



                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        connection.Close();
                        return sessionID;
                    }
                    else
                    {
                        connection.Close();
                        return "false";
                    }

                }

            }
            catch (Exception ex)
            {

                return "error";
            }


        }

        //check session
        public string checkSession(string cdsNumber, string sessionID)
        {

           
            var sql = "select * from cds.dbo.SystemUsers where Role = '"+ cdsNumber + "' and Active_Session = '"+ sessionID + "'";

            try
            {

                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();

                    if (rdr.Read().ToString().Equals("True"))
                    {
                        connection.Close();
                        return "true";
                    }
                    else {
                        connection.Close();
                        return "false";
                    }


                    

                }
            }
            catch (Exception e) {

                return e.Message;
            
            }


        }


        public bool oldPassMatchNewPass(string cdsNumber, string oldPassword) {


            
            var sql = "SELECT * FROM [cds].[dbo].[SystemUsers] where [Role] =  " + "'" + cdsNumber + "' AND [Password]=" + "'" + base64Encode(oldPassword) + "'";


            bool hasRows = false;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();


                    if (rdr.HasRows)
                    {
                        hasRows = true;
                    }
                    else
                    {
                        hasRows = false;
                    }

                }
            }
            catch (Exception e) {
                return false;
            }

            return hasRows;


        }

        //change password
        public string changeNaymatPassword(string cdsNumber, string oldPassword, string newPassword)
        {

            //first check if old password matches new password
            if (oldPassMatchNewPass(cdsNumber, oldPassword))
            {

                //todo encrypt password
        /*        var sql = @"UPDATE [CDS].[dbo].[SystemUsers]  
                SET [Password] = " + "'" + encrypt(newPassword) + "'" + "WHERE [Role] = " + "'" + cdsNumber + "'";*/

                 var sql = @"UPDATE [CDS].[dbo].[SystemUsers]
                SET [Password] = " + "'" + EncryptBase64(newPassword) + "', [PasswordExpireyDate]=" + "'" + DateAndTime.Now.AddDays(30) + "'"+" WHERE [Role] = " + "'" + cdsNumber + "'";


                try
                {



                    using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                    {


                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;
                        connection.Open();

                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            connection.Close();
                            return "changed";
                        }
                        else
                        {
                            connection.Close();
                            return "false";
                        }

                    }

                }
                catch (Exception ex)
                {

                    return ex.Message;
                }
            }

                return "false";
          
        }


        /*Soap web services*/



        public HttpWebRequest TransferChargesSOAPWebRequest()
        {
            //Making Web Request    
            //http://192.168.3.105/WarehouseDev/NaymatBill.ASMX?op=transfercharges
            //https://ewrsystem-uat.naymatcollateral.com/CTRADEWR/NaymatBill.ASMX
             HttpWebRequest Req = (HttpWebRequest)WebRequest.Create(@"http://cdc-ho-nclapp/CTRADEWR/NaymatBiLl.asmx");
            //HttpWebRequest Req = (HttpWebRequest)WebRequest.Create(@"https://ewrsystem-uat.naymatcollateral.com/CTRADEWR/NaymatBill.ASMX");
            //SOAPAction    
            Req.Headers.Add(@"SOAPAction:http://tempuri.org/transfercharges");
            //Content_type    
            Req.ContentType = "text/xml;charset=\"utf-8\"";
            Req.Accept = "text/xml";
            //HTTP method    
            Req.Method = "POST";
            //return HttpWebRequest    
            return Req;
        }



        /*Soap web services*/
        public string getTransferCharges(string cdsNumber, double quantity, string ewr_number) {

            string transactionType = "ENQUIRE";
            string participantType = "DEPOSITOR";
            //Calling CreateSOAPWebRequest method  
            HttpWebRequest request = TransferChargesSOAPWebRequest();

            XmlDocument SOAPReqBody = new XmlDocument();
            //SOAP Body Request  
            SOAPReqBody.LoadXml(@"<?xml version=""1.0"" encoding=""utf-8""?>  
            <soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-   instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">  
             <soap:Body>  
                <transfercharges xmlns=""http://tempuri.org/"">  
                  <TranType>" + transactionType + @"</TranType>  
                  <ParticipantType>" + participantType + @"</ParticipantType>  
                  <quantity>" + quantity + @"</quantity>  
                  <accid>" + cdsNumber + @"</accid>  
                  <TransRef>" + ewr_number + @"</TransRef> 
                </transfercharges>  
              </soap:Body>  
            </soap:Envelope>");


            using (Stream stream = request.GetRequestStream())
            {
                SOAPReqBody.Save(stream);
            }
            //Geting response from request  
            using (WebResponse Serviceres = request.GetResponse())
            {
                using (StreamReader rd = new StreamReader(Serviceres.GetResponseStream()))
                {
                    //reading stream  
                    var ServiceResult = rd.ReadToEnd();
                    //writting stream result on console  
                  
                  //  return ServiceResult;

                    var doc = System.Xml.Linq.XDocument.Parse(ServiceResult);
                    System.Xml.Linq.XNamespace ns = "http://tempuri.org/";
                    var result = doc.Root.Descendants(ns + "transferchargesResponse").Elements(ns + "transferchargesResult").FirstOrDefault();

                    var transferCharge = "";

                    if (!String.IsNullOrEmpty(result.Value.ToString()))
                    {
                        transferCharge = result.Value.ToString();


                       // return ewr_number;

                        return String.Format("{0:0.00}", Double.Parse(transferCharge));
                    }

                    return transferCharge;

                   



                }
            }

         
        }

        public string billTransferCharges(string cdsNumber, double quantity, string ewr_number)
        {

            string transactionType = "BILL";
            string participantType = "DEPOSITOR";
            //Calling CreateSOAPWebRequest method  
            HttpWebRequest request = TransferChargesSOAPWebRequest();

            XmlDocument SOAPReqBody = new XmlDocument();
            //SOAP Body Request  
            SOAPReqBody.LoadXml(@"<?xml version=""1.0"" encoding=""utf-8""?>  
            <soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-   instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">  
             <soap:Body>  
                <transfercharges xmlns=""http://tempuri.org/"">  
                  <TranType>" + transactionType + @"</TranType>  
                  <ParticipantType>" + participantType + @"</ParticipantType>  
                  <quantity>" + quantity + @"</quantity>  
                  <accid>" + cdsNumber + @"</accid>  
                  <TransRef>" + ewr_number + @"</TransRef> 
                </transfercharges>  
              </soap:Body>  
            </soap:Envelope>");


            using (Stream stream = request.GetRequestStream())
            {
                SOAPReqBody.Save(stream);
            }
            //Geting response from request  
            using (WebResponse Serviceres = request.GetResponse())
            {
                using (StreamReader rd = new StreamReader(Serviceres.GetResponseStream()))
                {
                    //reading stream  
                    var ServiceResult = rd.ReadToEnd();
                    //writting stream result on console  

                    //  return ServiceResult;

                    var doc = System.Xml.Linq.XDocument.Parse(ServiceResult);
                    System.Xml.Linq.XNamespace ns = "http://tempuri.org/";
                    var result = doc.Root.Descendants(ns + "transferchargesResponse").Elements(ns + "transferchargesResult").FirstOrDefault();

                    var transferCharge = "";

                    if (!String.IsNullOrEmpty(result.Value.ToString()))
                    {
                        transferCharge = result.Value.ToString();


                        // return ewr_number;

                        return String.Format("{0:0.00}", Double.Parse(transferCharge));
                    }

                    return transferCharge;





                }
            }


        }

        public HttpWebRequest WithdrawalChargesSOAPWebRequest()
        {
            //Making Web Request    
            //http://192.168.3.105/WarehouseDev/NaymatBill.ASMX?op=withdrawalcharges

            HttpWebRequest Req = (HttpWebRequest)WebRequest.Create(@"http://cdc-ho-nclapp/CTRADEWR/NaymatBiLl.asmx");
            //HttpWebRequest Req = (HttpWebRequest)WebRequest.Create(@"https://ewrsystem-uat.naymatcollateral.com/CTRADEWR/NaymatBill.ASMX");
       

            //HttpWebRequest Req = (HttpWebRequest)WebRequest.Create(@"http://192.168.3.105/WarehouseDev/NaymatBill.ASMX");
            //SOAPAction    
            Req.Headers.Add(@"SOAPAction:http://tempuri.org/withdrawalcharges");
            //Content_type    
            Req.ContentType = "text/xml;charset=\"utf-8\"";
            Req.Accept = "text/xml";
            //HTTP method    
            Req.Method = "POST";
            //return HttpWebRequest    
            return Req;
        }



        public HttpWebRequest splitChargesSOAPWebRequest()
        {
            //Making Web Request    
            //http://192.168.3.105/WarehouseDev/NaymatBill.ASMX?op=withdrawalcharges

            HttpWebRequest Req = (HttpWebRequest)WebRequest.Create(@"http://cdc-ho-nclapp/CTRADEWR/NaymatBiLl.asmx");
            //HttpWebRequest Req = (HttpWebRequest)WebRequest.Create(@"https://ewrsystem-uat.naymatcollateral.com/CTRADEWR/NaymatBill.ASMX");


            //HttpWebRequest Req = (HttpWebRequest)WebRequest.Create(@"http://192.168.3.105/WarehouseDev/NaymatBill.ASMX");
            //SOAPAction    
            Req.Headers.Add(@"SOAPAction:http://tempuri.org/withdrawalcharges");
            //Content_type    
            Req.ContentType = "text/xml;charset=\"utf-8\"";
            Req.Accept = "text/xml";
            //HTTP method    
            Req.Method = "POST";
            //return HttpWebRequest    
            return Req;
        }


        public string getWithdrawalCharges(string cdsNumber, double quantity, string ewr_number)
        {
            string transactionType = "ENQUIRE";
            string participantType = "DEPOSITOR";
            //Calling CreateSOAPWebRequest method  
            HttpWebRequest request = WithdrawalChargesSOAPWebRequest();

            XmlDocument SOAPReqBody = new XmlDocument();
            //SOAP Body Request  
            SOAPReqBody.LoadXml(@"<?xml version=""1.0"" encoding=""utf-8""?>  
            <soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-   instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">  
             <soap:Body>  
                <withdrawalcharges  xmlns=""http://tempuri.org/"">  
                  <TranType>" + transactionType + @"</TranType>  
                  <ParticipantType>" + participantType + @"</ParticipantType>  
                  <quantity>" + quantity + @"</quantity>  
                  <accid>" + cdsNumber + @"</accid>  
                  <TransRef>" + ewr_number + @"</TransRef> 
                </withdrawalcharges >  
              </soap:Body>  
            </soap:Envelope>");


            using (Stream stream = request.GetRequestStream())
            {
                SOAPReqBody.Save(stream);
            }
            //Geting response from request  
            using (WebResponse Serviceres = request.GetResponse())
            {
                using (StreamReader rd = new StreamReader(Serviceres.GetResponseStream()))
                {
                    //reading stream  
                    var ServiceResult = rd.ReadToEnd();
                    //writting stream result on console  
             

                    var doc = System.Xml.Linq.XDocument.Parse(ServiceResult);
                    System.Xml.Linq.XNamespace ns = "http://tempuri.org/";
                    var result = doc.Root.Descendants(ns+ "withdrawalchargesResponse").Elements(ns+ "withdrawalchargesResult").FirstOrDefault();

                    var withdrawalCharge = "";

                    if (!String.IsNullOrEmpty(result.Value.ToString()))
                    {
                        withdrawalCharge = result.Value.ToString();
                        //return ewr_number;
                        return String.Format("{0:0.00}", Double.Parse(withdrawalCharge));
                    }

                    return withdrawalCharge;



                }
            }

       
        }

        public string billWithdrawalCharges(string cdsNumber, double quantity, string ewr_number)
        {
            string transactionType = "BILL";
            string participantType = "DEPOSITOR";
            //Calling CreateSOAPWebRequest method  
            HttpWebRequest request = WithdrawalChargesSOAPWebRequest();

            XmlDocument SOAPReqBody = new XmlDocument();
            //SOAP Body Request  
            SOAPReqBody.LoadXml(@"<?xml version=""1.0"" encoding=""utf-8""?>  
            <soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-   instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">  
             <soap:Body>  
                <withdrawalcharges  xmlns=""http://tempuri.org/"">  
                  <TranType>" + transactionType + @"</TranType>  
                  <ParticipantType>" + participantType + @"</ParticipantType>  
                  <quantity>" + quantity + @"</quantity>  
                  <accid>" + cdsNumber + @"</accid>  
                  <TransRef>" + ewr_number + @"</TransRef> 
                </withdrawalcharges >  
              </soap:Body>  
            </soap:Envelope>");


            using (Stream stream = request.GetRequestStream())
            {
                SOAPReqBody.Save(stream);
            }
            //Geting response from request  
            using (WebResponse Serviceres = request.GetResponse())
            {
                using (StreamReader rd = new StreamReader(Serviceres.GetResponseStream()))
                {
                    //reading stream  
                    var ServiceResult = rd.ReadToEnd();
                    //writting stream result on console  


                    var doc = System.Xml.Linq.XDocument.Parse(ServiceResult);
                    System.Xml.Linq.XNamespace ns = "http://tempuri.org/";
                    var result = doc.Root.Descendants(ns + "withdrawalchargesResponse").Elements(ns + "withdrawalchargesResult").FirstOrDefault();

                    var withdrawalCharge = "";

                    if (!String.IsNullOrEmpty(result.Value.ToString()))
                    {
                        withdrawalCharge = result.Value.ToString();
                        //return ewr_number;
                        return String.Format("{0:0.00}", Double.Parse(withdrawalCharge));
                    }

                    return withdrawalCharge;



                }
            }


        }

        public string getSplitCharges(string cdsNumber, double quantity, string ewr_number)
        {
            string transactionType = "BILL";
            string participantType = "DEPOSITOR";
            //Calling CreateSOAPWebRequest method  
            HttpWebRequest request = WithdrawalChargesSOAPWebRequest();

            XmlDocument SOAPReqBody = new XmlDocument();
            //SOAP Body Request  
            SOAPReqBody.LoadXml(@"<?xml version=""1.0"" encoding=""utf-8""?>  
            <soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-   instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">  
             <soap:Body>  
                <Splitcharges  xmlns=""http://tempuri.org/"">  
                  <TranType>" + transactionType + @"</TranType>  
                  <ParticipantType>" + participantType + @"</ParticipantType>  
                  <quantity>" + quantity + @"</quantity>  
                  <accid>" + cdsNumber + @"</accid>  
                  <TransRef>" + ewr_number + @"</TransRef> 
                </Splitcharges >  
              </soap:Body>  
            </soap:Envelope>");


            using (Stream stream = request.GetRequestStream())
            {
                SOAPReqBody.Save(stream);
            }
            //Geting response from request  
            using (WebResponse Serviceres = request.GetResponse())
            {
                using (StreamReader rd = new StreamReader(Serviceres.GetResponseStream()))
                {
                    //reading stream  
                    var ServiceResult = rd.ReadToEnd();
                    //writting stream result on console  


                    var doc = System.Xml.Linq.XDocument.Parse(ServiceResult);
                    System.Xml.Linq.XNamespace ns = "http://tempuri.org/";
                    var result = doc.Root.Descendants(ns + "withdrawalchargesResponse").Elements(ns + "withdrawalchargesResult").FirstOrDefault();

                    var withdrawalCharge = "";

                    if (!String.IsNullOrEmpty(result.Value.ToString()))
                    {
                        withdrawalCharge = result.Value.ToString();
                        //return ewr_number;
                        return String.Format("{0:0.00}", Double.Parse(withdrawalCharge));
                    }

                    return withdrawalCharge;



                }
            }


        }



        private string base64Encode(string sData)
        {
            try
            {
                byte[] encData_byte = new byte[sData.Length - 1 + 1];
                encData_byte = System.Text.Encoding.UTF8.GetBytes(sData);
                string encodedData = Convert.ToBase64String(encData_byte);
                return (encodedData);
            }
            catch (Exception ex)
            {
                throw (new Exception("Error in base64Encode" + ex.Message));
            }
        }

        private string EncryptBase64(string value)
        {
            string result = "";

            try
            {
                if (!string.IsNullOrEmpty(value))
                {
                    byte[] bytes = System.Text.UnicodeEncoding.UTF8.GetBytes(value);
                    result = Convert.ToBase64String(bytes);
                }
            }
            catch { }

            return result;
        }


        public string getemail(string cdsnumber)
        {

            var sql = "select email from accounts_clients where cds_Number='" + cdsnumber + "'";

            var email = "";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();

                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    email = rdr["email"].ToString();

                }

                    connection.Close();
            
            }

            return email;

        }


        public  string generateOTP()
        {
            
            Random rnd = new Random();

            var randomNumber = (rnd.Next(1000, 9999)).ToString();
            

            return randomNumber;
        }



        public JsonResult getAccountUpdates(string cds_no)
        {


            var sql = "SELECT *,CASE WHEN A.AccountType='I' THEN 'Single' when A.AccountType='J' THEN 'Joint' when A.AccountType='C' THEN 'Corporate' else A.AccountType end as myAccType FROM cds.dbo.Accounts_Audit A WHERE A.AuthorizationState='O' and ISNULL(A.OTP,'0')<>'0' and ISNULL(A.OTPStatus,'')<>'APPROVED' and a.CDS_Number ="+ "'" + cds_no + "'" + "order by ID";

            var accountUpdates = new List<AccountsUpdateModel>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    AccountsUpdateModel accountUpdate = new AccountsUpdateModel
                    {


                        ID = rdr["ID"].ToString()
                        ,
                        CNIC = rdr["CNIC"].ToString()
                        ,
                        AccountType = rdr["AccountType"].ToString()
               



                    };


                    accountUpdates.Add(accountUpdate);
                }
            }

            if (accountUpdates.Any())
            {
                return Json(accountUpdates, JsonRequestBehavior.AllowGet);

            }
            return Json("No data was found}", JsonRequestBehavior.AllowGet);


        }

        public JsonResult NaymatLogin(string username, string password)
        {


            string decryptedPassword = base64Encode(password);



            var sql = "SELECT * FROM [CDS].[dbo].[SystemUsers] where [UserName] =" + "'" + username + "'" + " AND [Password]  =" + "'" + decryptedPassword + "'";

            var users = new List<UserModel>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();


                while (rdr.Read())
                {
                    UserModel user = new UserModel
                    {


                        Username = rdr["Username"].ToString()
                        ,
                        Surname = rdr["Surname"].ToString()
                        ,
                        Forenames = rdr["Forenames"].ToString()
                        ,
                        Email = rdr["Email"].ToString()
                        ,
                        HolderNo = rdr["Role"].ToString()
                        ,
                        PasswordExpirey = rdr["PasswordExpireyDate"].ToString()


                    };


                    users.Add(user);
                }
            }

            if (users.Any())
            {
                //CREATE SESSION
                string sessionID = createSession(users[0].HolderNo);
                if (!sessionID.Equals("false") || !sessionID.Equals("error"))
                {

                    users[0].SessionID = sessionID;
                    return Json(users, JsonRequestBehavior.AllowGet);
                }
                else {
                    
                    return Json("failed to create session", JsonRequestBehavior.AllowGet);
                }

             

            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);


        }


        public String addLoanMobile(string cdsNumber = null, string reason = null, string tenure = null, string lender = null, string amount = null){

            String status = "0";

            var sql = @"INSERT INTO [CDS_Router].[dbo].[tblSecuritiesBorrowing_Main]
                               ([CSD_Number]
                               ,[LoanAmount]
                               ,[Tenure]
                               ,[Reason]
                               ,LendingBank
                               ,[DisbursementDate]
                               ,[ApplicationDate]
                               ,ExpiryDate
                               ,[Status])
                         VALUES
                               ('" + cdsNumber.Trim() + @"'
                               ,'" + amount.Trim() + @"'
                               ,'" + tenure.Trim() + @"'
                               ,'" + reason.Trim() + @"'
                               ,'" + lender.Trim() + @"'
                               ,GETDATE()
                               ,GETDATE()
                               ,GETDATE()
                               ,'" + status.Trim() + @"') ";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                    return "Inserted questions successfully";


                }

            }
            catch (Exception ex)
            {
                return "Error loading data" + sql + ex;
            }

        }

        public String withdrawCommodity(PendingWithdrawalModel pendingWithdrawalModel, string email)
        {

            string otp = generateOTP();


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            //var withdrawals = linqToSQLDataContext.withdrawals.Where(withdrawal => withdrawal.ReceiptID == pendingWithdrawalModel.ReceiptID && withdrawal.status == pendingWithdrawalModel.status).ToList();

            withdrawal wd = new withdrawal();
            wd.company = pendingWithdrawalModel.ReceiptID;
            wd.amount_to_withdraw = decimal.Parse(pendingWithdrawalModel.amount_to_withdraw);
            wd.date = DateTime.Now;
            wd.query = "0";
            wd.CapturedBy = pendingWithdrawalModel.EWR_holder;
            wd.CaptureDate = DateTime.Now;
            wd.ParticipantCode = pendingWithdrawalModel.ParticipantCode;
            wd.status = pendingWithdrawalModel.status;
            wd.ParticipantCode = pendingWithdrawalModel.ParticipantCode;
            wd.ReceiptID = pendingWithdrawalModel.ReceiptID;
            wd.EWR_holder = pendingWithdrawalModel.EWR_holder;
            wd.OTP = otp;
            wd.OTPCreateTime = DateTime.Now;
            wd.OTPSent = true;


            linqToSQLDataContext.withdrawals.InsertOnSubmit(wd);

            linqToSQLDataContext.SubmitChanges();

            billWithdrawalCharges(pendingWithdrawalModel.EWR_holder.Trim(), Double.Parse(pendingWithdrawalModel.amount_to_withdraw), pendingWithdrawalModel.ReceiptID.Trim());

            sendmail s = new sendmail();


            string strBody = "";
            strBody = "A Warehouse receipt withdrawal has been initiated from your account.: " + pendingWithdrawalModel.EWR_holder.Trim();
            // strBody = "The following changes have been made to your account: " + ma + " "
            strBody = Environment.NewLine;
            strBody = "Please authorize using OTP: " + otp + "";



            s.sendEmail(email, "OTP Request", strBody, getMobileNumber(pendingWithdrawalModel.EWR_holder));
            //s.messagesend(getMobileNumber(email), strBody);

            return "submitted";




        }



        public string getMobileNumber(string email)
        {


            var mobileNumber = "0";
           

            var sql = "SELECT mobile1 FROM [CDS].[dbo].[SystemUsers] " + " where [username] =  " + "'" + email + "'";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    mobileNumber = rdr["mobile1"].ToString();
                }

                return mobileNumber;
            }

  

        }


        public String addPledge(PledgeModel pledge, string email)
        {

            string otp = generateOTP();

            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);



            //var requests = linqToSQLDataContext.BorrowingRequests.Where(request => request.Collateral == pledge.Collateral).ToList();

            try
            {
                BorrowingRequest br = new BorrowingRequest();
                br.Collateral = pledge.Collateral;
                br.AvailableQuantity = decimal.Parse(pledge.AvailableQuantity);
                br.Unit_Price = decimal.Parse(pledge.Unit_Price);
                br.CapturedDate = DateTime.Now;
                br.Tenure = 0;
                br.Bank = pledge.Bank;
                br.LoanAmount = decimal.Parse(pledge.LoanAmount);
                br.Borrower = pledge.Borrower;
                br.Participant = pledge.Participant;
                br.OTP = otp;
                br.OTPSent = true;

                linqToSQLDataContext.BorrowingRequests.InsertOnSubmit(br);

                linqToSQLDataContext.SubmitChanges();


                sendmail s = new sendmail();


                string strBody = "";
                strBody = "A Warehouse receipt pledge has been initiated from your account.: " + pledge.Borrower.Trim();
                // strBody = "The following changes have been made to your account: " + ma + " "
                strBody = Environment.NewLine;
                strBody = "Please authorize using OTP: " + otp + "";



                s.sendEmail(email, "OTP Request", strBody, getMobileNumber(pledge.Borrower));
                //s.messagesend(getMobileNumber(email), strBody);



                return "submitted";
            }
            catch (Exception e)
            {
                return e.Message;
            }


        }

    public async Task<string>  getFile(Stream stream) {


            try
            {
                LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

                chargesdocument cd = new chargesdocument();
                CashTransTemp cashTransTemp = new CashTransTemp();


                MultipartFormDataParser parser = new MultipartFormDataParser(stream);

                // From this point the data is parsed, we can retrieve the
                // form data from the Parameters dictionary:
                var amount = parser.Parameters[0].Data;
                var CDS_Number = parser.Parameters[1].Data;
                var ChargeCode = parser.Parameters[2].Data;
                var Description = parser.Parameters[3].Data;
                var Reference = parser.Parameters[4].Data;
                var TransType = parser.Parameters[5].Data;
                var TransStatus = parser.Parameters[6].Data;


                //string strQuery = " insert into [chargesdocuments] (chargeCode,filename,refrence, cds_number, ContentType, Data, doctype,DateUploaded,CreatedBy)"

                // Files are stored in a list:
                var file = parser.Files.First();
                string filename = file.FileName;
                var ContentType = file.ContentType;
                var doctype = file.ContentType;
                Stream data = file.Data;

                cd.chargeCode = ChargeCode;
                cd.filename = filename;
                cd.refrence = Reference;
                cd.cds_number = CDS_Number;
                cd.ContentType = ContentType;
                cd.CreatedBy = CDS_Number;
                // cd.docttype = doctype;
                cd.DateUploaded = DateTime.Now;

                byte[] bytes;
                using (FileStream f = new FileStream(filename, FileMode.Open, FileAccess.Read))
                {
                    bytes = new byte[f.Length];
                    f.Read(bytes, 0, (int)f.Length);
                }

                cd.Data = bytes;



                cashTransTemp.Amount = decimal.Parse(amount);
                cashTransTemp.CDS_Number = CDS_Number;
                cashTransTemp.ChargeCode = ChargeCode;
                cashTransTemp.DateCreated = DateTime.Now;
                cashTransTemp.Description = Description;
                cashTransTemp.Reference = Reference;
                cashTransTemp.TransType = TransType;
                cashTransTemp.TransStatus = TransStatus;


                linqToSQLDataContext.CashTransTemps.InsertOnSubmit(cashTransTemp);
                linqToSQLDataContext.chargesdocuments.InsertOnSubmit(cd);

                linqToSQLDataContext.SubmitChanges();




                return "submitted";

            }
            catch (Exception e) {
                return e.Message;
            }
                    


     }






        public String postPayment(ChargeModel chargeModel)
        {


/*            {
                Stream fs = FileUpload4.PostedFile.InputStream;
                BinaryReader br = new BinaryReader(fs);
                byte[] bytes = br.ReadBytes(fs.Length);

                // insert the file into database 
                string strQuery = " insert into [chargesdocuments] (chargeCode,filename,refrence, cds_number, ContentType, Data, doctype,DateUploaded,CreatedBy)"
                + " values ('chandas',@docname,@refrence,@cds_number,@ContentType, @Data, @doctype, getdate(),@CreatedBy)";
                SqlCommand cmd = new SqlCommand(strQuery);
                cmd.Parameters.Add("@CreatedBy", SqlDbType.VarChar).Value = Session("Username");
                cmd.Parameters.Add("@docname", SqlDbType.VarChar).Value = filename;
                cmd.Parameters.Add("@refrence", SqlDbType.VarChar).Value = txtReference.Text;
                cmd.Parameters.Add("@cds_number", SqlDbType.VarChar).Value = getDEPCDS(Session("Username"));
                cmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype;
                cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes;
                cmd.Parameters.Add("@doctype", SqlDbType.VarChar).Value = txtDescription.Text;
                cmd.Parameters.Add("@chargeCode", SqlDbType.VarChar).Value = txtChargeCode.Text;
            }*/


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

    /*        chargesdocument chargesdoc = new chargesdocument();


            chargesdoc.chargeCode = chargeModel.ChargeCode;
            chargesdoc.filename = "";
            chargesdoc.refrence = chargeModel.Reference;
            chargesdoc.cds_number = chargeModel.CDS_Number;
            chargesdoc.ContentType = "";
            chargesdoc.Data = "";
            chargesdoc.docttype = chargeModel.Description;
            chargesdoc.DateUploaded = DateTime.Now; ;
            chargesdoc.CreatedBy = "";


            linqToSQLDataContext.chargesdocuments.InsertOnSubmit(chargesdoc);*/

            CashTransTemp cashTransTemp = new CashTransTemp();

            cashTransTemp.Amount = decimal.Parse( chargeModel.Amount);
            cashTransTemp.CDS_Number = chargeModel.CDS_Number;
            cashTransTemp.ChargeCode = chargeModel.ChargeCode;
            cashTransTemp.DateCreated = DateTime.Now;
            cashTransTemp.Description = chargeModel.Description;
            cashTransTemp.Reference = chargeModel.Reference;
            cashTransTemp.TransType = chargeModel.TransType;
            cashTransTemp.TransStatus = chargeModel.TransStatus;

            linqToSQLDataContext.CashTransTemps.InsertOnSubmit(cashTransTemp);

            linqToSQLDataContext.SubmitChanges();

            return "submitted";


        }

        public String addDeposit(DeliveryModel deliveryModel)
        {

            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);


            WarehourseDeliveriestemp wdt = new WarehourseDeliveriestemp();
            wdt.Holder = deliveryModel.Holder;
            wdt.Commodity = deliveryModel.Commodity;
            wdt.Quantity = decimal.Parse(deliveryModel.Quantity);
            wdt.Date_Issued = DateTime.Now;
            wdt.Warehouse = deliveryModel.Warehouse;
            wdt.UnitMeasure = deliveryModel.UnitMeasure;

            try
            {
                linqToSQLDataContext.WarehourseDeliveriestemps.InsertOnSubmit(wdt);


                linqToSQLDataContext.SubmitChanges();

                return "submitted";
            }
            catch (Exception e) {
                return e.Message;
            }
 
          

        }

        public String updateTransferApproval(string receipt_no, String approval, string otp)
        {

            if (approval.Equals("rejected"))
            {
         



                    var sql = @"DELETE FROM [CDS].[dbo].[share_transfer] WHERE [ReceiptID] = " + "'" + receipt_no + "'";

             

                    try
                    {



                        using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                        {


                            SqlCommand cmd = new SqlCommand(sql, connection);
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;
                            connection.Open();
                            cmd.ExecuteNonQuery();
                            if (cmd.ExecuteNonQuery() > 0)
                            {
                                connection.Close();
                                return approval;
                            }
                            else
                            {
                                connection.Close();
                                return "rejected";
                            }

                        }

                    }
                    catch (Exception ex)
                    {

                        return ex.Message;
                    }


            
            }
            else {
                var sql = "SELECT * FROM [cds].[dbo].[share_transfer] where [ReceiptID] =  " + "'" + receipt_no + "' AND [OTP] IS NULL OR [OTP]=" + "'" + otp + "'";


                bool hasRows = false;

                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();


                    if (rdr.HasRows)
                    {
                        hasRows = true;
                    }
                    else
                    {
                        hasRows = false;
                    }
                }

                if (hasRows)
                {



                    sql = @"UPDATE [CDS].[dbo].[share_transfer]
                SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [ReceiptID] = " + "'" + receipt_no + "' AND [OTP]=" + "'" + otp + "'";

                    try
                    {



                        using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                        {


                            SqlCommand cmd = new SqlCommand(sql, connection);
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;
                            connection.Open();
                            cmd.ExecuteNonQuery();
                            if (cmd.ExecuteNonQuery() > 0)
                            {
                                connection.Close();
                                return approval;
                            }
                            else
                            {
                                connection.Close();
                                return "false";
                            }

                        }

                    }
                    catch (Exception ex)
                    {

                        return ex.Message;
                    }


                }
            }

           

            return "true";



        }

        public String cancelTransfer(string receipt_no)
        {


            /*   var sql = @"UPDATE[CDS].[dbo].[BorrowingRequest]
        SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [collateral] = " + "'" + receipt_no + "'";*/

          //  var sql = @"DELETE FROM [CDS].[dbo].[share_transfer] WHERE [ReceiptID] = " + "'" + receipt_no + "'";

            var sql = @"UPDATE[CDS].[dbo].[share_transfer]
                SET [Deleted] = 1 WHERE [ReceiptID] = " + "'" + receipt_no + "'";

            try
            {



                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        connection.Close();
                        return "cancelled";

                    }
                    else
                    {
                        connection.Close();
                       

                        return "failed";

                    }





                }




            }
            catch (Exception ex)
            {

                return ex.Message;
            }





            return "false";



        }


        public String updateWithdrawalApproval(string receipt_no, String approval, string otp)
        {


            if (approval.Equals("rejected"))
            {

            /*    var sql = @"UPDATE[cds].[dbo].[withdrawals]
                SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [ReceiptID] = " + "'" + receipt_no + "'";*/

                var sql = @"DELETE FROM [CDS].[dbo].[withdrawals] WHERE [ReceiptID] = " + "'" + receipt_no + "'";

                try
                {



                    using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                    {


                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            connection.Close();
                            return approval;
                        }
                        else
                        {
                            connection.Close();
                            return "rejected";
                        }





                    }




                }
                catch (Exception ex)
                {

                    return ex.Message;
                }


            }
            else
            {
                var sql = "SELECT * FROM [cds].[dbo].[withdrawals] where [ReceiptID] =  " + "'" + receipt_no + "' AND [OTP] IS NULL OR [OTP]=" + "'" + otp + "'";


                bool hasRows = false;

                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();


                    if (rdr.HasRows)
                    {
                        hasRows = true;
                    }
                    else
                    {
                        hasRows = false;
                    }
                }

                if (hasRows)
                {



                    sql = @"UPDATE[cds].[dbo].[withdrawals]
                SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [ReceiptID] = " + "'" + receipt_no + "' AND [OTP]=" + "'" + otp + "'";

                    try
                    {



                        using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                        {


                            SqlCommand cmd = new SqlCommand(sql, connection);
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;
                            connection.Open();
                            cmd.ExecuteNonQuery();
                            if (cmd.ExecuteNonQuery() > 0)
                            {
                                connection.Close();
                                return approval;
                            }
                            else
                            {
                                connection.Close();
                                return "false";
                            }





                        }




                    }
                    catch (Exception ex)
                    {

                        return ex.Message;
                    }


                }
            }




            return "true";



        }

        public String cancelWithdrawal(string receipt_no)
        {


            /*   var sql = @"UPDATE[CDS].[dbo].[BorrowingRequest]
        SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [collateral] = " + "'" + receipt_no + "'";*/

            //var sql = @"DELETE FROM [CDS].[dbo].[withdrawals] WHERE [ReceiptID] = " + "'" + receipt_no + "'";
            var sql = @"UPDATE[CDS].[dbo].[withdrawals]
                SET [Deleted] = 1 WHERE [ReceiptID] = " + "'" + receipt_no + "'";

            try
            {



                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        connection.Close();
                        return "cancelled";
                     

                    }
                    else
                    {
                        connection.Close();

                        return "failed";
                    }





                }




            }
            catch (Exception ex)
            {

                return ex.Message;
            }





            return "false";



        }

        public String updateSplitApproval(string receipt_no, String approval, string otp)
        {


            if (approval.Equals("rejected"))
            {

                /*    var sql = @"UPDATE[cds].[dbo].[withdrawals]
                    SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [ReceiptID] = " + "'" + receipt_no + "'";*/

                var sql = @"DELETE FROM [CDS].[dbo].[tblWRSplits] WHERE [OriginalWRNo] = " + "'" + receipt_no + "'";

               // DELETE FROM[CDS_20NOV20].[dbo].[tblWRSplits] WHERE OriginalWRNo = 132

                try
                {



                    using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                    {


                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            connection.Close();
                            return approval;
                        }
                        else
                        {
                            connection.Close();
                            return "rejected";
                        }





                    }




                }
                catch (Exception ex)
                {

                    return ex.Message;
                }


            }
            else
            {
                var sql = "SELECT * FROM [cds].[dbo].[tblWRSplits] where [OriginalWRNo] =  " + "'" + receipt_no + "' AND [OTP] IS NULL OR [OTP]=" + "'" + otp + "'";


                bool hasRows = false;

                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();


                    if (rdr.HasRows)
                    {
                        hasRows = true;
                    }
                    else
                    {
                        hasRows = false;
                    }
                }

                if (hasRows)
                {



                    sql = @"UPDATE[cds].[dbo].[tblWRSplits]
                SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [OriginalWRNo] = " + "'" + receipt_no + "'  AND [OTP] = " + "'" + otp + "'";

                    try
                    {



                        using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                        {


                            SqlCommand cmd = new SqlCommand(sql, connection);
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;
                            connection.Open();
                            cmd.ExecuteNonQuery();
                            if (cmd.ExecuteNonQuery() > 0)
                            {
                                connection.Close();
                                return approval;
                            }
                            else
                            {
                                connection.Close();
                                return "false";
                            }





                        }




                    }
                    catch (Exception ex)
                    {

                        return ex.Message;
                    }


                }
            }




            return "true";



        }

        public String cancelSplit(string receipt_no)
        {


            /*   var sql = @"UPDATE[CDS].[dbo].[BorrowingRequest]
        SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [collateral] = " + "'" + receipt_no + "'";*/

            //var sql = @"DELETE FROM [CDS].[dbo].[tblWRSplits] WHERE [OriginalWRNo] = " + "'" + receipt_no + "'";

            var sql = @"UPDATE[CDS].[dbo].[tblWRSplits]
                SET [Deleted] = 1 WHERE [OriginalWRNo] = " + "'" + receipt_no + "'";

            try
            {



                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        connection.Close();
                        
                       
                        return "cancelled";
                    }
                    else
                    {
                        connection.Close();
                        return "failed";


                    }





                }




            }
            catch (Exception ex)
            {

                return ex.Message;
            }





            return "false";



        }


   

        public String updatePledgeApproval(string receipt_no, String approval, string otp)
        {

            if (approval.Equals("rejected"))
            {

             /*   var sql = @"UPDATE[CDS].[dbo].[BorrowingRequest]
                SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [collateral] = " + "'" + receipt_no + "'";*/

                var sql = @"DELETE FROM [CDS].[dbo].[BorrowingRequest] WHERE [collateral] = " + "'" + receipt_no + "'";

                try
                {



                    using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                    {


                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            connection.Close();
                            return approval;
                        }
                        else
                        {
                            connection.Close();
                            return "rejected";
                        }





                    }




                }
                catch (Exception ex)
                {

                    return ex.Message;
                }

            }
            else
            {
                var sql = "SELECT * FROM [CDS].[dbo].[BorrowingRequest] where [collateral] =  " + "'" + receipt_no + "' AND [OTP] IS NULL OR [OTP]=" + "'" + otp + "'";


                bool hasRows = false;

                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();


                    if (rdr.HasRows)
                    {
                        hasRows = true;
                    }
                    else
                    {
                        hasRows = false;
                    }
                }

                if (hasRows)
                {



                    sql = @"UPDATE[CDS].[dbo].[BorrowingRequest]
                SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [collateral] = " + "'" + receipt_no + "' AND [OTP]=" + "'" + otp + "'";

                    try
                    {



                        using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                        {


                            SqlCommand cmd = new SqlCommand(sql, connection);
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;
                            connection.Open();
                            cmd.ExecuteNonQuery();
                            if (cmd.ExecuteNonQuery() > 0)
                            {
                                connection.Close();
                                return approval;
                            }
                            else
                            {
                                connection.Close();
                                return "false";
                            }





                        }




                    }
                    catch (Exception ex)
                    {

                        return ex.Message;
                    }


                }
            }



    

            return "true";



        }

        public String cancelPledge(string receipt_no)
        {


            /*   var sql = @"UPDATE[CDS].[dbo].[BorrowingRequest]
        SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [collateral] = " + "'" + receipt_no + "'";*/

            //var sql = @"DELETE FROM [CDS].[dbo].[BorrowingRequest] WHERE [collateral] = " + "'" + receipt_no + "'";

            var sql = @"UPDATE[CDS].[dbo].[BorrowingRequest]
                SET [Deleted] = 1 WHERE [collateral] = " + "'" + receipt_no + "'";

            try
            {



                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        connection.Close();
                      
                        return "cancelled";

                    }
                    else
                    {
                        connection.Close();

                        return "failed";
                    }





                }




            }
            catch (Exception ex)
            {

                return ex.Message;
            }





            return "false";



        }

        public String insertAccountUpdateOTP(string CDS_Number, string otp)
        {

     
       
       

            var sql = "DECLARE @LastID numeric(18,0) SET @LastID = (SELECT MAX(B.ID) FROM cds.dbo.Accounts_Audit B WHERE B.CDS_Number="+"'"+ CDS_Number + "' AND B.AuthorizationState='O') select *  FROM cds.dbo.Accounts_Audit where isnull(OTP,'')="+"'" + otp + "'  and id = @LastID";


                bool hasRows = false;

                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();


                    if (rdr.HasRows)
                    {
                        hasRows = true;
                    }
                    else
                    {
                        hasRows = false;
                    }
                }

            if (hasRows)
            {




                sql = "DECLARE @LastID numeric(18,0) SET @LastID = (SELECT MAX(B.ID) FROM cds.dbo.Accounts_Audit B WHERE B.CDS_Number=" + "'" + CDS_Number + "' AND B.AuthorizationState='O') update cds.dbo.Accounts_Audit set OTPStatus ='APPROVED' where CDS_NUMBER =" + "'" + CDS_Number + "' and ID=@LastID";

                try
                {



                    using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                    {


                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;
                        connection.Open();
                        //cmd.ExecuteNonQuery();
                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            connection.Close();
                            return "true";
                        }
                        else
                        {
                            connection.Close();
                            return "false";
                        }


                    }




                }
                catch (Exception ex)
                {

                    return ex.Message;
                }


            }
            else {
                return "invalid";
            }
            





            return "na";



        }

        public JsonResult getNonUserApprovedTransfers(string holder_no)
        {




            var sql = "SELECT * FROM [CDS].[dbo].[share_transfer] where [transferor] ="+"'"+holder_no+"'"+" AND [OTPStatus] is null OR [OTPStatus] =" + "'expired'";

            var nonUserApprovedTransfers = new List<TransferModel>();
            

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    TransferModel transferModel = new TransferModel
                    {


                        transferor = rdr["transferor"].ToString()
                        ,
                        transferee = rdr["transferee"].ToString()
                        ,
                        receiptId = rdr["receiptid"].ToString()
                        ,
                        company = rdr["company"].ToString()
                        ,
                        amount_to_transfer = int.Parse(rdr["amount_to_transfer"].ToString())
                        ,
                        date = rdr["date"].ToString()
                      

                    };


                    nonUserApprovedTransfers.Add(transferModel);
                }
            }

            if (nonUserApprovedTransfers.Any())
            {
                return Json(nonUserApprovedTransfers, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
    

        }

        public JsonResult getCommoditiez()
        {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var commodities = new List<Para_Commodity_Type>();

            commodities = linqToSQLDataContext.Para_Commodity_Types.ToList();



            if (commodities.Any())
            {
                return Json(commodities, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }

        public JsonResult getMeasurements()
        {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var measurements = new List<para_measurement>();

            measurements = linqToSQLDataContext.para_measurements.ToList();



            if (measurements.Any())
            {
                return Json(measurements, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }

        public string AddMessage(string message) {

            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            tbl_CtradeMessage message1 = new tbl_CtradeMessage();

            message1.Message = message;
            linqToSQLDataContext.tbl_CtradeMessages.InsertOnSubmit(message1);

            linqToSQLDataContext.SubmitChanges();


            return "";
        }

        public string AddAdmin(tbl_CtradeAdmin admin)
        {

            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            tbl_CtradeAdmin admin1 = new tbl_CtradeAdmin();

            admin1 = admin;

            linqToSQLDataContext.tbl_CtradeAdmins.InsertOnSubmit(admin1);

            linqToSQLDataContext.SubmitChanges();


            return "";
        }

        public string UpdateCompanyDescription(int id,  string description)
        {

            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            tbl_CtradeCompany ctradeCompany = linqToSQLDataContext.tbl_CtradeCompanies.FirstOrDefault(company=>company.Id == id);

            ctradeCompany.Description = description;

            linqToSQLDataContext.SubmitChanges();


            return "";
        }

        public string UpdateAdminPassword(string email, string oldPassword, string newPassword)
        {

            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            tbl_CtradeAdmin ctradeAdmin = linqToSQLDataContext.tbl_CtradeAdmins.FirstOrDefault(admin => admin.Email== email && admin.Password == oldPassword);

            ctradeAdmin.Password = newPassword;

            linqToSQLDataContext.SubmitChanges();


            return "";
        }


        public string UpdateWarehouseReceiptStatus(WarehouseReceiptModel warehouseReceipt, string aft_type, string email)
        {
            string otp = generateOTP();

            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);


            try
            {
                AFT aft1 = new AFT();


                aft1.AFT_Quantity = decimal.Parse(warehouseReceipt.quantity);
                aft1.EWR_holder = warehouseReceipt.cdsNumber;
                aft1.date = DateTime.Now;
                aft1.status = "0";
                aft1.query = "0";
                aft1.company = warehouseReceipt.receiptNo;
                aft1.CaptureDate= DateTime.Now;
                aft1.CapturedBy = warehouseReceipt.cdsNumber;
                aft1.ParticipantCode = warehouseReceipt.wareHousePhysical;
                aft1.ReceiptID = warehouseReceipt.receiptNo;
                aft1.AFT_Type = aft_type;
                aft1.OTP = otp;
                aft1.OTPCreateTime = DateTime.Now;
                aft1.OTPSent = true;
            
           

                linqToSQLDataContext.AFTs.InsertOnSubmit(aft1);

                linqToSQLDataContext.SubmitChanges();

                sendmail s = new sendmail();

                string strBody = "";
                strBody = "A Warehouse receipt has marked for AFT from your account.: " + warehouseReceipt.cdsNumber.Trim();
                // strBody = "The following changes have been made to your account: " + ma + " "
                strBody = Environment.NewLine;
                strBody = "Please authorize using OTP: " + otp + "";



                s.sendEmail(email, "OTP Request", strBody, getMobileNumber(warehouseReceipt.cdsNumber));
                //s.messagesend(getMobileNumber(email), strBody);


                return "done";
            }
            catch(Exception e)
            {
                return e.Message;
            }

         
            


           
        }

        public String cancelAFT(string receipt_no)
        {


            /*   var sql = @"UPDATE[CDS].[dbo].[BorrowingRequest]
        SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [collateral] = " + "'" + receipt_no + "'";*/

            //var sql = @"DELETE FROM [CDS].[dbo].[AFT] WHERE [ReceiptID] = " + "'" + receipt_no + "'";

            var sql = @"UPDATE[CDS].[dbo].[AFT]
                SET [Deleted] = 1 WHERE [ReceiptID] = " + "'" + receipt_no + "'";

            try
            {



                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        connection.Close();
                 
                        return "cancelled";

                    }
                    else
                    {
                        connection.Close();
                        return "failed";


                    }





                }




            }
            catch (Exception ex)
            {

                return ex.Message;
            }





            return "false";



        }


        public String updateWarehouseReceiptAFTStatus(string receipt_no, String approval, string otp)
        {

            if (approval.Equals("rejected"))
            {




                var sql = @"DELETE FROM [CDS].[dbo].[AFT] WHERE [ReceiptID] = " + "'" + receipt_no + "'";



                try
                {



                    using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                    {


                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            connection.Close();
                            return approval;
                        }
                        else
                        {
                            connection.Close();
                            return "rejected";
                        }

                    }

                }
                catch (Exception ex)
                {

                    return ex.Message;
                }



            }
            else
            {
                var sql = "SELECT * FROM [cds].[dbo].[AFT] where [ReceiptID] =  " + "'" + receipt_no + "' AND [OTP] IS NULL OR [OTP]=" + "'" + otp + "'";


                bool hasRows = false;

                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();


                    if (rdr.HasRows)
                    {
                        hasRows = true;
                    }
                    else
                    {
                        hasRows = false;
                    }
                }

                if (hasRows)
                {



                    sql = @"UPDATE [CDS].[dbo].[AFT]
                SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [ReceiptID] = " + "'" + receipt_no + "' AND [OTP]=" + "'" + otp + "'";

                    try
                    {



                        using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                        {


                            SqlCommand cmd = new SqlCommand(sql, connection);
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;
                            connection.Open();
                            cmd.ExecuteNonQuery();
                            if (cmd.ExecuteNonQuery() > 0)
                            {
                                connection.Close();
                                return approval;
                            }
                            else
                            {
                                connection.Close();
                                return "false";
                            }

                        }

                    }
                    catch (Exception ex)
                    {

                        return ex.Message;
                    }


                }
            }



            return "true";



        }

        public String resendOTP(string type, string cdsNumber, string email, string receipt_no, string id) {

            string otp = generateOTP();
            if (type.Equals("transfer")) {

     

                var sql = @"UPDATE [CDS].[dbo].[share_transfer]
                SET [OTP] = " + "'" + otp + "'" + "WHERE [ReceiptID] = " + "'" + receipt_no + "'";

                try
                {



                    using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                    {


                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;
                        connection.Open();
                       // cmd.ExecuteNonQuery();
                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            sendmail s = new sendmail();


                            string strBody = "";
                            strBody = "A Warehouse receipt transfer has been initiated from your account.: " + cdsNumber;
                            // strBody = "The following changes have been made to your account: " + ma + " "
                            strBody = Environment.NewLine;
                            strBody = "Please authorize using OTP: " + otp + "";


                           
                           s.sendEmail(email, "OTP Request", strBody, getMobileNumber(cdsNumber));
                            //s.messagesend(getMobileNumber(email), strBody);
                            connection.Close();

                            return "true";
                        }
                        else
                        {
                            connection.Close();
                            return "false";
                        }

                    }

                }
                catch (Exception ex)
                {

                    return ex.Message;
                }


            }
            else if (type.Equals("pledge"))
            {
              

                var sql = @"UPDATE [CDS].[dbo].[BorrowingRequest]
                SET [OTP] = " + "'" + otp + "'" + "WHERE [collateral] = " + "'" + receipt_no + "'";

                try
                {



                    using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                    {


                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            sendmail s = new sendmail();


                            string strBody = "";
                            strBody = "A Warehouse receipt pledge has been initiated from your account.: " + cdsNumber;
                            // strBody = "The following changes have been made to your account: " + ma + " "
                            strBody = Environment.NewLine;
                            strBody = "Please authorize using OTP: " + otp + "";



                            s.sendEmail(email, "OTP Request", strBody, getMobileNumber(cdsNumber));
                            //s.messagesend(getMobileNumber(email), strBody);

                            connection.Close();
                            return "true";
                        }
                        else
                        {
                            connection.Close();
                            return "false";
                        }





                    }




                }
                catch (Exception ex)
                {

                    return ex.Message;
                }
            }
            else if (type.Equals("withdrawal"))
            {
          

                var sql = @"UPDATE [CDS].[dbo].[withdrawals]
                SET [OTP] = " + "'" + otp + "'" + "WHERE [ReceiptID] = " + "'" + receipt_no + "'";

                try
                {



                    using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                    {


                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            sendmail s = new sendmail();


                            string strBody = "";
                            strBody = "A Warehouse receipt withdrawal has been initiated from your account.: " + cdsNumber.Trim();
                            // strBody = "The following changes have been made to your account: " + ma + " "
                            strBody = Environment.NewLine;
                            strBody = "Please authorize using OTP: " + otp + "";
                            s.sendEmail(email, "OTP Request", strBody, getMobileNumber(cdsNumber));
                            //s.messagesend(getMobileNumber(email), strBody);
                            connection.Close();
                            return "true";
                        }
                        else
                        {
                            connection.Close();
                            return "false";
                        }





                    }




                }
                catch (Exception ex)
                {

                    return ex.Message;
                }

            }
            else if (type.Equals("split"))
            {
           

                var sql = @"UPDATE [CDS].[dbo].[tblWRSplits]
                SET [OTP] = " + "'" + otp + "'" + "WHERE [OriginalWRNo] = " + "'" + receipt_no + "'";


                try
                {



                    using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                    {


                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        if (cmd.ExecuteNonQuery() > 0)
                        {

                            sendmail s = new sendmail();


                            string strBody = "A Warehouse receipt split has been initiated from your account: " + cdsNumber + "\n Please authorize using OTP: " + otp;


                            s.sendEmail(email, "OTP Request", strBody, getMobileNumber(cdsNumber));
                            //s.messagesend(getMobileNumber(email), strBody);
                            connection.Close();
                            return "true";
                        }
                        else
                        {
                            connection.Close();
                            return "false";
                        }





                    }




                }
                catch (Exception ex)
                {

                    return ex.Message;
                }
            }
            else if (type.Equals("aft"))
            {
                
                 var   sql = @"UPDATE [CDS].[dbo].[AFT]
                SET [OTP] = " + "'" + otp + "'" + "WHERE [ReceiptID] = " + "'" + receipt_no + "'";

                    try
                    {



                        using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                        {


                            SqlCommand cmd = new SqlCommand(sql, connection);
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;
                            connection.Open();
                            cmd.ExecuteNonQuery();
                            if (cmd.ExecuteNonQuery() > 0)
                            {
                            sendmail s = new sendmail();

                            string strBody = "";
                            strBody = "A Warehouse receipt has marked for AFT from your account.: " + cdsNumber.Trim();
                            // strBody = "The following changes have been made to your account: " + ma + " "
                            strBody = Environment.NewLine;
                            strBody = "Please authorize using OTP: " + otp + "";



                            s.sendEmail(email, "OTP Request", strBody, getMobileNumber(cdsNumber));
                            //s.messagesend(getMobileNumber(email), strBody);
                            connection.Close();
                                return "true";
                            }
                            else
                            {
                                connection.Close();
                                return "false";
                            }

                        }

                    }
                    catch (Exception ex)
                    {

                        return ex.Message;
                    }


            }
            else if (type.Equals("acc_update"))
            {
      

                var sql = @"UPDATE cds.dbo.Accounts_Audit SET OTP='" + otp + "' WHERE ID ='" + id + "'";

                try
                {



                    using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                    {


                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            sendmail s = new sendmail();
                            
                            string strBody = "";
                            strBody = "Changes have been made to your account, Account No.:.: " + cdsNumber.Trim();
                            // strBody = "The following changes have been made to your account: " + ma + " "
                            strBody = Environment.NewLine;
                            strBody = "Please authorize using OTP: " + otp + "";



                            s.sendEmail(email, "OTP Request", strBody, getMobileNumber(cdsNumber));
                            //s.messagesend(getMobileNumber(email), strBody);
                            connection.Close();
                            return "true";
                        }
                        else
                        {
                            connection.Close();
                            return "false";
                        }

                    }

                }
                catch (Exception ex)
                {

                    return ex.Message;
                }

            }

            return "na";


        }



        public string DeleteMessage(int id)
        {

            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            tbl_CtradeMessage ctradeMessage = linqToSQLDataContext.tbl_CtradeMessages.FirstOrDefault(message => message.Id == id);

            linqToSQLDataContext.tbl_CtradeMessages.DeleteOnSubmit(ctradeMessage);

        

            linqToSQLDataContext.SubmitChanges();


            return "";
        }

        public JsonResult getMessages() {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var messages = new List<tbl_CtradeMessage>();

            messages = linqToSQLDataContext.tbl_CtradeMessages.ToList();



            if (messages.Any())
            {
                return Json(messages, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }


        public JsonResult getCompaniez()
        {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var companies = new List<tbl_CtradeCompany>();

            companies = linqToSQLDataContext.tbl_CtradeCompanies.ToList();



            if (companies.Any())
            {
                return Json(companies, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }


        public JsonResult getUzers()
        {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var uzers = new List<tbl_CtradeAdmin>();

            uzers = linqToSQLDataContext.tbl_CtradeAdmins.ToList();



            if (uzers.Any())
            {
                return Json(uzers, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }


        public JsonResult getUzer(string email, string password)
        {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var uzer = linqToSQLDataContext.tbl_CtradeAdmins.Where(user=>user.Email == email && user.Password == password);



            if (uzer != null)
            {
                return Json(uzer, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }


        public JsonResult getSplitz(string participant)
        {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var splitz = linqToSQLDataContext.tblWRSplits.Where(split => split.Inputter == participant).ToList();



            if (splitz != null)
            {
                return Json(splitz, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }

        public JsonResult getCharges(string cds_number)
        {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var cashTransations = linqToSQLDataContext.CashTrans.Where(cashTran => cashTran.CDS_Number == cds_number).ToList();



            if (cashTransations != null)
            {
                return Json(cashTransations, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }

        public JsonResult getPendingChargez(string cds_number)
        {

            var chargesModels = new List<ChargeModel>();

            //sql = "SELECT * FROM [cds].[dbo].[CashTransTemps] where [CDS_Number] =   '" + cds_number + "' ";
            var sql = "select distinct Reference, [Description],FORMAT(sum([Amount]) * -1,'#,0.00') as [Amount], chargecode,'NOT PAID' AS STATUS FROM[CDS].[dbo].[CashTrans] a where CDS_Number = '" + cds_number + "'  and ChargeCode = (select top 1 ChargeCode from[CDS].[dbo].[CashTrans] c where c.ChargeCode = a.ChargeCode   ) and a.Reference not in  (select  Reference from[CDS].[dbo].[CashTransTemps] c where c.Reference = a.Reference  and c. CDS_Number = a.CDS_Number   ) group by[Description], Reference, chargecode union select distinct Reference, [Description], FORMAT(sum([Amount]),'#,0.00') as [Amount], chargecode,'PENDING'  AS STATUS FROM[CDS].[dbo].[CashTransTemps] b where CDS_Number = '" + cds_number + "' and ChargeCode = (select top 1 ChargeCode from[CDS].[dbo].[CashTransTemps] d where d.ChargeCode = b.ChargeCode ) and b.Reference in  (select  Reference from[CDS].[dbo].[CashTranstemps] c where c.Reference = b.Reference   )  group by[Description], Reference, chargecode";


            try
            {
                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();


                    while (rdr.Read())
                    {
                        ChargeModel chargeModel = new ChargeModel
                        {


                            Reference = rdr["Reference"].ToString()
                            ,
                            Description = rdr["Description"].ToString()
                            ,
                            Amount = rdr["Amount"].ToString()
                            ,
                            ChargeCode = rdr["chargecode"].ToString()
                            ,
                            TransStatus = rdr["STATUS"].ToString()

                        };


                        chargesModels.Add(chargeModel);
                    }
                }

                if (chargesModels.Any())
                {
                    return Json(chargesModels, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("No data was found", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception e)
            {


                Json(e.Message, JsonRequestBehavior.AllowGet);

            }


            return Json("No data was found", JsonRequestBehavior.AllowGet);



        }

        public JsonResult getPendingCharges(string cds_number)
        {



            var pendingCharges = new List<PendingChargesModel>();

            var sql = "SELECT * FROM [cds].[dbo].[CashTransTemps] where [CDS_Number] =   '" + cds_number + "' ";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();


                    while (rdr.Read())
                    {
                        PendingChargesModel pendingChargesModel = new PendingChargesModel
                        {


                            ChargeCode = rdr["ChargeCode"].ToString()


                        };


                        pendingCharges.Add(pendingChargesModel);
                    }
                }

                if (pendingCharges.Any())
                {
                    return Json(pendingCharges, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("No data was found", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception e) {

                
                Json(e.Message, JsonRequestBehavior.AllowGet);

            }


            return Json("No data was found", JsonRequestBehavior.AllowGet);





        }


        public JsonResult getTransfers(string transferor)
        {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var transfers = linqToSQLDataContext.share_transfers.Where(transfer => transfer.transferor == transferor).ToList();



            if (transfers != null)
            {
                return Json(transfers, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }

        public JsonResult getWithdrawals(string cds_number)
        {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var withdrawals = linqToSQLDataContext.withdrawals .Where(withdrawal => withdrawal.EWR_holder == cds_number).ToList();



            if (withdrawals != null)
            {
                return Json(withdrawals, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }

        public JsonResult getPledgez(string cds_number)
        {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var pledges = linqToSQLDataContext.BorrowingRequests.Where(pledge => pledge.Borrower == cds_number).ToList();



            if (pledges != null)
            {
                return Json(pledges, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }


        public JsonResult getPendingTrans()
        {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var pendingTrans = linqToSQLDataContext.pendingtrans.ToList();



            if (pendingTrans != null)
            {
                return Json(pendingTrans, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }




        public JsonResult getPendingAFT(string cds_number)
        {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var pendingAFT = linqToSQLDataContext.AFTs.Where(aft => aft.EWR_holder == cds_number).ToList();



            if (pendingAFT != null)
            {
                return Json(pendingAFT, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }

        public JsonResult getDeposits(string writerNo)
        {


            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);

            var deposits = linqToSQLDataContext.WarehourseDeliveriestemps.Where(deposit => deposit.Holder == writerNo).ToList();



            if (deposits != null)
            {
                return Json(deposits, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }


        public bool checkFirstTimeLogin(string email)
        {



            var sql = "SELECT * FROM [CDSC].[dbo].[Vatenkecis] where [Email] =  " + "'" + email + "' AND [isFirstTime] = " +"'1'";

            bool isFirstTime = false;
            

            using (SqlConnection connection = new SqlConnection(connectionStringCDSC))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();


                if (rdr.HasRows)
                {
                    isFirstTime = true;
                }
            }

            return isFirstTime;

        }


        private bool checkTransferApproved(string EWRNo)
        {

          

            var sql = "SELECT * FROM [CDS].[dbo].[share_transfer] where [ReceiptID] =  " + "'" + EWRNo + "' AND [status] = " + "'0'";

            bool isApproved = false;


            using (SqlConnection connection = new SqlConnection(connectionStringCDS))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();


                if (rdr.HasRows)
                {
                    isApproved = false;
                }
                else {
                    isApproved = true;
                }
            }

            return isApproved; 

        }

        public bool checkSplitApproved(string EWRNo)
        {
            

            var sql = "SELECT * FROM [cds].[dbo].[tblWRSplits] where [OriginalWRNo] =  " + "'" + EWRNo + "' AND [Authoriser] IS NULL";

            bool isApproved = false;

            using (SqlConnection connection = new SqlConnection(connectionStringCDS))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();


                if (rdr.HasRows)
                {
                    isApproved = false;
                }
                else
                {
                    isApproved = true;
                }
            }

            return isApproved;

        }


        public string insertWarehouseReceiptsTransfer(TransferModel transferModel, string email)
        {

            var otp = generateOTP();
            var nn = "";


            var sql = @"INSERT INTO [CDS].[dbo].[share_transfer]
                               ([amount_to_transfer]
                               ,[transferor]
                               ,[transferee]
                               ,[date]
                               ,[status]
                               ,[query]
                               ,[company]
                               ,[ReceiptID]
                               ,[CapturedBy]
                               ,[CaptureDate]
                               ,[ParticipantCode]
                               ,[OTP]
                               ,[OTPCreateTime]
                               ,[OTPSent]
                                )        
                         VALUES
                               ('" + transferModel.amount_to_transfer + @"'
                               ,'" + transferModel.transferor.Trim() + @"'
                               ,'" + transferModel.transferee.Trim() + @"'
                               ,GETDATE()
                               ,'" + transferModel.status.Trim() + @"'
                               ,'" + 0 + @"'
                               ,'" + transferModel.receiptId.Trim() + @"'
                               ,'" + transferModel.receiptId.Trim() + @"'
                               ,'" + transferModel.transferor.Trim() + @"'
                               ,GETDATE()
                               ,'" + transferModel.participant_code.Trim() + @"'
                               ,'" + otp+ @"'
                               ,GETDATE()
                               ,'" + 1 + @"') ";
                        

            //bool isApproved = checkTransferApproved(transferModel.receiptId);

            try
            {

                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {

                  


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    //cmd.ExecuteNonQuery();
                    if (cmd.ExecuteNonQuery() == 1)
                    {



                        billTransferCharges(transferModel.transferor.Trim(), transferModel.amount_to_transfer, transferModel.receiptId.Trim());
                        connection.Close();
                        nn = "true";

                    }
                    else
                    {
                        connection.Close();
                        nn = "false";

                    }




                }

                if (nn.Equals("true"))
                {
                    sendmail s = new sendmail();


                    string strBody = "";
                    strBody = "A Warehouse receipt transfer has been initiated from your account.: " + transferModel.transferor.Trim();
                    // strBody = "The following changes have been made to your account: " + ma + " "
                    strBody = Environment.NewLine;
                    strBody = "Please authorize using OTP: " + otp + "";


                    var n = "OTP Request";
                    sql = "insert into emaillog(email_address, [subject],[body],[status],[date],[sender]) values('" + email + "', '" + n + "', '" + strBody + "', '0', getdate(), 'ADMIN')";
                    s.sendEmail(email, "OTP Request", strBody, getMobileNumber(transferModel.transferor.Trim()));
                    //s.messagesend(getMobileNumber(email), strBody);

                    return "true";
                }
                else
                {
                    return "false";
                }



            }
            catch (Exception ex)
            {
               
                return ex.Message;
            }


        }

        public JsonResult testSplits() { 
        
            String  a = "20-000028-000";

            string WRParentPrefix;
            string WRChildSuffix;
            var ss = new List<String>();


            int count = int.Parse(a.Substring(12));
            int num = (int) GetMaxSplit(a);
;            for (int i = 0; i < 90; i++) {

                 num++;


                WRParentPrefix = a.Substring(0, 9);


                int maxsplit = num;

                int ii= 1;
                WRChildSuffix = "" + maxsplit;

                for (ii = Strings.Len(maxsplit.ToString()); ii <= 2; ii++)
                {
                    WRChildSuffix = "0" + WRChildSuffix;
                }



                ss.Add(WRParentPrefix + "   :  " + WRChildSuffix);

                count++;



            }


            return Json(ss, JsonRequestBehavior.AllowGet);
            

        }


        public decimal GetMaxSplit(string WRNo)
        {
        
            SqlConnection connection = new SqlConnection(connectionStringCDS);
          //  var sql = "SELECT * FROM [CDS].[dbo].[WR] " + " where [holder] =  " + "'" + WRNo + "'";
           var sql = "select isnull(count(*),0)+(SELECT count(*) from cds.dbo.tblWRSplits where state<>'A' and [OriginalWRNo]='" + WRNo + "')  as tot from cds.dbo.wr where LEFT(receiptno,LEN(receiptno)-4)=LEFT('" + WRNo + "',LEN('" + WRNo + "')-4)";
            connection.Open();

            SqlCommand cmd = new SqlCommand(sql, connection);
            cmd.CommandType = CommandType.Text;



            decimal rec = 0;
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                 rec = decimal.Parse(rdr["tot"].ToString());
            }



       

            connection.Close();

            return rec -1;

         

        }


        public string insertWarehouseReceiptSplits(List<SplitWarehouseReceiptModel> warehouseReceipts, string email)
        {

            var otp = generateOTP();

            SqlConnection connection = new SqlConnection(connectionStringCDS);
            connection.Open();
            string isInserted = "false";

            //   bool isApproved = checkSplitApproved(warehouseReceipts[0].OriginalWRNo);

            // WRChildSuffix;

            int num = (int)GetMaxSplit(warehouseReceipts[0].OriginalWRNo);
            foreach (SplitWarehouseReceiptModel warehouseReceipt in warehouseReceipts)
            {


                string WRParentPrefix = "";
                string WRChildSuffix = "";

                try
                {

                    num++;
                    //20-000018-009
                    WRParentPrefix = warehouseReceipt.OriginalWRNo.Substring(0, 9);

                    int maxsplit = num;


                    int ii = 1;
                    WRChildSuffix = "" + maxsplit;

                    for (ii = Strings.Len(maxsplit.ToString()); ii <= 2; ii++)
                    {
                        WRChildSuffix = "0" + WRChildSuffix;
                    }


                    var sql = @"insert into [cds].[dbo].[tblWRSplits]
                               ([TransactionRef]
                                ,[inputter]
                               ,[TransactionDate]
                               ,[OriginalWRNo]
                               ,[OriginalQTY]
                               ,[ChildQTY]
                               ,[State]
                               ,[AuthDate]
                               ,[WRParentPrefix]
                               ,[WRChildSuffix]
                               ,Participant
                                ,[OTP]
                               ,[OTPSent]
                            )
                         values
                               ('" + warehouseReceipt.TransactionRef.Trim() + @"'
                                ,'" + warehouseReceipt.Inputter.Trim() + @"'
                               ,getdate()
                               ,'" + warehouseReceipt.OriginalWRNo.Trim() + @"'
                               ,'" + warehouseReceipt.OriginalQTY.Trim() + @"'
                               ,'" + warehouseReceipt.ChildQTY.Trim() + @"'
                               ,'" + warehouseReceipt.State.Trim() + @"'
                               ,getdate()
                               ,'" + WRParentPrefix.Trim() + @"'
                               ,'" + WRChildSuffix.Trim() + @"'
                               ,'" + warehouseReceipt.Participant.Trim() + @"'
                               ,'" + otp + @"'
                               ,'" + 1 + @"') ";



                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;



                    if (cmd.ExecuteNonQuery() == 1)
                    {
                        isInserted = "true";
                        sendmail s = new sendmail();


                        string strBody = "A Warehouse receipt split has been initiated from your account: " + warehouseReceipts[0].Participant.Trim() + "\n Please authorize using OTP: " + otp;


                        s.sendEmail(email, "OTP Request", strBody, getMobileNumber(warehouseReceipt.Inputter.Trim()));
                        // s.messagesend(getMobileNumber(email), strBody);

                    }
                    else
                    {
                        isInserted = "false";

                        break;
                    }


                }
                catch (Exception ex)
                {
                    connection.Close();
                    isInserted = ex.Message;
                    return ex.Message;

                }




            }





            connection.Close();
            
            return isInserted;


        }


        public string getOldOTP(string EWRNo)
        {


            var sql = "SELECT otp FROM [cds].[dbo].[tblWRSplits] where [OriginalWRNo] =  " + "'" + EWRNo + "'";

            string otp = "";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {

                    otp = rdr["otp"].ToString();

                }
                

            }

            return otp;

        }



        public string InsertSplit(SplitWarehouseReceiptModel warehouseReceipt)
        {

          
            string otp ="";
            if (getOldOTP(warehouseReceipt.OriginalWRNo) == "")
            {
                otp = generateOTP();
            }
            else {

                otp = getOldOTP(warehouseReceipt.OriginalWRNo);
            }

            LinqToSQLDataContext linqToSQLDataContext = new LinqToSQLDataContext(connectionStringCDS);


            try
            {
        

                tblWRSplit splitTable = new tblWRSplit();

                string WRParentPrefix = "";
                string WRChildSuffix = "";


                int num = (int)GetMaxSplit(warehouseReceipt.OriginalWRNo);

                //num++;
                //20-000018-009
                WRParentPrefix = warehouseReceipt.OriginalWRNo.Substring(0, 9);

                num++;
                int maxsplit = num;

                int ii = 1;
                WRChildSuffix = "" + maxsplit;

                for (ii = Strings.Len(maxsplit.ToString()); ii <= 2; ii++)
                {
                    WRChildSuffix = "0" + WRChildSuffix;
                }


                splitTable.TransactionRef = warehouseReceipt.TransactionRef.Trim();
                splitTable.Inputter = warehouseReceipt.Inputter.Trim();
                splitTable.TransactionDate = DateTime.Now;
                splitTable.OriginalWRNo = warehouseReceipt.OriginalWRNo;
                splitTable.OriginalQTY = decimal.Parse(warehouseReceipt.OriginalQTY);
                splitTable.ChildQTY = decimal.Parse(warehouseReceipt.ChildQTY);
                splitTable.State = warehouseReceipt.State;
                splitTable.WRParentPrefix = WRParentPrefix;
                splitTable.WRChildSuffix = WRChildSuffix;
                splitTable.Participant = warehouseReceipt.Participant;
                splitTable.OTP = otp;
                splitTable.OTPCreateTime = DateTime.Now;
                splitTable.OTPSent = true;




                linqToSQLDataContext.tblWRSplits.InsertOnSubmit(splitTable);

                linqToSQLDataContext.SubmitChanges();


                return WRChildSuffix;
            }
            catch (Exception e)
            {
                return e.Message;
            }


        }

        public String clearSplits(string receipt_no)
        {


            /*   var sql = @"UPDATE[CDS].[dbo].[BorrowingRequest]
        SET [OTPStatus] = " + "'" + approval + "'" + "WHERE [collateral] = " + "'" + receipt_no + "'";*/

            var sql = @"DELETE FROM [CDS].[dbo].[tblWRSplits] WHERE [OriginalWRNo] = " + "'" + receipt_no + "'";

            try
            {



                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        connection.Close();

                        return "failed";
                    }
                    else
                    {
                        connection.Close();
                        return "cancelled";

                    }





                }




            }
            catch (Exception ex)
            {

                return ex.Message;
            }





            return "false";



        }


        public String submitSplit(string receipt_no, string email)
        {




            var state = "C";


                    var sql = @"UPDATE[cds].[dbo].[tblWRSplits]
                SET [State] = " + "'" + state + "'" + "WHERE [OriginalWRNo] = " + "'" + receipt_no.Trim() + "'";

                    try
                    {



                        using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                        {


                            SqlCommand cmd = new SqlCommand(sql, connection);
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;
                            connection.Open();
                            cmd.ExecuteNonQuery();
                            if (cmd.ExecuteNonQuery() > 0)
                            {
                                sendmail s = new sendmail();


                                string strBody = "A Warehouse receipt split has been initiated from your account: " + receipt_no + "\n Please authorize using OTP: " + getOldOTP(receipt_no);


                                s.sendEmail(email, "OTP Request", strBody, getMobileNumber(email));
                                // s.messagesend(getMobileNumber(email), strBody);
                        connection.Close();
                                return "updated";
                            }
                            else
                            {
                                connection.Close();
                                return receipt_no;
                            }





                        }




                    }
                    catch (Exception ex)
                    {

                        return ex.Message;
                    }



        }


        public String updateSplit(string receipt_no, string qty)
        {


            var sql = @"UPDATE[cds].[dbo].[tblWRSplits]
                SET [ChildQTY] = " + "'" + qty + "'" + "WHERE [WRChildSuffix] = " + "'" + receipt_no.Trim() + "'";

            try
            {



                using (SqlConnection connection = new SqlConnection(connectionStringCDS))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        connection.Close();
                        return "updated";
                    }
                    else
                    {
                        connection.Close();
                        return receipt_no;
                    }





                }




            }
            catch (Exception ex)
            {

                return ex.Message;
            }



        }





        public string insertWarehouseReceiptSplitsWeb(string TransactionRef, string OGWRNumber, string OGQTY, string childQTY, string State, string Participant)
        {

            SqlConnection connection = new SqlConnection(connectionStringCDS);
            connection.Open();
            string isInserted = "false";

            bool isApproved = checkSplitApproved(OGWRNumber);

            // WRChildSuffix;

            if (isApproved)
            {

                string WRParentPrefix;
                string WRChildSuffix;

                try
                {
                    WRParentPrefix = OGWRNumber.Substring(0, 8);
                    WRChildSuffix = OGWRNumber.Substring(8);
                }
                catch (Exception e)
                {
                    WRParentPrefix = OGWRNumber.Substring(0, 1);
                    WRChildSuffix = OGWRNumber.Substring(1);

                }


                var sql = @"insert into [cds].[dbo].[tblWRSplits]
                               ([TransactionRef]
                               ,[TransactionDate]
                               ,[OriginalWRNo]
                               ,[OriginalQTY]
                               ,[ChildQTY]
                               ,[State]
                               ,[AuthDate]
                               ,[WRParentPrefix]
                               ,[WRChildSuffix]
                               ,Participant)
                         values
                               ('" + TransactionRef.Trim() + @"'
                               ,getdate()
                               ,'" + OGWRNumber.Trim() + @"'
                               ,'" + OGQTY.Trim() + @"'
                               ,'" + childQTY.Trim() + @"'
                               ,'" + State.Trim() + @"'
                               ,getdate()
                               ,'" + WRParentPrefix.Trim() + @"'
                               ,'" + WRChildSuffix.Trim() + @"'
                               ,'" + Participant.Trim() + @"') ";

                try
                {



                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;



                    if (cmd.ExecuteNonQuery() == 1)
                    {
                        isInserted = "true";

                    }
                    else
                    {
                        isInserted = "false";


                    }




                }
                catch (Exception ex)
                {
                    isInserted = ex.Message;

                    connection.Close();

                    return ex.Message;
                }

            }
            else
            {
                isInserted = "not";

            }



            connection.Close();

            return isInserted;

        }



        public String insertWarehouseReceiptmerge(TransferModel transferModel)
        {


            var sql = @"INSERT INTO [CDS_Router].[dbo].[share_transfer]
                               ([amount_to_transfer]
                               ,[transferor]
                               ,[transferee]
                               ,[date]
                               ,[status]
                               ,[query]
                               ,company)
                         VALUES
                               ('" + transferModel.amount_to_transfer + @"'
                               ,'" + transferModel.transferor.Trim() + @"'
                               ,'" + transferModel.transferee.Trim() + @"'
                               ,GETDATE()
                               ,'" + transferModel.status.Trim() + @"'
                                ,'" + transferModel.query.Trim() + @"'
                               ,'" + transferModel.company.Trim() + @"') ";



            try
            {
                using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                    return "{ \"status\":\"true\",\"massage\":\"Transfer successfull\"}";


                }

            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }

       /* public JsonResult getPendingWithdrawals(string cds_number)
        {

   
            var pendingWithdrawals = new List<PendingWithdrawalModel>();

            var sql = "SELECT [CDS_Number], [Commodity], [Quantity] , [Value] FROM [CDS_ROUTER].[dbo].[PendingWithdrawals] " +
                " where [CDS_Number] =  " + "'"+cds_number+"'";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    PendingWithdrawalModel pendingWithdrawal = new PendingWithdrawalModel();
                    pendingWithdrawal._EWR_holder = rdr["CDS_Number"].ToString();
                    pendingWithdrawal.commodity = rdr["Commodity"].ToString();
                    pendingWithdrawal.quantity = rdr["Quantity"].ToString(); ;
                    pendingWithdrawal.value = rdr["Value"].ToString(); ;
             
                    pendingWithdrawals.Add(pendingWithdrawal);
                }
            }

            if (pendingWithdrawals.Any())
            {
                return Json(pendingWithdrawals, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }*/


        public JsonResult getWarehouseReceipts(string cds_number)
        {


            var warehouseReceipts = new List<WarehouseReceiptModel>();

            var sql = "SELECT * FROM [CDS].[dbo].[WR] " + " where [holder] =  " + "'" + cds_number + "'";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    WarehouseReceiptModel warehouseReceipt = new WarehouseReceiptModel
                    {
                       
                    
                        cdsNumber = rdr["holder"].ToString()
                        ,commodity = rdr["commodity"].ToString()
                        ,grade = rdr["grade"].ToString()
                        ,warehouse = rdr["warehouse"].ToString()
                        ,expiry = rdr["expiry"].ToString()
                        ,dateIssued = rdr["date_issued"].ToString()
                        ,quantity = rdr["quantity"].ToString()
                        ,insurancePolicy = rdr["insurancePolicy"].ToString()
                        ,price = rdr["price"].ToString()
                        ,issuer = rdr["issued_by"].ToString()
                        ,approver = rdr["approved_by"].ToString()
                        ,approvedOn = rdr["approvedOn"].ToString()
                        ,receiptNo = rdr["receiptNo"].ToString()
                        ,harvestDate = rdr["harvestDate"].ToString()
                        ,unitMeasure = rdr["unitMeasure"].ToString()
                        ,insuranceCompany = rdr["insuranceCompany"].ToString()
                        ,insuranceDetails = rdr["insuranceDetails"].ToString()
                        ,insuranceExpiry = rdr["insuranceExpiry"].ToString()
                        ,moistureContent = rdr["moistureContent"].ToString()
                        ,broken = rdr["broken"].ToString()
                        ,damage = rdr["damage"].ToString()
                        ,foreignMatters = rdr["foreignMatters"].ToString()
                        ,transportCharges = rdr["transportCharges"].ToString()
                        ,wareHousePhysical = rdr["wareHousePhysical"].ToString()
                        ,status = rdr["status"].ToString()
                        ,deliveryId = rdr["deliveryId"].ToString()
                        ,originalQuanity = rdr["originalQuantity"].ToString()
                        ,approve1 = rdr["approve1"].ToString()
                        ,approve2 = rdr["approve2"].ToString()
                        ,
                       sentPmex = rdr["sentPmex"].ToString()


                    };
            

                    warehouseReceipts.Add(warehouseReceipt);
                }
            }

            if (warehouseReceipts.Any())
            {
                return Json(warehouseReceipts, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }


        public JsonResult getSplitWarehouseReceipts(string cds_number)
        {


            var splitWarehouseReceipts = new List<SplitWarehouseReceiptModel>();

            
//select TransactionDate, OriginalWRNo, 
//OriginalQTY, ChildQTY, Commodity from [cds].[dbo].tblWRSplits Inner join cds.dbo.WR on [cds].[dbo].tblWRSplits.OriginalWRNo=
//cds.dbo.WR.ReceiptNo Where cds.dbo.WR.Holder='180625032933-0001/11700374'

            var sql = "SELECT * FROM [cds].[dbo].[tblWRSplits] Inner join [cds].[dbo].[WR] on [cds].[dbo].[tblWRSplits].OriginalWRNo=[cds].[dbo].[WR].ReceiptNo Where [cds].[dbo].[WR].Holder=" + "'"+cds_number+"'";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    SplitWarehouseReceiptModel splitWarehouseReceipt = new SplitWarehouseReceiptModel
                    {


                        TransactionDate = rdr["TransactionDate"].ToString()
                        ,
                        OriginalWRNo = rdr["OriginalWRNo"].ToString()
                        ,
                        OriginalQTY = rdr["OriginalQTY"].ToString()
                        ,
                        ChildQTY = rdr["ChildQTY"].ToString()
                        ,
                        Commodity = rdr["Commodity"].ToString()
                        ,
                        Authoriser = rdr["Authoriser"].ToString()
                        ,
                        OTPStatus = rdr["OTPStatus"].ToString()


                    };


                    splitWarehouseReceipts.Add(splitWarehouseReceipt);
                }
            }

            if (splitWarehouseReceipts.Any())
            {
                return Json(splitWarehouseReceipts, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
          
        }


        public JsonResult getWarehouses()
        {


            var warehouses = new List<WarehouseModel>();
            

           var sql = "SELECT * FROM [cds].[dbo].[WarehouseCreation] ";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    WarehouseModel warehouse = new WarehouseModel
                    {


                        warehouseName = rdr["warehouseName"].ToString()
                        ,
                        warehouseCode = rdr["warehouseCode"].ToString()
                        ,
                        warehouseOperator = rdr["warehouseOperator"].ToString()
                      

                    };


                    warehouses.Add(warehouse);
                }
            }

            if (warehouses.Any())
            {
                return Json(warehouses, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
     
        }

        public JsonResult getStates()
        {


            var states = new List<StateModel>();


            

           var sql = "SELECT * FROM [cds].[dbo].[para_states] ";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    StateModel state = new StateModel
                    {


                        state = rdr["state"].ToString()
                 


                    };


                    states.Add(state);
                }
            }

            if (states.Any())
            {
                return Json(states, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);

        }


        public JsonResult getClientByEmail(string email)
        {


            var accountsClients = new List<AccountClientsWebModel>();

            var sql = "SELECT * FROM [CDS_ROUTER].[dbo].[Accounts_Clients_Web] " +" where [email] =  " + "'" + email + "'";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                
                List<string> ClientImages = new List<string>();
                List<string> BioMatrices = new List<string>();
                List<string> Documents = new List<string>();

                while (rdr.Read())
                {



                    AccountClientsWebModel account = new AccountClientsWebModel
                    {

                        DateCreated = rdr["Date_Created"].ToString()
                        ,
                        DOB = rdr["DOB"].ToString()
                        ,
                        Id = rdr["ID"].ToString()
                        ,
                        CDSNumber = rdr["CDS_Number"].ToString()
                        ,
                        BrokerCode = rdr["BrokerCode"].ToString()
                        ,
                        AccountType = rdr["AccountType"].ToString()
                        ,
                        Surname = rdr["Surname"].ToString()
                        ,
                        Middlename = rdr["Middlename"].ToString()
                        ,
                        Forenames = rdr["Forenames"].ToString()
                        ,
                        Initials = rdr["Initials"].ToString()
                        ,
                        Title = rdr["Title"].ToString()
                        ,
                        IDNoPP = rdr["IDNoPP"].ToString()
                        ,
                        IDtype = rdr["IDtype"].ToString()
                        ,
                        Nationality = rdr["Nationality"].ToString()
                        ,
                        Gender = rdr["Gender"].ToString()
                        ,
                        Add1 = rdr["Add_1"].ToString()
                        ,
                        Add2 = rdr["Add_2"].ToString()
                        ,
                        Add3 = rdr["Add_3"].ToString()
                        ,
                        Add4 = rdr["Add_4"].ToString()
                        ,
                        Country = rdr["Country"].ToString()
                        ,
                        City = rdr["City"].ToString()
                        ,
                        Tel = rdr["Tel"].ToString()
                        ,
                        Mobile = rdr["Mobile"].ToString()
                        ,
                        Email = rdr["Email"].ToString()
                        ,
                        Category = rdr["Category"].ToString()
                        ,
                        Custodian = rdr["Custodian"].ToString()
                        ,
                        TradingStatus = rdr["TradingStatus"].ToString()
                        ,
                        Industry = rdr["Industry"].ToString()
                        ,
                        Tax = rdr["Tax"].ToString()
                        ,
                        DivBank = rdr["Div_Bank"].ToString()
                        ,
                        DivBranch = rdr["Div_Branch"].ToString()
                        ,
                        DivAccountNo = rdr["Div_AccountNo"].ToString()
                        ,
                        CashBank = rdr["Cash_Bank"].ToString()
                        ,
                        CashBranch = rdr["Cash_Branch"].ToString()
                        ,
                        CashAccountNo = rdr["Cash_AccountNo"].ToString()
                        ,
                        AttachedDocuments = rdr["Attached_Documents"].ToString()
                        ,
                        UpdateType = rdr["Update_Type"].ToString()
                        ,
                        CreatedBy = rdr["Created_By"].ToString()
                        ,
                        AccountState = rdr["AccountState"].ToString()
                        ,
                        Comments = rdr["Comments"].ToString()
                        ,
                        DivPayee = rdr["DivPayee"].ToString()
                        ,
                        SettlementPayee = rdr["SettlementPayee"].ToString()
                        ,
                        Accountclass = rdr["Account_class"].ToString()
                        ,
                        Idnopp2 = rdr["Idnopp2"].ToString()
                        ,
                        Idtype2 = rdr["Idtype2"].ToString()
                        ,
                        ClientImage2 = rdr["Client_Image2"].ToString()
                        ,
                        Documents2 = rdr["Documents2"].ToString()
                        ,
                        Isin = rdr["Isin"].ToString()
                        ,
                        CompanyCode = rdr["Company_Code"].ToString()
                        ,
                        MobileMoney = rdr["Mobile_Money"].ToString()
                        ,
                        MobileNumber = rdr["Mobile_Number"].ToString()
                        ,
                        Sttupdate = rdr["Sttupdate"].ToString()
                        ,
                        Currency = rdr["Currency"].ToString()
                        ,
                        TradingPlatform = rdr["Trading_Platform"].ToString()
                        ,
                        SourceName = rdr["SourceName"].ToString()



                    };


                    account.ClientImage = ClientImages.ToArray();
                    account.Documents = Documents.ToArray();
                    account.BioMatrix = BioMatrices.ToArray();
                    accountsClients.Add(account);

             
                }
            }

            if (accountsClients.Any())
            {
                return Json(accountsClients, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }

        public JsonResult getClients()
        {


            var accountsClients = new List<AccountClientsWebModel>();

            var sql = "SELECT * FROM [CDS_ROUTER].[dbo].[Accounts_Clients_Web]";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();

                List<string> ClientImages = new List<string>();
                List<string> BioMatrices = new List<string>();
                List<string> Documents = new List<string>();

                while (rdr.Read())
                {



                    AccountClientsWebModel account = new AccountClientsWebModel
                    {

                        DateCreated = rdr["Date_Created"].ToString()
                        ,
                        DOB = rdr["DOB"].ToString()
                        ,
                        Id = rdr["ID"].ToString()
                        ,
                        CDSNumber = rdr["CDS_Number"].ToString()
                        ,
                        BrokerCode = rdr["BrokerCode"].ToString()
                        ,
                        AccountType = rdr["AccountType"].ToString()
                        ,
                        Surname = rdr["Surname"].ToString()
                        ,
                        Middlename = rdr["Middlename"].ToString()
                        ,
                        Forenames = rdr["Forenames"].ToString()
                        ,
                        Initials = rdr["Initials"].ToString()
                        ,
                        Title = rdr["Title"].ToString()
                        ,
                        IDNoPP = rdr["IDNoPP"].ToString()
                        ,
                        IDtype = rdr["IDtype"].ToString()
                        ,
                        Nationality = rdr["Nationality"].ToString()
                        ,
                        Gender = rdr["Gender"].ToString()
                        ,
                        Add1 = rdr["Add_1"].ToString()
                        ,
                        Add2 = rdr["Add_2"].ToString()
                        ,
                        Add3 = rdr["Add_3"].ToString()
                        ,
                        Add4 = rdr["Add_4"].ToString()
                        ,
                        Country = rdr["Country"].ToString()
                        ,
                        City = rdr["City"].ToString()
                        ,
                        Tel = rdr["Tel"].ToString()
                        ,
                        Mobile = rdr["Mobile"].ToString()
                        ,
                        Email = rdr["Email"].ToString()
                        ,
                        Category = rdr["Category"].ToString()
                        ,
                        Custodian = rdr["Custodian"].ToString()
                        ,
                        TradingStatus = rdr["TradingStatus"].ToString()
                        ,
                        Industry = rdr["Industry"].ToString()
                        ,
                        Tax = rdr["Tax"].ToString()
                        ,
                        DivBank = rdr["Div_Bank"].ToString()
                        ,
                        DivBranch = rdr["Div_Branch"].ToString()
                        ,
                        DivAccountNo = rdr["Div_AccountNo"].ToString()
                        ,
                        CashBank = rdr["Cash_Bank"].ToString()
                        ,
                        CashBranch = rdr["Cash_Branch"].ToString()
                        ,
                        CashAccountNo = rdr["Cash_AccountNo"].ToString()
                        ,
                        AttachedDocuments = rdr["Attached_Documents"].ToString()
                        ,
                        UpdateType = rdr["Update_Type"].ToString()
                        ,
                        CreatedBy = rdr["Created_By"].ToString()
                        ,
                        AccountState = rdr["AccountState"].ToString()
                        ,
                        Comments = rdr["Comments"].ToString()
                        ,
                        DivPayee = rdr["DivPayee"].ToString()
                        ,
                        SettlementPayee = rdr["SettlementPayee"].ToString()
                        ,
                        Accountclass = rdr["Account_class"].ToString()
                        ,
                        Idnopp2 = rdr["Idnopp2"].ToString()
                        ,
                        Idtype2 = rdr["Idtype2"].ToString()
                        ,
                        ClientImage2 = rdr["Client_Image2"].ToString()
                        ,
                        Documents2 = rdr["Documents2"].ToString()
                        ,
                        Isin = rdr["Isin"].ToString()
                        ,
                        CompanyCode = rdr["Company_Code"].ToString()
                        ,
                        MobileMoney = rdr["Mobile_Money"].ToString()
                        ,
                        MobileNumber = rdr["Mobile_Number"].ToString()
                        ,
                        Sttupdate = rdr["Sttupdate"].ToString()
                        ,
                        Currency = rdr["Currency"].ToString()
                        ,
                        TradingPlatform = rdr["Trading_Platform"].ToString()
                        ,
                        SourceName = rdr["SourceName"].ToString()



                    };


                    account.ClientImage = ClientImages.ToArray();
                    account.Documents = Documents.ToArray();
                    account.BioMatrix = BioMatrices.ToArray();
                    accountsClients.Add(account);


                }
            }

            if (accountsClients.Any())
            {
                return Json(accountsClients, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }

        public JsonResult getClientByName(string name)
        {


            var accountsClients = new List<ClientSearch>();



            var sql = "SELECT [Forenames], [Middlename], [Surname], [CDS_Number] FROM [CDS].[dbo].[Accounts_Clients] ";//" + " where [Forenames] like  " + "'" + name + "'";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();

                //List<string> ClientImages = new List<string>();
                //List<string> BioMatrices = new List<string>();
                //List<string> Documents = new List<string>();

                while (rdr.Read())
                {


                    ClientSearch account = new ClientSearch
                    {


                        CDSNumber = rdr["CDS_Number"].ToString()
                        ,
                        Surname = rdr["Surname"].ToString()
                        ,
                        Middlename = rdr["Middlename"].ToString()
                        ,
                        Forenames = rdr["Forenames"].ToString()




                    };


                    //  AccountClientsWebModel account = new AccountClientsWebModel
                    //{

                    //DateCreated = rdr["Date_Created"].ToString()
                    //,
                    //DOB = rdr["DOB"].ToString()
                    //,
                    //Id = rdr["ID"].ToString()
                    //,
                    //CDSNumber = rdr["CDS_Number"].ToString()
                    //,
                    //BrokerCode = rdr["BrokerCode"].ToString()
                    //,
                    //AccountType = rdr["AccountType"].ToString()
                    //,
                    //Surname = rdr["Surname"].ToString()
                    //,
                    //Middlename = rdr["Middlename"].ToString()
                    //,
                    //      Forenames = rdr["Forenames"].ToString()
                    //,
                    //Initials = rdr["Initials"].ToString()
                    //,
                    //Title = rdr["Title"].ToString()
                    //,
                    //IDNoPP = rdr["IDNoPP"].ToString()
                    //,
                    //IDtype = rdr["IDtype"].ToString()
                    //,
                    //Nationality = rdr["Nationality"].ToString()
                    //,
                    //Gender = rdr["Gender"].ToString()
                    //,
                    //Add1 = rdr["Add_1"].ToString()
                    //,
                    //Add2 = rdr["Add_2"].ToString()
                    //,
                    //Add3 = rdr["Add_3"].ToString()
                    //,
                    //Add4 = rdr["Add_4"].ToString()
                    //,
                    //Country = rdr["Country"].ToString()
                    //,
                    //City = rdr["City"].ToString()
                    //,
                    //Tel = rdr["Tel"].ToString()
                    //,
                    //Mobile = rdr["Mobile"].ToString()
                    //,
                    //Email = rdr["Email"].ToString()
                    //,
                    //Category = rdr["Category"].ToString()
                    //,
                    //Custodian = rdr["Custodian"].ToString()
                    //,
                    //TradingStatus = rdr["TradingStatus"].ToString()
                    //,
                    //Industry = rdr["Industry"].ToString()
                    //,
                    //Tax = rdr["Tax"].ToString()
                    //,
                    //DivBank = rdr["Div_Bank"].ToString()
                    //,
                    //DivBranch = rdr["Div_Branch"].ToString()
                    //,
                    //DivAccountNo = rdr["Div_AccountNo"].ToString()
                    //,
                    //CashBank = rdr["Cash_Bank"].ToString()
                    //,
                    //CashBranch = rdr["Cash_Branch"].ToString()
                    //,
                    //CashAccountNo = rdr["Cash_AccountNo"].ToString()
                    //,
                    //AttachedDocuments = rdr["Attached_Documents"].ToString()
                    //,
                    //UpdateType = rdr["Update_Type"].ToString()
                    //,
                    //CreatedBy = rdr["Created_By"].ToString()
                    //,
                    //AccountState = rdr["AccountState"].ToString()
                    //,
                    //Comments = rdr["Comments"].ToString()
                    //,
                    //DivPayee = rdr["DivPayee"].ToString()
                    //,
                    //SettlementPayee = rdr["SettlementPayee"].ToString()
                    //,
                    //Accountclass = rdr["Account_class"].ToString()
                    //,
                    //Idnopp2 = rdr["Idnopp2"].ToString()
                    //,
                    //Idtype2 = rdr["Idtype2"].ToString()
                    //,
                    //ClientImage2 = rdr["Client_Image2"].ToString()
                    //,
                    //Documents2 = rdr["Documents2"].ToString()
                    //,
                    //Isin = rdr["Isin"].ToString()
                    //,
                    //CompanyCode = rdr["Company_Code"].ToString()
                    //,
                    //MobileMoney = rdr["Mobile_Money"].ToString()
                    //,
                    //MobileNumber = rdr["Mobile_Number"].ToString()
                    //,
                    //Sttupdate = rdr["Sttupdate"].ToString()
                    //,
                    //Currency = rdr["Currency"].ToString()
                    //,
                    //TradingPlatform = rdr["Trading_Platform"].ToString()
                    //,
                    //SourceName = rdr["SourceName"].ToString()



                    //                    };


                    //account.ClientImage = ClientImages.ToArray();
                    //account.Documents = Documents.ToArray();
                    //account.BioMatrix = BioMatrices.ToArray();
                    accountsClients.Add(account);


                }
            }

            if (accountsClients.Any())
            {
                return Json(accountsClients, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }
        
      

        private JsonResult getClientByIDNoPP(string idNoPP)
        {


            var accountsClients = new List<AccountClientsWebModel>();

            var sql = "SELECT * FROM [CDS_ROUTER].[dbo].[Accounts_Clients_Web] " + " where [IDNoPP] =  " + "'" + idNoPP + "'";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
               
                List<string> ClientImages = new List<string>();
                List<string> BioMatrices = new List<string>();
                List<string> Documents = new List<string>();

                while (rdr.Read())
                {



                    AccountClientsWebModel account = new AccountClientsWebModel
                    {

                        DateCreated = rdr["Date_Created"].ToString()
                        ,
                        DOB = rdr["DOB"].ToString()
                        ,
                        Id = rdr["ID"].ToString()
                        ,
                        CDSNumber = rdr["CDS_Number"].ToString()
                        ,
                        BrokerCode = rdr["BrokerCode"].ToString()
                        ,
                        AccountType = rdr["AccountType"].ToString()
                        ,
                        Surname = rdr["Surname"].ToString()
                        ,
                        Middlename = rdr["Middlename"].ToString()
                        ,
                        Forenames = rdr["Forenames"].ToString()
                        ,
                        Initials = rdr["Initials"].ToString()
                        ,
                        Title = rdr["Title"].ToString()
                        ,
                        IDNoPP = rdr["IDNoPP"].ToString()
                        ,
                        IDtype = rdr["IDtype"].ToString()
                        ,
                        Nationality = rdr["Nationality"].ToString()
                        ,
                        Gender = rdr["Gender"].ToString()
                        ,
                        Add1 = rdr["Add_1"].ToString()
                        ,
                        Add2 = rdr["Add_2"].ToString()
                        ,
                        Add3 = rdr["Add_3"].ToString()
                        ,
                        Add4 = rdr["Add_4"].ToString()
                        ,
                        Country = rdr["Country"].ToString()
                        ,
                        City = rdr["City"].ToString()
                        ,
                        Tel = rdr["Tel"].ToString()
                        ,
                        Mobile = rdr["Mobile"].ToString()
                        ,
                        Email = rdr["Email"].ToString()
                        ,
                        Category = rdr["Category"].ToString()
                        ,
                        Custodian = rdr["Custodian"].ToString()
                        ,
                        TradingStatus = rdr["TradingStatus"].ToString()
                        ,
                        Industry = rdr["Industry"].ToString()
                        ,
                        Tax = rdr["Tax"].ToString()
                        ,
                        DivBank = rdr["Div_Bank"].ToString()
                        ,
                        DivBranch = rdr["Div_Branch"].ToString()
                        ,
                        DivAccountNo = rdr["Div_AccountNo"].ToString()
                        ,
                        CashBank = rdr["Cash_Bank"].ToString()
                        ,
                        CashBranch = rdr["Cash_Branch"].ToString()
                        ,
                        CashAccountNo = rdr["Cash_AccountNo"].ToString()
                        ,
                        AttachedDocuments = rdr["Attached_Documents"].ToString()
                        ,
                        UpdateType = rdr["Update_Type"].ToString()
                        ,
                        CreatedBy = rdr["Created_By"].ToString()
                        ,
                        AccountState = rdr["AccountState"].ToString()
                        ,
                        Comments = rdr["Comments"].ToString()
                        ,
                        DivPayee = rdr["DivPayee"].ToString()
                        ,
                        SettlementPayee = rdr["SettlementPayee"].ToString()
                        ,
                        Accountclass = rdr["Account_class"].ToString()
                        ,
                        Idnopp2 = rdr["Idnopp2"].ToString()
                        ,
                        Idtype2 = rdr["Idtype2"].ToString()
                        ,
                        ClientImage2 = rdr["Client_Image2"].ToString()
                        ,
                        Documents2 = rdr["Documents2"].ToString()
                        ,
                        Isin = rdr["Isin"].ToString()
                        ,
                        CompanyCode = rdr["Company_Code"].ToString()
                        ,
                        MobileMoney = rdr["Mobile_Money"].ToString()
                        ,
                        MobileNumber = rdr["Mobile_Number"].ToString()
                        ,
                        Sttupdate = rdr["Sttupdate"].ToString()
                        ,
                        Currency = rdr["Currency"].ToString()
                        ,
                        TradingPlatform = rdr["Trading_Platform"].ToString()
                        ,
                        SourceName = rdr["SourceName"].ToString()



                    };


                    account.ClientImage = ClientImages.ToArray();
                    account.Documents = Documents.ToArray();
                    account.BioMatrix = BioMatrices.ToArray();
                    accountsClients.Add(account);


                }
            }

            if (accountsClients.Any())
            {
                return Json(accountsClients, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }

        public JsonResult getClientByCdsNumber(string cds_number)
        {


            var accountsClients = new List<ClientSearch>();

         

            var sql = "SELECT [CDS_Number], [Forenames], [Middlename], [Surname]  FROM [CDS].[dbo].[Accounts_Clients] ";// + " where [CDS_Number] like  " + "'" + cds_number + "'";

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
             
                List<string> ClientImages = new List<string>();
                List<string> BioMatrices = new List<string>();
                List<string> Documents = new List<string>();

                while (rdr.Read())
                {



                    ClientSearch account = new ClientSearch
                    {

                      
                        CDSNumber = rdr["CDS_Number"].ToString()
                        ,
                        Surname = rdr["Surname"].ToString()
                        ,
                        Middlename = rdr["Middlename"].ToString()
                        ,
                        Forenames = rdr["Forenames"].ToString()
                      



                    };


                    //account.ClientImage = ClientImages.ToArray();
                    //account.Documents = Documents.ToArray();
                    //account.BioMatrix = BioMatrices.ToArray();
                    accountsClients.Add(account);


                }
            }

            if (accountsClients.Any())
            {
                return Json(accountsClients, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }

        public String saveClient(AccountClientsWebModel account)
        {

    
            var sql = @"INSERT INTO [CDS_Router].[dbo].[Accounts_Clients_Web]
                               ([Date_Created] , [DOB], [ID], [CDS_Number], [BrokerCode], AccountType, [Surname], [Middlename], [Forenames], [Initials], [Title], [IDNoPP]
                                ,[IDtype], [Nationality], [Gender], [Add_1], [Add_2], [Add_3], [Add_4], [Country], [City], [Tel], [Mobile], [Email], [Category], [Custodian], [TradingStatus]
                                ,[Industry], [Tax] ,[Div_Bank], [Div_Branch], [Div_AccountNo], [Cash_Bank], [Cash_Branch], [Cash_AccountNo], [Attached_Documents], [Update_Type]
                                ,[Created_By], [AccountState], [Comments], [DivPayee], [SettlementPayee], [Account_class], [Idnopp2], [Idtype2], [Client_Image2], [Documents2]
                                ,[Isin], [Company_Code], [Mobile_Money], [Mobile_Number], [Sttupdate], [Currency], [Trading_Platform], [SourceName]
                            )
                         VALUES
                               ('" + account.DateCreated + @"' , '" + account.DOB.Trim() + @"' , '" + account.Id.Trim() + @"' , '" +account.CDSNumber.Trim() + @"' , '" + account.BrokerCode.Trim() + @"' 
                            , '" + account.AccountType.Trim() + @"', '" + account.Surname.Trim() + @"', '" + account.Middlename.Trim() + @"', '" + account.Forenames.Trim() + @"'
                            , '" + account.Initials.Trim() + @"', '" + account.Title.Trim() + @"', '" + account.IDNoPP.Trim() + @"', '" + account.IDtype.Trim() + @"'
                            , '" + account.Nationality.Trim() + @"', '" + account.Gender.Trim() + @"', '" + account.Add1.Trim() + @"', '" + account.Add2.Trim() + @"'
                            , '" + account.Add3.Trim() + @"', '" + account.Add4.Trim() + @"', '" + account.Country.Trim() + @"', '" + account.City.Trim() + @"'
                            , '" + account.Tel.Trim() + @"', '" + account.Mobile.Trim() + @"', '" + account.Email.Trim() + @"', '" + account.Category.Trim() + @"'
                            , '" + account.Custodian.Trim() + @"', '" + account.TradingStatus.Trim() + @"', '" + account.Industry.Trim() + @"', '" + account.Tax.Trim() + @"'
                            , '" + account.DivBank.Trim() + @"', '" + account.DivBranch.Trim() + @"', '" + account.DivAccountNo.Trim() + @"', '" + account.CashBank.Trim() + @"'
                            , '" + account.CashBranch.Trim() + @"', '" + account.CashAccountNo.Trim() + @"', '" + account.AttachedDocuments.Trim() + @"', '" + account.UpdateType.Trim() + @"'
                            , '" + account.CreatedBy.Trim() + @"', '" + account.AccountState.Trim() + @"', '" + account.Comments.Trim() + @"', '" + account.DivPayee.Trim() + @"', '" + account.SettlementPayee.Trim() + @"'
                            , '" + account.Accountclass.Trim() + @"', '" + account.Idnopp2.Trim() + @"', '" + account.Idtype2.Trim() + @"', '" + account.ClientImage2.Trim() + @"'
                            , '" + account.Documents2.Trim() + @"' ,'" + account.Isin.Trim() + @"', '" + account.CompanyCode.Trim() + @"', '" + account.MobileMoney.Trim() + @"'
                            , '" + account.MobileNumber.Trim() + @"',  '" + account.Sttupdate.Trim() + @"',  '" + account.Currency.Trim() + @"',  '" + account.TradingPlatform.Trim() + @"'
                            , '" + account.SourceName.Trim() + @"') ";

        



            try
            {
                using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                    return "{ \"status\":\"true\",\"massage\":\"Account successfully saved\"}";


                }

            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }

        public string saveVatenkesi(VatenkesisModel vatenkes)
        {

          

            var sql = @"INSERT INTO [CDSC].[dbo].[vatenkecis]
                                ([PhoneNumber] 
                                ,[Email]
                                ,[Username]
                                ,[CdsNumber]
                                ,[Password]
                                ,[Active]
                                ,[Date]
                                ,[Comp_authorizer]
                                ,[Comp_initiator]
                                )
                         VALUES
                               ('" + vatenkes.PhoneNumber + @"' 
                                ,'" + vatenkes.Email.Trim() + @"' 
                                ,'" + vatenkes.Username.Trim() + @"'   
                                ,'" + vatenkes.CdsNumber.Trim() + @"' 
                                ,'" + vatenkes.Password.Trim() + @"' 
                                ,'" + vatenkes.Active + @"'
                                ,GETDATE()
                                ,'" + vatenkes.Comp_authorizer.Trim() + @"'
                                ,'" + vatenkes.Comp_initiator.Trim() + @"') ";





            try
            {
                using (SqlConnection connection = new SqlConnection(connectionStringCDSC))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                    return "{ \"status\":\"true\",\"massage\":\"Vatenkesis successfully saved\"}";


                }

            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }

        public JsonResult getCredentialsByEmail(string email)
        {


            var vatenkesis = new List<VatenkesisModel>();

          
           var sql = " SELECT * FROM[CDSC].[dbo].[vatenkecis] where[email] = " + " '"+email+"' ";
      

            using (SqlConnection connection = new SqlConnection(connectionStringCDSC)) //todo
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();



                while (rdr.Read())
                {
    
                    VatenkesisModel vatenkecis = new VatenkesisModel
                    {

                            Id = long.Parse(rdr["Id"].ToString()),

                            PhoneNumber = rdr["PhoneNumber"].ToString()
                                        ,
                            Email = rdr["Email"].ToString()
                                        ,
                            Username = rdr["Username"].ToString()
                                        ,
                            CdsNumber = rdr["CDSNumber"].ToString()
                                        ,
                            Password = rdr["Password"].ToString()
                                        ,
                            Active = rdr["Active"].ToString()
                                        ,
                            Date = rdr["Date"].ToString()
                                        ,
                            PIN = rdr["PIN"].ToString()
                                        ,
                            EmailSend = rdr["EmailSend"].ToString()
                                        ,
                            FullName = rdr["FullName"].ToString()
                                        ,
                            Comp_authorizer = rdr["Comp_authorizer"].ToString()
                                        ,
                            Comp_initiator = rdr["Comp_initiator"].ToString()
                                      
                         
                            

            };
               
                    vatenkesis.Add(vatenkecis);


                }
            }

            if (vatenkesis.Any())
            {
                return Json(vatenkesis, JsonRequestBehavior.AllowGet);
            }
            return Json("No data was found", JsonRequestBehavior.AllowGet);
            //            var thePrices = "atsDbContext.;";
            //            return Json(thePrices, JsonRequestBehavior.AllowGet);
        }

        public ResponseModel CreateNaymatAccount(RegistrationModel registration)
        {
            AccountClientsWebModel AccountClient = registration.AccountClient;

            JsonResult json = new JsonResult();
            json = getClientByEmail(AccountClient.Email);

            if (json.MaxJsonLength > 0) {
                return new ResponseModel(false, "The Supplied Email Already Exists" );
            }

            json = new JsonResult();
            json = getClientByIDNoPP(AccountClient.IDNoPP);

            if (json.MaxJsonLength > 0)
            {
                return new ResponseModel(  false, "The Supplied ID Already Exists" );
            }

            AccountClient.Sttupdate = "1";
            string password = encrypt( registration.Password);


            if (AccountClient.AccountType.ToLower().Equals("i"))
                AccountClient.IDtype = "NID";
            else AccountClient.IDtype = "CORP";

            AccountClient.MobileNumber = AccountClient.MobileNumber;
            AccountClient.SourceName = AccountClient.CreatedBy;
            AccountClient.UpdateType = "NEW";
            AccountClient.AccountState = "PENDING";
            AccountClient.TradingStatus = "DEALING ALLOWED";
            AccountClient.Category = "C";
            AccountClient.CDSNumber = "9098";
            AccountClient.DateCreated = DateTime.Today.ToString();
            AccountClient.Middlename = "";

            saveClient(AccountClient); //todo insert query

            json = new JsonResult();
            json = getClientByEmail(AccountClient.Email);

            AccountClientsWebModel savedClient = Newtonsoft.Json.JsonConvert.DeserializeObject<AccountClientsWebModel>(json.ToString());


            String newCDSNumber = savedClient.CDSNumber;

            if (json.MaxJsonLength > 0)
            {
                if (savedClient.AccountType.Equals("i"))
                {


                    if (saveLoginCredentials( savedClient.MobileNumber, savedClient.Email, newCDSNumber, password, null, null))
                    {
                        return new ResponseModel(true, "Account Has Been Created Successfully");
                    }
                    else
                    {
                        return new ResponseModel(false, "Account Has Been Created Successfully.But Failed To Sit Correctly Please Contact CTrade Team For Assistance ");
                    }
                        

                }
                else if (savedClient.AccountType.Equals("c"))
                {
                    List<RepresentativeModel> representatives = registration.Representatives;
                    int repSuccessCount = 0;
                    int repFailCount = 0;

                    if (saveLoginCredentials(savedClient.MobileNumber, savedClient.Email, newCDSNumber,  encrypt(password), null, null))
                    {
                        if (representatives != null)
                        {
                           
                           
                          foreach (RepresentativeModel representative in representatives)
                            {
                                
                                String repPassword = encrypt(representative.Password);
                                String auth = representative.Authoriser ? "YES" : "NO";
                                String init = representative.Initiator ? "YES" : "NO";
                                representative.Password = repPassword;

                                JsonResult emailCheckerV = getCredentialsByEmail(representative.Email);

                                if (emailCheckerV == null || emailCheckerV.MaxJsonLength<=0) 
                                {
                                    if (saveLoginCredentials(representative.Mobile, representative.Email, newCDSNumber, repPassword, auth, init))
                                    {
                                        repSuccessCount += 1;
                                    }
                                    else
                                    {
                                        repFailCount += 1;
                                    }
                                }
                                else
                                {
                                    repFailCount += 1;
                                }
                            }
                        }
                        String message = String.Format("A Corporate Account With %s Representative(s) Has Been Created Successfully", repSuccessCount);
                        if (repFailCount > 0)
                        {
                            message = String.Format("A Corporate Account With %s Representative(s) " +
                         "Has Been Created Successfully. %s Failed Because Their Email Already Existed On CTrade", repSuccessCount, repFailCount);

                        }

                        return new ResponseModel(true, message, newCDSNumber);
                    }
                    else
                    {
                        return new ResponseModel(true, "Failed To Create The Corporate Account Please Contact The CTrade Team");
                    }
                }
            }
            return new ResponseModel(false, "Failed To Create Account Please Try Again Later");




        }

        public bool saveLoginCredentials(string phone, string email, string cdsnumber, string password, string authorizer, string initiator)
        {
            VatenkesisModel vatenkecis = new VatenkesisModel
            {
                Active = false.ToString(),
                CdsNumber = cdsnumber,
                Username = email,
                Email = email,
                Comp_authorizer = authorizer,
                Comp_initiator = initiator,
                Password = password,
                PhoneNumber = phone
            };

            writetofile("phon----" + vatenkecis.PhoneNumber + "    " );
            writetofile("cds----" + vatenkecis.CdsNumber + "    ");
            writetofile("email----" + vatenkecis.Email + "    ");
            writetofile("auth----" + vatenkecis.Comp_authorizer + "    ");
            writetofile("init----" + vatenkecis.Comp_initiator + "    ");
            writetofile("password----" + vatenkecis.Password + "    ");
            writetofile("active----" + vatenkecis.Active + "    ");






            //LOGGER.info("Generated Cds Number: {}", cdsnumber);
            saveVatenkesi(vatenkecis);

            JsonResult json = getCredentialsByEmail(vatenkecis.Email); //todo get vatenkes from json result


            VatenkesisModel saved = Newtonsoft.Json.JsonConvert.DeserializeObject<VatenkesisModel>(json.ToString());

            if (saved == null) return false;
            return true;
        }

        private string encrypt(String s)
        {
            String e = "";
            if (s != null)
            {
                for (int i = 0; i < s.Length; i++)
                {
                    int ascii1 = s.ElementAt(i);
                    int ascii2 = ascii1 - 10;
                    char char1 = (char)ascii2;
                    String char2 = char1.ToString();
                    e = e + char2;
                }
            }
            return e;
        }

        public ResponseModel updateProfile(ProfileModel profile)
        {

           JsonResult json = getClientByCdsNumber(profile.CDSNumber);

            if (json.MaxJsonLength <=0)
            {
                return new ResponseModel(false, "Failed To Validate Your CDS Number Please Try Again.");
            }

            //todo from json
       

            AccountClientsWebModel account = Newtonsoft.Json.JsonConvert.DeserializeObject<AccountClientsWebModel>(json.ToString());
            
            if (profile.Type == 1)
            {
         
                account.Mobile = profile.Mobile;
                account.Mobile = profile.Mobile;
                account.Add1 = profile.Address;

                if (!profile.Email.Equals(account.Email))
                {
                    if (getClientByEmail(profile.Email) != null)
                    {
                        return new ResponseModel(false, "Could Not Proceed With The Update Since The Email Supplied Is Already Registered To Another Account.");
                    }
                    account.Email = profile.Email;

                    json = getCredentialsByEmail(account.Email); //todo get vatenkes from json result

                    VatenkesisModel vatenkecis = Newtonsoft.Json.JsonConvert.DeserializeObject<VatenkesisModel>(json.ToString());


                    if (vatenkecis != null)
                    {
                        vatenkecis.Email = profile.Email;
                        saveVatenkesi(vatenkecis);
                    }
                }
            }
            else if (profile.Type == 2)
            {
                account.CashBank = profile.BankName;
                account.CashBranch = profile.Branch;
                account.CashAccountNo = profile.BankAccountNumber;
            }
            saveClient(account);
            return new ResponseModel(true, "Your Profile Has Been Updated Successfully");
        }


        /************************************Session*************************************************************/

        public JsonResult getSessionNo(string cdsNumber)
        {
            

            var sql = "SELECT [CDS_Number] FROM [CDS_ROUTER].[dbo].[monitor] " +
                " where [CDS_Number] =  " + "'" + cdsNumber + "'";

            string cds_number = "";
            int loanId=0;

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                
                while (rdr.Read())
                {
                   
                    cds_number = rdr["CDS_Number"].ToString();
                 
                }
            }

            if (cds_number != "")
            {
                return Json(cds_number, JsonRequestBehavior.AllowGet);
            }
            return Json(loanId, JsonRequestBehavior.AllowGet);
         
        }

        public JsonResult getTokenNo(string cdsNumber)
        {


            var sql = "SELECT [session_token] FROM [CDS_ROUTER].[dbo].[monitor] " +
                " where [CDS_Number] =  " + "'" + cdsNumber + "'";

            string session_token = "";
            int loanId = 0;

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {

                    session_token = rdr["session_token"].ToString();

                }
            }

            if (session_token != "")
            {
                return Json(session_token, JsonRequestBehavior.AllowGet);
            }
            return Json(loanId, JsonRequestBehavior.AllowGet);

        }

        public JsonResult getStatus(string cdsNumber)
        {


            var sql = "SELECT [status] FROM [CDS_ROUTER].[dbo].[monitor] " +
                " where [CDS_Number] =  " + "'" + cdsNumber + "'";

            string status = "";
            int loanId = 0;

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.Text;
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {

                    status = rdr["status"].ToString();

                }
            }

            if (status != "")
            {
                return Json(status, JsonRequestBehavior.AllowGet);
            }
            return Json(loanId, JsonRequestBehavior.AllowGet);

        }

        public void updateSessionNo(string cdsNumber, string generatedToken)
        {
            string sql = "Update [CDS_ROUTER].[dbo].[monitor] set session_token='" + generatedToken + "' where cds_number='" + cdsNumber + "'";
            var updt = _cdscDbContext.Database.ExecuteSqlCommand(sql);

            if(Json(updt, JsonRequestBehavior.AllowGet).Equals(""))
            {
                //todo die in php
            }

         

        }

        public void updateStatus(string cdsNumber, string status)
        {
            string sql = "Update [CDS_ROUTER].[dbo].[monitor] set status='" + status + "' where cds_number='" + cdsNumber + "'";
            var updt = _cdscDbContext.Database.ExecuteSqlCommand(sql);

            if (Json(updt, JsonRequestBehavior.AllowGet).Equals(""))
            {
                //todo die in php
            }



        }


        //public JsonResult getData(string cdsNumber, string oldToken, string tokenNumber, string generatedToken, string status)
        //{



        //    if ( oldToken != tokenNumber && !tokenNumber.Equals("") && tokenNumber != null && !cdsNumber.Equals("") && cdsNumber != null ) {


        //        updateStatus(cdsNumber, "false");

        //        return "{ \"statu\" :status , \"message\" : \"session still running\", \"key]\" : generatedToken }";

        //    }
        //    else {

        //        updateStatus(cdsNumber, "true");
        //        return "{ \"statu\" :status , \"message\" : \"session created\", \"key]\" : generatedToken }";
        //    }



        //    if (status != "")
        //    {
              
        //    }
        //    return Json(loanId, JsonRequestBehavior.AllowGet);

        //}

        /************************************Session*************************************************************/




        /************************************CHANDALALA TINASHE*************************************************************/

        public Boolean Desolvemember(string member_cdsNumber, string club_cdsnumber)
        {

            string req_params = "declare @member_cdsnumber nvarchar(50)='" + member_cdsNumber + "';declare @group_cdsnumber nvarchar(50)='" + club_cdsnumber + "';";
            string full_query = "INSERT into cds_router.dbo.trans (company, cds_number, date_created, trans_time, shares, update_type, created_by, batch_ref, [source], pledge_shares, reference, instrument, [broker], custodian) select company, cds_number, getdate(), getdate(), floor(isnull(sum(shares),0)), 'Group Exit','INVC','0','D',NULL,@group_cdsnumber, NULL, NULL, NULL from cds_router.dbo.trans_groups where cds_number=@member_cdsnumber and groupid=@group_cdsnumber group by cds_number, company INSERT into cds_router.dbo.trans (company, cds_number, date_created, trans_time, shares, update_type, created_by, batch_ref, [source], pledge_shares, reference, instrument, [broker], custodian) select company, @group_cdsnumber, getdate(), getdate(), floor(isnull(sum(shares),0))*-1, 'Group Exit','INVC','0','D',NULL,@member_cdsnumber, NULL, NULL, NULL from cds_router.dbo.trans_groups where cds_number=@member_cdsnumber and groupid=@group_cdsnumber group by cds_number, company INSERT into cds_router.dbo.trans_groups (company, cds_number, date_created, trans_time, shares, update_type, created_by, batch_ref, [source], pledge_shares, reference, instrument, [broker], groupid) select company, cds_number, getdate(), getdate(), floor(isnull(sum(shares),0))*-1, 'Group Exit','INVC','0','D',NULL, NULL, NULL, NULL,@group_cdsnumber from cds_router.dbo.trans_groups where cds_number=@member_cdsnumber and groupid=@group_cdsnumber group by cds_number, company insert into cdsc.dbo.CashTrans ([description], transtype, amount, datecreated, transstatus, cds_number, paid, reference) select 'Group Exit', 'Group Exit', sum(amount), getdate(), '1', cds_number,'1', @group_cdsnumber from cdsc.dbo.CashTransgroups where cds_number=@member_cdsnumber and cds_numbergroup=@group_cdsnumber GROUP BY cds_number insert into cdsc.dbo.CashTrans ([description], transtype, amount, datecreated, transstatus, cds_number, paid, reference) select 'Group Exit', 'Group Exit', sum(amount)*-1, getdate(), '1', @group_cdsnumber ,'1', @member_cdsnumber from cdsc.dbo.CashTransgroups where cds_number=@member_cdsnumber and cds_numbergroup=@group_cdsnumber GROUP BY cds_number insert into cdsc.dbo.CashTransgroups ([description], transtype, amount, datecreated, transstatus, cds_number, cds_numbergroup) select 'Group Exit', 'Group Exit', sum(amount)*-1, getdate(), '1', cds_number, @group_cdsnumber from cdsc.dbo.CashTransgroups where cds_number=@member_cdsnumber and cds_numbergroup=@group_cdsnumber GROUP BY cds_number";

            var sql = @"" + req_params + full_query + "";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                    return true;


                }

            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public String SubscribersInsert(string username = null, string email = null, string password = null,
          string phone = null, string cdsnumber = null, string fullname = null, string comp_authorizer = null, string comp_initiator = null, string isCompany = null)
        {
            string newcds = "";

            int activate = 1;
            if (isCompany == "c")
            {
                activate = 0;
            }

            try
            {

                var cds = _cdDataContext.Accounts_Clients_Web.ToList().Where(a => a.Email.ToLower() == email.ToLower()).FirstOrDefault();
                newcds = cds.CDS_Number;

            }
            catch (Exception)
            {


            }
            if (newcds == "")
            {
                newcds = cdsnumber;
            }
            var sql = "INSERT INTO [CDSC].[dbo].[Vatenkecis] ([Username],[Email],[Password],[PhoneNumber],[CdsNumber],[Active],[Date],[EmailSend],[FullName],[comp_authorizer],[comp_initiator]) VALUES (@username,@email,@password,@phone,@cdsnumber,@activate,GETDATE(),0,@fullname,@comp_authorizer,@comp_initiator)";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionStringATS))
                {

                    string encryptedPassword = EncryptIt(password.Trim());

                    SqlCommand cmd = new SqlCommand(sql, connection)
                    {
                        CommandType = CommandType.Text
                    };
                    cmd.Parameters.AddWithValue("@username", username.Trim());
                    cmd.Parameters.AddWithValue("@email", email.Trim());
                    cmd.Parameters.AddWithValue("@password", encryptedPassword);
                    cmd.Parameters.AddWithValue("@phone", phone.Trim());
                    cmd.Parameters.AddWithValue("@cdsnumber", newcds);
                    cmd.Parameters.AddWithValue("@activate", activate);
                    cmd.Parameters.AddWithValue("@fullname", fullname.Trim());
                    cmd.Parameters.AddWithValue("@comp_authorizer", comp_authorizer.Trim());
                    cmd.Parameters.AddWithValue("@comp_initiator", comp_initiator.Trim());
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();

                    try
                    {
                        investmentclubs(email, cdsnumber);
                    }
                    catch (Exception)
                    {

                    }
                    return "1";


                }

            }
            catch (Exception ex)
            {
                return "0" + sql + ex;
            }

        }


        public String insertAlerts(string company = null, string cds_number = null, string price = null)
        {

            var today = DateTime.Today.ToString();

            var sql = @"INSERT INTO [CDS_ROUTER].[dbo].[Alerts]
                               ([company]
                               ,[cds_number]
                               ,[price]
                               ,[sent]
                               ,[active]
                               ,[update_on])
                         VALUES
                               ('" + company.Trim() + @"'
                               ,'" + cds_number.Trim() + @"'
                               ,'" + price.Trim() + @"'
                               ,0
                                ,0
                               ,'" + today + @"') ";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionStringATS))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();

                    return "Alert request submitted successfully";


                }

            }
            catch (Exception ex)
            {
                return "Error loading data" + sql + ex;
            }

        }

        public void UpdateCdsNO(string email, string cds)
        {

            string sql = "Update [CDSC].[dbo].[Vatenkecis] set cdsnumber='" + cds + "' where member_email='" + email + "'";
            var updt = _cdscDbContext.Database.ExecuteSqlCommand(sql);

        }

        public void investmentclubs(string email, string cds)
        {

            string sql = "Update club_members set cdsnumber='" + cds + "' where member_email='" + email + "'";
            var updt = _cdscDbContext.Database.ExecuteSqlCommand(sql);

        }

        public String executeDemat(string cds_number = null, string certificate_number = null, string shares = null, string company = null)
        {
            var sql = @"INSERT INTO [CDS_ROUTER].[dbo].[batch_certs]
                               ([batch_no],
                                [cds_number]
                               ,[certificate_no]
                               ,[shares]
                               ,[company])
                         VALUES
                               ('1'
                               ,'" + cds_number.Trim() + @"'
                               ,'" + certificate_number.Trim() + @"'
                               ,'" + shares.Trim() + @"'
                               ,'" + company.Trim() + @"') ";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionStringATS))
                {


                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                    return "Request has been received. You will be notified after processing.";


                }

            }
            catch (Exception ex)
            {
                return "Error loading data" + sql + ex;
            }

        }

        // club methods
        public JsonResult CreateClub(string chairmain, int clubnumber, string clubname, string clubphone, string phone)
        {
            string result = "";
            try
            {
                //            var cdDataContext = new CdDataContext();
                investment_club investment_Club = new investment_club();
                investment_Club.chairman_id = chairmain;
                investment_Club.club_member_num = clubnumber.ToString();
                investment_Club.club_name = clubname;
                investment_Club.club_phone = clubphone;
                investment_Club.created_date = DateTime.Now;
                investment_Club.phone = phone;
                investment_Club.Active = true;
                _cdscDbContext.investment_club.Add(investment_Club);
                _cdscDbContext.SaveChanges();
                result = "Club successfully created";

            }
            catch (Exception)
            {

                result = "Club not successfully created";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public JsonResult CreateClubID(string chairmain, int clubnumber, string clubname, string clubphone, string phone)
        {
            string result = "Blue";

            string ran = RandomNumber(100000, 90000000).ToString() + "/" + RandomNumber(1000, 90000).ToString() + RandomString(4, true);
            try
            {
                // var cdDataContext = new CdDataContext();
                investment_club investment_Club = new investment_club();
                investment_Club.chairman_id = chairmain;
                investment_Club.club_member_num = clubnumber.ToString();
                investment_Club.club_name = clubname;
                investment_Club.club_phone = clubphone;
                investment_Club.created_date = DateTime.Now;
                investment_Club.phone = phone;
                investment_Club.Active = true;
                investment_Club.club_cds_number = ran;

                _cdscDbContext.investment_club.Add(investment_Club);
                _cdscDbContext.SaveChanges();
                var max = _cdscDbContext.investment_club.ToList().Max(a => a.id);
                var result2 = max.ToString();



                return Json(result2, JsonRequestBehavior.AllowGet);



            }
            catch (Exception f)
            {

                return Json(f.Message, JsonRequestBehavior.AllowGet);
            }

            return Json("blue", JsonRequestBehavior.AllowGet);
        }
        public JsonResult newInvestmentClub(string chairmain, int clubnumber, string clubname, string clubphone, string phone, string email)
        {
            string result = "Successully Created";

            string ran = RandomNumber(100000, 90000000).ToString() + "/" + RandomNumber(1000, 90000).ToString() + RandomString(4, true);
            try
            {
                // var cdDataContext = new CdDataContext();
                investment_club investment_Club = new investment_club();
                investment_Club.chairman_id = chairmain;
                investment_Club.club_member_num = clubnumber.ToString();
                investment_Club.club_name = clubname;
                investment_Club.club_phone = clubphone;
                investment_Club.created_date = DateTime.Now;
                investment_Club.phone = phone;
                investment_Club.Active = true;
                investment_Club.club_cds_number = ran;

                _cdscDbContext.investment_club.Add(investment_Club);
                _cdscDbContext.SaveChanges();
                var max = _cdscDbContext.investment_club.ToList().Max(a => a.id);
                var result2 = max.ToString();

                if (investmentClubsClient(clubname, clubphone, ran, email))
                {
                    newMemberAddAdmin(clubphone, ran, clubphone, email, "", "", clubnumber.ToString());
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
                var result3 = "Failed To Create Club";
                return Json(result3, JsonRequestBehavior.AllowGet);

            }
            catch (Exception f)
            {

                return Json(f.Message, JsonRequestBehavior.AllowGet);
            }

            //return Json("blue", JsonRequestBehavior.AllowGet);
        }
        public string RandomString(int size, bool lowerCase)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (lowerCase)
                return builder.ToString().ToLower();
            return builder.ToString();
        }

        public int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }
        public JsonResult EditClub(string chairmain, int clubnumber, string clubname, string clubphone, string phone, int clubid)
        {
            string result = "";
            try
            {
                //            var cdDataContext = new CdDataContext();
                investment_club investment_Club = _cdscDbContext.investment_club.Find(clubid);
                investment_Club.chairman_id = chairmain;
                investment_Club.club_member_num = clubnumber.ToString();
                investment_Club.club_name = clubname;
                investment_Club.club_phone = clubphone;
                investment_Club.created_date = DateTime.Now;
                investment_Club.phone = phone;
                investment_Club.Active = true;
                _cdscDbContext.investment_club.AddOrUpdate(investment_Club);
                _cdscDbContext.SaveChanges();
                result = "Club successfully updated";

            }
            catch (Exception)
            {

                result = "Club not successfully updated";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult RemoveClub(int clubid)
        {
            string result = "";
            try
            {
                //            var cdDataContext = new CdDataContext();
                investment_club investment_Club = _cdscDbContext.investment_club.Find(clubid);

                investment_Club.Active = false;
                _cdscDbContext.investment_club.AddOrUpdate(investment_Club);
                _cdscDbContext.SaveChanges();
                result = "Club successfully removed";

            }
            catch (Exception)
            {

                result = "Club removed";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Clublist(string cdsno)
        {
            string result = "";
            List<investment_club> clublist = (from s in _cdscDbContext.investment_club
                                              where s.chairman_id == cdsno && s.Active == true
                                              select s).ToList();

            //return Json(clublist, JsonRequestBehavior.AllowGet);
            return new CustomJsonResult { Data = new { clublist } };
        }
        public JsonResult ClublistMember(string cdsno)
        {
            string result = "";
            var clublist = (from s in _cdscDbContext.club_members
                            join v in _cdscDbContext.investment_club on s.club_id equals v.id
                            let ClubName = v.club_name
                            let Clubid = v.id
                            where s.cdsnumber == cdsno
                            select new { ClubName, Clubid }).ToList();


            return new CustomJsonResult { Data = new { clublist } };
        }
        public JsonResult ClublistById(int id)
        {
            string result = "";
            List<investment_club> clublist = (from s in _cdscDbContext.investment_club
                                              where s.id == id
                                              select s).ToList();

            //return Json(clublist, JsonRequestBehavior.AllowGet);
            return new CustomJsonResult { Data = new { clublist } };
        }
        public JsonResult ClublistMembers(int clubid)
        {
            string result = "";
            List<club_members> clublist = (from s in _cdscDbContext.club_members where s.club_id == clubid && s.Active == true && s.rejected == false select s).ToList();
            //return Json(clublist, JsonRequestBehavior.AllowGet);
            return new CustomJsonResult { Data = new { clublist } };
        }

        private Boolean validatemember()
        {

            return true;
        }
        //membermethods

        public JsonResult ClubMemberAdd(string clubphone, string clubcds, string phone, string email, string surname, string firstname, string club_id)
        {

            string result = "Member successfully added";
            try
            {

                club_members club_Members = new club_members();
                club_Members.club_phone = clubphone;
                club_Members.member_cds_number = Returnmember(email);
                club_Members.member_phone = phone;
                club_Members.member_email = email;
                club_Members.club_id = Convert.ToInt32(club_id);
                club_Members.confirmed = false;
                club_Members.rejected = false;
                club_Members.created_date = DateTime.Now;
                club_Members.Surname = surname;
                club_Members.Firstname = firstname;
                club_Members.Active = true;
                club_Members.cdsnumber = clubcds;
                _cdscDbContext.club_members.Add(club_Members);
                _cdscDbContext.SaveChanges();

                var mynames = _cdscDbContext.investment_club.ToList().Where(a => a.id == club_Members.club_id).FirstOrDefault();
                //send invite
                //var sent=SendSms("you have been invited to join C-Trade Investment Club " + mynames.club_name + " download Ctrade App https://play.google.com/store/apps/details?id=zw.co.escrow.ctradelive&hl=en or dial *727# to view More", phone);
            }
            catch (Exception f)
            {

                result = f.Message;
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public JsonResult newMemberAdd(string clubphone, string clubcds, string phone, string email, string surname, string firstname, string club_id)
        {
            if (Returnmember(email) == "") return Json("Email Does Not Exist", JsonRequestBehavior.AllowGet);
            string result = "Member successfully added";
            try
            {

                club_members club_Members = new club_members();
                club_Members.club_phone = clubphone;
                club_Members.member_cds_number = Returnmember(email);
                club_Members.member_phone = phone;
                club_Members.member_email = email;
                club_Members.club_id = Convert.ToInt32(club_id);
                club_Members.confirmed = false;
                club_Members.rejected = false;
                club_Members.created_date = DateTime.Now;
                club_Members.Surname = surname;
                club_Members.Firstname = firstname;
                club_Members.Active = true;
                club_Members.cdsnumber = clubcds;
                _cdscDbContext.club_members.Add(club_Members);
                _cdscDbContext.SaveChanges();

                var mynames = _cdscDbContext.investment_club.ToList().Where(a => a.id == club_Members.club_id).FirstOrDefault();
                //send invite
                //var sent=SendSms("you have been invited to join C-Trade Investment Club " + mynames.club_name + " download Ctrade App https://play.google.com/store/apps/details?id=zw.co.escrow.ctradelive&hl=en or dial *727# to view More", phone);
            }
            catch (Exception f)
            {

                result = f.Message;
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public JsonResult newMemberAddAdmin(string clubphone, string clubcds, string phone, string email, string surname, string firstname, string club_id)
        {
            if (Returnmember(email) == "") return Json("Email Does Not Exist", JsonRequestBehavior.AllowGet);
            string result = "Member successfully added";
            try
            {

                club_members club_Members = new club_members();
                club_Members.club_phone = clubphone;
                club_Members.member_cds_number = Returnmember(email);
                club_Members.member_phone = phone;
                club_Members.member_email = email;
                club_Members.club_id = 0;
                club_Members.confirmed = true;
                club_Members.rejected = false;
                club_Members.created_date = DateTime.Now;
                club_Members.Surname = surname;
                club_Members.Firstname = firstname;
                club_Members.Active = true;
                club_Members.cdsnumber = clubcds;
                _cdscDbContext.club_members.Add(club_Members);
                _cdscDbContext.SaveChanges();

                var mynames = _cdscDbContext.investment_club.ToList().Where(a => a.id == club_Members.club_id).FirstOrDefault();
                //send invite
                //var sent=SendSms("you have been invited to join C-Trade Investment Club " + mynames.club_name + " download Ctrade App https://play.google.com/store/apps/details?id=zw.co.escrow.ctradelive&hl=en or dial *727# to view More", phone);
            }
            catch (Exception f)
            {

                result = f.Message;
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public JsonResult ClubMemberUpdate(string clubphone, string clubcds, string phone, string email, string surname, string firstname, string club_id, int clubmemberid)
        {
            string result = "Member successfully updated";
            try
            {

                club_members club_Members = _cdscDbContext.club_members.Find(clubmemberid);
                club_Members.member_phone = phone;
                club_Members.member_email = email;
                _cdscDbContext.club_members.AddOrUpdate(club_Members);
                _cdscDbContext.SaveChanges();
            }
            catch (Exception)
            {

                result = "Member not updated";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public JsonResult ClubMemberRemove(int clubmemberid)
        {
            string result = "Member successfully removed";
            try
            {

                club_members club_Members = _cdscDbContext.club_members.Find(clubmemberid);
                club_Members.Active = false;
                _cdscDbContext.club_members.AddOrUpdate(club_Members);
                _cdscDbContext.SaveChanges();
            }
            catch (Exception)
            {

                result = "Member not removed";
            }

            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public JsonResult memberRemoval(int clubmemberid, string clubCdsNumber, string memberCdsNumber)
        {
            string result = "Member successfully removed";
            string result1 = "Failed to remove Member";
            try
            {

                club_members club_Members = _cdscDbContext.club_members.Find(clubmemberid);
                club_Members.Active = false;
                _cdscDbContext.club_members.AddOrUpdate(club_Members);
                _cdscDbContext.SaveChanges();
            }
            catch (Exception)
            {

                result = "Member not removed";
            }
            if (Desolvemember(memberCdsNumber, clubCdsNumber))
            {
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(result1, JsonRequestBehavior.AllowGet);
            }
            //return Json(result, JsonRequestBehavior.AllowGet);
        }
        //check if member exsist
        public int Confirmmember(string email)
        {
            int result = 0;
            try
            {

                var membercount = _cdDataContext.Accounts_Clients_Web.ToList().Where(a => a.Email.ToLower() == email.ToLower()).Count();

                if (membercount > 0)
                {
                    result = 1;
                }
            }
            catch (Exception)
            {

                result = 0;
            }
            return result;
        }
        public JsonResult CheckIfUserExists(string email)
        {
            var cdDataContexts = new cdscDbContext();
            var usernameFound = cdDataContexts.Vatenkecis.Where(x => x.Email.Trim() == email.Trim()).Count();

            if (usernameFound > 0)
            {
                return Json(1, JsonRequestBehavior.AllowGet);
            }
            var usernameFound2 = _cdDataContext.Accounts_Clients_Web.Where(x => x.Email.Trim() == email.Trim()).Count();
            if (usernameFound2 > 0)
            {
                return Json(1, JsonRequestBehavior.AllowGet);
            }
            return Json(0, JsonRequestBehavior.AllowGet); ;
        }

        public string Returnmember(string email)
        {
            var cdDataContexts = new cdscDbContext();
            var cdsnumber = (from p in cdDataContexts.Vatenkecis.Where(x => x.Email.Trim() == email.Trim()) select new { p.CdsNumber }).FirstOrDefault();

            var usernameFound = cdDataContexts.Vatenkecis.Where(x => x.Email.Trim() == email.Trim()).Count();

            if (usernameFound > 0)
            {
                return cdsnumber.CdsNumber;
            }
            return "";
        }

        public JsonResult LoadFunds(string isin)
        {

            var fundlist = (from v in _AtsDbContext.para_company
                            where v.ISIN_No == isin
                            let ID = v.ID
                            let Company = v.Company
                            let FundType = v.fnam
                            let InitialPrice = v.InitialPrice
                            let IssueDate = v.Date_created
                            let IssuePricePerUnit = v.InitialPrice
                            select new { ID, Company, FundType, InitialPrice, IssueDate, IssuePricePerUnit }).ToList();



            return new CustomJsonResult { Data = new { fundlist } };
        }
        //paynow
        [HttpGet]
        public async Task<ActionResult> PaynowPayments(
     string cdsNumber,
     string price,
     string quantity,
     string email, string currency)
        {
            cdscDbContext cdscDbContext = new cdscDbContext();
            if (cdsNumber == null && price == null && (quantity == null && email == null))
                return (ActionResult)this.View();
            Decimal num1 = Math.Round(Decimal.Parse(price) * Decimal.Parse(quantity), 2);
            BuyOrderPayments entity = new BuyOrderPayments()
            {
                CdsNumber = cdsNumber,
                Company = "None",
                Price = price,
                Security = "Equity",
                Total = num1.ToString((IFormatProvider)CultureInfo.InvariantCulture),
                Quantity = quantity,
                PaymentStatus = "PENDING",
                PostedStatus = "PENDING",
                Date = new DateTime?(DateTime.Now),
                Broker = "None",
                EmailAddress = email,
                Currency = currency
            };
            cdscDbContext.BuyOrderPayments.Add(entity);
            cdscDbContext.SaveChanges();
            BuyOrderPayments buyOrderPayments = new cdscDbContext().BuyOrderPayments.OrderByDescending<BuyOrderPayments, int>((Expression<Func<BuyOrderPayments, int>>)(x => x.Id)).FirstOrDefault<BuyOrderPayments>((Expression<Func<BuyOrderPayments, bool>>)(x => x.CdsNumber == cdsNumber && x.PaymentStatus == "PENDING" && x.PostedStatus == "PENDING"));
            if (buyOrderPayments == null)
                return (ActionResult)this.View();
            Guid.NewGuid();
            int num2 = 5333;
            string guid = "2044befe-9f70-4ca2-9d59-d46e380ea284";
            /* return urlhttps://ctrade.co.zw/online/paynow/thankyou.php 
             * resulturlhttp://197.155.235.78:8446/CTRADEAPI/subscriber/PaynowPaymentsResultUrl
             * */
            string twoWayHash = SubscriberController.GenerateTwoWayHash(new Dictionary<string, string>()
      {
        {
          "id",
          num2.ToString()
        },
        {
          "reference",
          buyOrderPayments.Id.ToString()
        },
        {
          "amount",
          num1.ToString((IFormatProvider) CultureInfo.InvariantCulture)
        },
        {
          "returnurl",
          "https://demo.ctrade.co.zw/ctrade_v2/paynow/thankyou.php"

        },
        {
          "resulturl",
          "https://demo.ctrade.co.zw/mobileapi/PaynowPaymentsResultUrl"
        },
        {
          "status",
          "Message"
        }
      }, guid);
            FormUrlEncodedContent urlEncodedContent = new FormUrlEncodedContent((IEnumerable<KeyValuePair<string, string>>)new Dictionary<string, string>()
      {
        {
          "id",
          num2.ToString()
        },
        {
          "reference",
          buyOrderPayments.Id.ToString()
        },
        {
          "amount",
          num1.ToString((IFormatProvider) CultureInfo.InvariantCulture)
        },
        {
          "returnurl",
          "https://demo.ctrade.co.zw/ctrade_v2/paynow/thankyou.php"
        },
        {
          "resulturl",
           "https://demo.ctrade.co.zw/mobileapi/PaynowPaymentsResultUrl"
        },
        {
          "status",
          "Message"
        },
        {
          "hash",
          twoWayHash
        }
      });
            string str = HttpUtility.UrlDecode(await (await SubscriberController.client.PostAsync("https://www.paynow.co.zw/interface/initiatetransaction", (HttpContent)urlEncodedContent)).Content.ReadAsStringAsync());
            List<string> stringList = new List<string>();
            if (str == null)
                return (ActionResult)this.View();
            stringList.AddRange((IEnumerable<string>)str.Split('&'));
            return (ActionResult)this.Redirect(stringList[1].Split('=')[1].Trim());
        }

        [HttpPost]
        public async Task<ActionResult> PaynowPayments(FormCollection formCollection)
        {
            string cdsNumber = formCollection["cdsNumber"];
            string form1 = formCollection["total"];
            string form2 = formCollection["security"];
            string form3 = formCollection["quantity"];
            string form4 = formCollection["company"];
            string form5 = formCollection["price"];
            BuyOrderPayments buyOrderPayments = new cdscDbContext().BuyOrderPayments.OrderByDescending<BuyOrderPayments, int>((Expression<Func<BuyOrderPayments, int>>)(x => x.Id)).FirstOrDefault<BuyOrderPayments>((Expression<Func<BuyOrderPayments, bool>>)(x => x.CdsNumber == cdsNumber && x.PaymentStatus == "PENDING" && x.PostedStatus == "PENDING"));
            if (buyOrderPayments == null)
                return (ActionResult)this.View();
            Guid.NewGuid();
            int num = 5333;
            string guid = "2044befe-9f70-4ca2-9d59-d46e380ea284";
            string twoWayHash = SubscriberController.GenerateTwoWayHash(new Dictionary<string, string>()
      {
        {
          "id",
          num.ToString()
        },
        {
          "reference",
          buyOrderPayments.Id.ToString()
        },
        {
          "amount",
          form1.ToString((IFormatProvider) CultureInfo.InvariantCulture)
        },
        {
          "returnurl",
          "http://197.155.235.78:8446/SSX/Ssx/PaynowPaymentsReturnUrl"
        },
        {
          "resulturl",
          "http://197.155.235.78:8446/SSX/Ssx/PaynowPaymentsResultUrl"
        },
        {
          "status",
          "Message"
        }
      }, guid);
            FormUrlEncodedContent urlEncodedContent = new FormUrlEncodedContent((IEnumerable<KeyValuePair<string, string>>)new Dictionary<string, string>()
      {
        {
          "id",
          num.ToString()
        },
        {
          "reference",
          buyOrderPayments.Id.ToString()
        },
        {
          "amount",
          form1.ToString((IFormatProvider) CultureInfo.InvariantCulture)
        },
        {
          "returnurl",
          "http://197.155.235.78:8446/SSX/Ssx/PaynowPaymentsReturnUrl"
        },
        {
          "resulturl",
          "http://197.155.235.78:8446/SSX/Ssx/PaynowPaymentsResultUrl"
        },
        {
          "status",
          "Message"
        },
        {
          "hash",
          twoWayHash
        }
      });
            string str = HttpUtility.UrlDecode(await (await SubscriberController.client.PostAsync("https://www.paynow.co.zw/interface/initiatetransaction", (HttpContent)urlEncodedContent)).Content.ReadAsStringAsync());
            List<string> stringList = new List<string>();
            if (str == null)
                return (ActionResult)this.View();
            stringList.AddRange((IEnumerable<string>)str.Split('&'));
            return (ActionResult)this.Redirect(stringList[1].Split('=')[1].Trim());
        }

        private static string GenerateTwoWayHash(Dictionary<string, string> items, string guid)
        {
            return SubscriberController.ByteArrayToString(SHA512.Create().ComputeHash(Encoding.UTF8.GetBytes(string.Join("", items.Select<KeyValuePair<string, string>, string>((Func<KeyValuePair<string, string>, string>)(c =>
            {
                if (c.Value == null || !(c.Key.ToLower() != "hash"))
                    return "";
                return c.Value.Trim();
            })).ToArray<string>()) + guid)));
        }

        public static string ByteArrayToString(byte[] ba)
        {
            StringBuilder stringBuilder = new StringBuilder(ba.Length * 2);
            foreach (byte num in ba)
                stringBuilder.AppendFormat("{0:x2}", (object)num);
            return stringBuilder.ToString().ToUpper();
        }

        public string PaynowPaymentsReturnUrl()
        {
            return "Thank you for paying with paynow";
        }

        [HttpPost]
        public void PaynowPaymentsResultUrl(FormCollection formCollection)
        {
            cdscDbContext cdscDbContext = new cdscDbContext();
            try
            {
                string form1 = formCollection["reference"];
                string form2 = formCollection["amount"];
                string form3 = formCollection["status"];
                string form4 = formCollection["pollurl"];
                string form5 = formCollection["paynowreference"];
                int intRef = int.Parse(form1);
                BuyOrderPayments buyOrderPayments = cdscDbContext.BuyOrderPayments.OrderByDescending<BuyOrderPayments, int>((Expression<Func<BuyOrderPayments, int>>)(x => x.Id)).FirstOrDefault<BuyOrderPayments>((Expression<Func<BuyOrderPayments, bool>>)(x => x.Id == intRef));
                if (buyOrderPayments != null)
                {
                    buyOrderPayments.PaynowRef = form5;
                    buyOrderPayments.PollUrl = form4;
                    string paymentStatus = buyOrderPayments.PaymentStatus;
                    buyOrderPayments.PaymentStatus = form3;
                    buyOrderPayments.Total = form2;
                    cdscDbContext.SaveChanges();
                    /* if (!paymentStatus.ToString().Equals("Cancelled") ||!paymentStatus.ToString().Equals("PENDING") || !form3.Equals("Paid") && !form3.Equals("Delivered") && !form3.Equals("Awaiting Delivery"))
                         return;*/
                    if (buyOrderPayments.Currency == "ZWL")
                    {
                        CashTrans entity = new CashTrans()
                        {
                            Description = "PAYNOW DEPOSIT",
                            TransType = "DEPOSIT",
                            TransStatus = "1",
                            Amount = new Decimal?(Decimal.Parse(buyOrderPayments.Total)),
                            CDS_Number = buyOrderPayments.CdsNumber,
                            DateCreated = DateTime.Now
                        };
                        cdscDbContext.CashTrans.Add(entity);
                        cdscDbContext.SaveChanges();
                        buyOrderPayments.PostedStatus = form3;
                        cdscDbContext.SaveChanges();

                    }
                    else if (buyOrderPayments.Currency != "ZWL")
                    {
                        CashTrans_forex entity = new CashTrans_forex()
                        {
                            Description = "PAYNOW DEPOSIT",
                            TransType = "DEPOSIT",
                            TransStatus = "1",
                            Amount = new Decimal?(Decimal.Parse(buyOrderPayments.Total)),
                            CDS_Number = buyOrderPayments.CdsNumber,
                            DateCreated = DateTime.Now,
                            Currency = buyOrderPayments.Currency

                        };
                        cdscDbContext.CashTrans_forex.Add(entity);
                        cdscDbContext.SaveChanges();
                        buyOrderPayments.PostedStatus = form3;
                        cdscDbContext.SaveChanges();
                    }

                }
                else
                {
                    BuyOrderPayments entity = new BuyOrderPayments()
                    {
                        PaymentStatus = form3,
                        PaynowRef = "Not Null" + (object)intRef
                    };
                    cdscDbContext.BuyOrderPayments.Add(entity);
                    cdscDbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                BuyOrderPayments entity = new BuyOrderPayments()
                {
                    PaymentStatus = ex.Message
                };
                cdscDbContext.BuyOrderPayments.Add(entity);
                cdscDbContext.SaveChanges();
            }
        }

        //paynow usd
        [HttpGet]
        public async Task<ActionResult> PaynowPaymentsUSD(
   string cdsNumber,
   string price,
   string quantity,
   string email, string currency)
        {
            cdscDbContext cdscDbContext = new cdscDbContext();
            if (cdsNumber == null && price == null && (quantity == null && email == null))
                return (ActionResult)this.View();
            Decimal num1 = Math.Round(Decimal.Parse(price) * Decimal.Parse(quantity), 2);
            BuyOrderPayments entity = new BuyOrderPayments()
            {
                CdsNumber = cdsNumber,
                Company = "None",
                Price = price,
                Security = "Equity",
                Total = num1.ToString((IFormatProvider)CultureInfo.InvariantCulture),
                Quantity = quantity,
                PaymentStatus = "PENDING",
                PostedStatus = "PENDING",
                Date = new DateTime?(DateTime.Now),
                Broker = "None",
                EmailAddress = email,
                Currency = currency
            };
            cdscDbContext.BuyOrderPayments.Add(entity);
            cdscDbContext.SaveChanges();
            BuyOrderPayments buyOrderPayments = new cdscDbContext().BuyOrderPayments.OrderByDescending<BuyOrderPayments, int>((Expression<Func<BuyOrderPayments, int>>)(x => x.Id)).FirstOrDefault<BuyOrderPayments>((Expression<Func<BuyOrderPayments, bool>>)(x => x.CdsNumber == cdsNumber && x.PaymentStatus == "PENDING" && x.PostedStatus == "PENDING"));
            if (buyOrderPayments == null)
                return (ActionResult)this.View();
            Guid.NewGuid();
            int num2 = 7948;
            string guid = "6bd35932-9706-4bad-b1f8-219ddd3829ab";
            /* return urlhttps://ctrade.co.zw/online/paynow/thankyou.php 
             * resulturlhttp://197.155.235.78:8446/CTRADEAPI/subscriber/PaynowPaymentsResultUrl
             * */
            string twoWayHash = SubscriberController.GenerateTwoWayHash(new Dictionary<string, string>()
      {
        {
          "id",
          num2.ToString()
        },
        {
          "reference",
          buyOrderPayments.Id.ToString()
        },
        {
          "amount",
          num1.ToString((IFormatProvider) CultureInfo.InvariantCulture)
        },
        {
          "returnurl",
          "https://demo.ctrade.co.zw/ctrade/paynow/thankyou.php"

        },
        {
          "resulturl",
          "https://demo.ctrade.co.zw/mobileapi/PaynowPaymentsResultUrlUSD"
        },
        {
          "status",
          "Message"
        }
      }, guid);
            FormUrlEncodedContent urlEncodedContent = new FormUrlEncodedContent((IEnumerable<KeyValuePair<string, string>>)new Dictionary<string, string>()
      {
        {
          "id",
          num2.ToString()
        },
        {
          "reference",
          buyOrderPayments.Id.ToString()
        },
        {
          "amount",
          num1.ToString((IFormatProvider) CultureInfo.InvariantCulture)
        },
        {
          "returnurl",
          "https://demo.ctrade.co.zw/ctrade/paynow/thankyou.php"
        },
        {
          "resulturl",
           "https://demo.ctrade.co.zw/mobileapi/PaynowPaymentsResultUrlUSD"
        },
        {
          "status",
          "Message"
        },
        {
          "hash",
          twoWayHash
        }
      });
            string str = HttpUtility.UrlDecode(await (await SubscriberController.client.PostAsync("https://www.paynow.co.zw/interface/initiatetransaction", (HttpContent)urlEncodedContent)).Content.ReadAsStringAsync());
            List<string> stringList = new List<string>();
            if (str == null)
                return (ActionResult)this.View();
            stringList.AddRange((IEnumerable<string>)str.Split('&'));
            return (ActionResult)this.Redirect(stringList[1].Split('=')[1].Trim());
        }

        [HttpPost]
        public async Task<ActionResult> PaynowPaymentsUSD(FormCollection formCollection)
        {
            string cdsNumber = formCollection["cdsNumber"];
            string form1 = formCollection["total"];
            string form2 = formCollection["security"];
            string form3 = formCollection["quantity"];
            string form4 = formCollection["company"];
            string form5 = formCollection["price"];
            BuyOrderPayments buyOrderPayments = new cdscDbContext().BuyOrderPayments.OrderByDescending<BuyOrderPayments, int>((Expression<Func<BuyOrderPayments, int>>)(x => x.Id)).FirstOrDefault<BuyOrderPayments>((Expression<Func<BuyOrderPayments, bool>>)(x => x.CdsNumber == cdsNumber && x.PaymentStatus == "PENDING" && x.PostedStatus == "PENDING"));
            if (buyOrderPayments == null)
                return (ActionResult)this.View();
            Guid.NewGuid();
            int num = 7948;
            string guid = "6bd35932-9706-4bad-b1f8-219ddd3829ab";
            string twoWayHash = SubscriberController.GenerateTwoWayHash(new Dictionary<string, string>()
      {
        {
          "id",
          num.ToString()
        },
        {
          "reference",
          buyOrderPayments.Id.ToString()
        },
        {
          "amount",
          form1.ToString((IFormatProvider) CultureInfo.InvariantCulture)
        },
        {
          "returnurl",
          "https://demo.ctrade.co.zw/mobileapi/PaynowPaymentsReturnUrlUSD"
        },
        {
          "resulturl",
          "https://demo.ctrade.co.zw/mobileapi/PaynowPaymentsResultUrlUSD"
        },
        {
          "status",
          "Message"
        }
      }, guid);
            FormUrlEncodedContent urlEncodedContent = new FormUrlEncodedContent((IEnumerable<KeyValuePair<string, string>>)new Dictionary<string, string>()
      {
        {
          "id",
          num.ToString()
        },
        {
          "reference",
          buyOrderPayments.Id.ToString()
        },
        {
          "amount",
          form1.ToString((IFormatProvider) CultureInfo.InvariantCulture)
        },
        {
          "returnurl",
          "https://demo.ctrade.co.zw/mobileapi/PaynowPaymentsReturnUrlUSD"
        },
        {
          "resulturl",
          "https://demo.ctrade.co.zw/mobileapi/PaynowPaymentsResultUrlUSD"
        },
        {
          "status",
          "Message"
        },
        {
          "hash",
          twoWayHash
        }
      });
            string str = HttpUtility.UrlDecode(await (await SubscriberController.client.PostAsync("https://www.paynow.co.zw/interface/initiatetransaction", (HttpContent)urlEncodedContent)).Content.ReadAsStringAsync());
            List<string> stringList = new List<string>();
            if (str == null)
                return (ActionResult)this.View();
            stringList.AddRange((IEnumerable<string>)str.Split('&'));
            return (ActionResult)this.Redirect(stringList[1].Split('=')[1].Trim());
        }



        public string PaynowPaymentsReturnUrlUSD()
        {
            return "Thank you for paying with paynow";
        }

        [HttpPost]
        public void PaynowPaymentsResultUrlUSD(FormCollection formCollection)
        {
            cdscDbContext cdscDbContext = new cdscDbContext();
            try
            {
                string form1 = formCollection["reference"];
                string form2 = formCollection["amount"];
                string form3 = formCollection["status"];
                string form4 = formCollection["pollurl"];
                string form5 = formCollection["paynowreference"];
                int intRef = int.Parse(form1);
                BuyOrderPayments buyOrderPayments = cdscDbContext.BuyOrderPayments.OrderByDescending<BuyOrderPayments, int>((Expression<Func<BuyOrderPayments, int>>)(x => x.Id)).FirstOrDefault<BuyOrderPayments>((Expression<Func<BuyOrderPayments, bool>>)(x => x.Id == intRef));
                if (buyOrderPayments != null)
                {
                    buyOrderPayments.PaynowRef = form5;
                    buyOrderPayments.PollUrl = form4;
                    string paymentStatus = buyOrderPayments.PaymentStatus;
                    buyOrderPayments.PaymentStatus = form3;
                    buyOrderPayments.Total = form2;
                    cdscDbContext.SaveChanges();
                    if (!paymentStatus.ToString().Equals("PENDING") || !form3.Equals("Paid") && !form3.Equals("Delivered") && !form3.Equals("Awaiting Delivery"))
                        return;


                    CashTrans_forex entity = new CashTrans_forex()
                    {
                        Description = "PAYNOW DEPOSIT",
                        TransType = "DEPOSIT",
                        TransStatus = "1",
                        Amount = new Decimal?(Decimal.Parse(buyOrderPayments.Total)),
                        CDS_Number = buyOrderPayments.CdsNumber,
                        DateCreated = DateTime.Now,
                        Currency = buyOrderPayments.Currency

                    };
                    cdscDbContext.CashTrans_forex.Add(entity);
                    cdscDbContext.SaveChanges();
                    buyOrderPayments.PostedStatus = form3;
                    cdscDbContext.SaveChanges();


                }
                else
                {
                    BuyOrderPayments entity = new BuyOrderPayments()
                    {
                        PaymentStatus = form3,
                        PaynowRef = "Not Null" + (object)intRef
                    };
                    cdscDbContext.BuyOrderPayments.Add(entity);
                    cdscDbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                BuyOrderPayments entity = new BuyOrderPayments()
                {
                    PaymentStatus = ex.Message
                };
                cdscDbContext.BuyOrderPayments.Add(entity);
                cdscDbContext.SaveChanges();
            }
        }
        //preshareholdercreation

        public JsonResult PreshareHolderExsists(string cdsnumber)
        {
            var fundlist = 0;
            fundlist = _cdDataContext.Database.SqlQuery<Pre_created>("select * from Pre_Created where replace(cast(cast(Shareholder as decimal) as nvarchar),'-','')=cast('" + cdsnumber + "' as nvarchar)").ToList().Count();


            var cdsclist = _cdDataContext.Accounts_Clients_Web.ToList().Where(a => a.CDS_Number == cdsnumber).Count();
            if (cdsclist > 0)
            {
                fundlist = 2;
            }
            return Json(fundlist, JsonRequestBehavior.AllowGet);
        }
        public JsonResult PreshareHolder(string cdsnumber)
        {

            var predetails = _cdDataContext.Database.SqlQuery<Pre_created>("select * from Pre_Created where replace(cast(cast(Shareholder as decimal) as nvarchar),'-','')=cast('" + cdsnumber + "' as nvarchar)").ToList();

            return new CustomJsonResult { Data = new { predetails } };
        }
        public JsonResult ForexTypes()
        {

            var predetails = _cdscDbContext.Database.SqlQuery<ForexTypes>("select * from ForexTypes").ToList();

            return Json(predetails, JsonRequestBehavior.AllowGet);
        }

        //insert into cashtrans forex
        public JsonResult LoadCash(string cdsnumber, string amount)
        {
            string result = "0";
            try
            {
                CashTrans_forex entity = new CashTrans_forex()
                {
                    Description = "DEPOSIT",
                    TransType = "DEPOSIT",
                    TransStatus = "1",
                    Amount = new Decimal?(Decimal.Parse(amount)),
                    CDS_Number = cdsnumber,
                    DateCreated = DateTime.Now,
                    Currency = "USD"

                };
                _cdscDbContext.CashTrans_forex.Add(entity);
                _cdscDbContext.SaveChanges();
                result = "1";
            }
            catch (Exception f)
            {

                result = "0";
            }

            //check for nominee
            var fundlist = _cdDataContext.Database.SqlQuery<Pre_created>("select * from Pre_Created where replace(cast(cast(Shareholder as decimal) as nvarchar),'-','')=cast('" + cdsnumber + "' as nvarchar)").ToList().FirstOrDefault();

            if (fundlist.For_Nominee == false)
            {
                var execAcc = _cdDataContext.Database.ExecuteSqlCommand("Update Accounts_Clients_Web set trading_platform='FINSEC',AccountState='PENDING' where CDS_Number='" + cdsnumber + "'");
            }

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult AndroidVersion()
        {

            var androidversion = _cdscDbContext.app_version.ToList().Take(1);
            return Json(androidversion, JsonRequestBehavior.AllowGet);
        }
        //get forex orders
        public JsonResult GetForex(string cds_number)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
            var marketWatcher = new List<Forex_O_Lives>();

            string sql = "select *, case when TransStatus='1' then 'Approved' else 'Pending' end as 'Final' from CashTrans_forex where CDS_Number='" + cds_number + "' and [Type_] in ('BUY','SELL') order by ID desc";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Forex_O_Lives recordSummary = new Forex_O_Lives
                    {
                        id = int.Parse(rdr["ID"].ToString()),
                        counter = rdr["Currency"].ToString(),
                        type = rdr["Type_"].ToString(),
                        volume = rdr["Amount"].ToString(),
                        price = rdr["Rate"].ToString(),
                        date = DateTime.Parse(rdr["DateCreated"].ToString()).ToString("dd MMM yyyy"),
                        status = rdr["Final"].ToString(),
                        desc = rdr["Description"].ToString(),
                        fullname = rdr["CDS_Number"].ToString(),
                        ordernumber = rdr["ID"].ToString(),
                        source = rdr["Source"].ToString(),
                        Bureau = rdr["Bureau"].ToString()
                    };
                    marketWatcher.Add(recordSummary);
                }
            }

            if (marketWatcher.Any())
            {
                return Json(marketWatcher, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(0, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult SanctionedExsists(string search)
        {
            var fundlist = 0;
            fundlist = _cdsDataContext.Database.SqlQuery<SanctionedList>("select * from SanctionedList where REPLACE(LOWER(names+''+surname),' ','')=REPLACE(LOWER('" + search + "'),' ','')").ToList().Count();



            if (fundlist > 0)
            {
                fundlist = 1;
            }
            return Json(fundlist, JsonRequestBehavior.AllowGet);
        }
        //sanction validation
        public int SanctionedExsistsval(string search)
        {
            var fundlist = 0;
            fundlist = _cdsDataContext.Database.SqlQuery<SanctionedList>("select * from SanctionedList where REPLACE(LOWER(names+''+surname),' ','')=REPLACE(LOWER('" + search + "'),' ','')").ToList().Count();



            if (fundlist > 0)
            {
                fundlist = 1;
            }
            return fundlist;
        }

        public JsonResult IDExsists(string idno)
        {
            var fundlist = 0;

            var clientsweblist = _cdDataContext.Accounts_Clients_Web.ToList().Where(a => a.IDNoPP.Replace(" ", "") == idno.Replace(" ", "")).Count();
            if (clientsweblist > 0)
            {
                fundlist = 1;
            }
            var clientslist = _cdDataContext.Accounts_Clients.ToList().Where(a => a.IDNoPP.Replace(" ", "") == idno.Replace(" ", "")).Count();
            if (clientslist > 0)
            {
                fundlist = 1;
            }
            return Json(fundlist, JsonRequestBehavior.AllowGet);
        }

        // SELECT investment_club.*FROM [CDSC].[dbo].[club_members] inner join investment_club on investment_club.id = club_members.club_id where member_phone like '%775567639'
        public JsonResult GetMyMemberClubs(string phone)
        {
            var fundlist = 0;


            var clientsweblist = _cdscDbContext.Database.SqlQuery<investments_club_two>("SELECT investment_club.id, investment_club.chairman_id,investment_club.club_member_num,investment_club.club_name,investment_club.club_phone,convert(nvarchar, investment_club.created_date, 106) as created_date,phone,investment_club.Active,investment_club.club_cds_number FROM[CDSC].[dbo].[club_members] inner join investment_club on investment_club.id = club_members.club_id where member_phone like '%" + phone + "' and confirmed = '1' and rejected = '0'").ToList();

            return Json(clientsweblist, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetMyMemberClubsNew(string cdsnumber)
        {
            var fundlist = 0;


            var clientsweblist = _cdscDbContext.Database.SqlQuery<investments_club_two>("SELECT investment_club.id, investment_club.chairman_id,investment_club.club_member_num,investment_club.club_name,investment_club.club_phone,convert(nvarchar, investment_club.created_date, 106) as created_date,phone,investment_club.Active,investment_club.club_cds_number FROM[CDSC].[dbo].[club_members] inner join investment_club on investment_club.id = club_members.club_id where member_cds_number = '" + cdsnumber + "' and confirmed = '1' and rejected = '0' and club_members.Active = '1' ").ToList();

            return Json(clientsweblist, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetMyMemberClubsPending(string phone)
        {
            var fundlist = 0;

            var clientsweblist = _cdscDbContext.Database.SqlQuery<investment_club>("SELECT investment_club.* FROM [CDSC].[dbo].[club_members] inner join investment_club on investment_club.id = club_members.club_id where member_phone like '%" + phone + "' and club_members.confirmed ='0' ").ToList();

            return Json(clientsweblist, JsonRequestBehavior.AllowGet);
        }
        public JsonResult myGroupInvitations(string cdsnumber)
        {
            var fundlist = 0;

            var clientsweblist = _cdscDbContext.Database.SqlQuery<investment_club>("SELECT investment_club.* FROM [CDSC].[dbo].[club_members] inner join investment_club on investment_club.id = club_members.club_id where member_cds_number = '" + cdsnumber + "' and club_members.confirmed ='0'").ToList();

            return Json(clientsweblist, JsonRequestBehavior.AllowGet);
        }

        //_cdsDataContext
        public JsonResult CheckAttachments(string cdsnumber)
        {

            int? count = 0;

            try
            {
                var mylist = _cdDataContext.Database.SqlQuery<Attachments>("select count(ID) as 'Count' from Accounts_Documents where doc_generated='" + cdsnumber + "'").FirstOrDefault();
                count = mylist.Count;
            }
            catch (Exception)
            {

                count = 0;
            }

            if (String.IsNullOrEmpty(count.ToString()) == true)
            {
                count = 0;
            }


            return Json(count, JsonRequestBehavior.AllowGet);
        }
        public JsonResult IDCDS(string idno)
        {
            var fundlist = 0;

            var clientsweblist = _cdDataContext.Accounts_Clients_Web.ToList().Where(a => a.IDNoPP.Replace(" ", "") == idno.Replace(" ", "")).FirstOrDefault();

            return Json(clientsweblist.CDS_Number, JsonRequestBehavior.AllowGet);
        }
        public JsonResult CheckMissingAttachments(string cdsnumber)
        {

            int? count = 0;
            int? count2 = 0;
            int? count3 = 0;
            string missing = "The following documents are needed ";
            try
            {
                var mylist = _cdDataContext.Database.SqlQuery<Attachments>("select isNull(count(ID),0) as 'Count' from Accounts_Documents where doc_generated='" + cdsnumber + "'  and Name='National ID' ").FirstOrDefault();
                count = mylist.Count;

            }
            catch (Exception)
            {

                count = 0;
            }
            try
            {
                var mylist = _cdDataContext.Database.SqlQuery<Attachments>("select isNull(count(ID),0) as 'Count' from Accounts_Documents where doc_generated='" + cdsnumber + "' and Name='Proof Of Residence'  ").FirstOrDefault();
                count2 = mylist.Count;
            }
            catch (Exception)
            {

                count2 = 0;
            }
            try
            {
                var mylist = _cdDataContext.Database.SqlQuery<Attachments>("select isNull(count(ID),0) as 'Count' from Accounts_Documents where doc_generated='" + cdsnumber + "' and Name='Photo'  ").FirstOrDefault();
                count3 = mylist.Count;
            }
            catch (Exception)
            {

                count3 = 0;
            }
            if (count == 0)
            {
                missing = missing + " National ID,";
            }
            if (count2 == 0)
            {
                missing = missing + " Proof Of Residence,";
            }
            if (count3 == 0)
            {
                missing = missing + " Photo,";
            }
            return Json(missing, JsonRequestBehavior.AllowGet);
        }

        // 
        public JsonResult OrderUpdate(string OrderNo, string cdsnumber, string OrderType, string Company, string Quantity, string BasePrice, string TimeInForce, string trading_platform, string FOK)
        {
            var message = "1";
            try
            {

                var orderno = Convert.ToInt64(OrderNo);
                var orderLive = _AtsDbContext.Pre_Order_Live.Find(orderno);

                orderLive.OrderType = OrderType;
                orderLive.Company = Company;
                orderLive.CDS_AC_No = cdsnumber;
                orderLive.Quantity = Convert.ToInt32(Quantity);
                orderLive.BasePrice = Convert.ToDouble(BasePrice);
                orderLive.TimeInForce = TimeInForce;
                orderLive.FOK = bool.Parse(FOK);
                orderLive.trading_platform = GetTradingPlaform(Company);

                _AtsDbContext.Pre_Order_Live.AddOrUpdate(orderLive);
                _AtsDbContext.SaveChanges();
            }
            catch (Exception f)
            {
                message = f.Message;
                message = "0";
            }
            return Json(message, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCompaniesandPricesEXCHANGEUpdate(string exchange, string company)
        {
            var companies = new List<CompanyPrices>();
            //load finsec 
            if (exchange.ToLower() == "zse")
            {
                var connectionString = ConfigurationManager.ConnectionStrings["CdDataContext"].ConnectionString;
                var sql = @"SELECT top 1 cast(ut.id as nvarchar) as 'Id' ,qt.fnam + '(' + ut.Ticker + ') - $' + cast(ut.Current_price as nvarchar) as 'WebCompanyName', ut.Ticker + ',' + cast(ut.Current_price as nvarchar) as 'WebCompanyValue'
                        FROM[CDS_ROUTER].[dbo].[ZSE_market_data] ut , testcds_ROUTER.dbo.para_company qt
                        WHERE ut.Ticker = '" + company + "'";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        CompanyPrices recordSummary = new CompanyPrices();
                        recordSummary.Id = rdr["Id"].ToString();
                        recordSummary.WebCompanyName = rdr["WebCompanyName"].ToString();
                        recordSummary.WebCompanyValue = rdr["WebCompanyValue"].ToString();
                        companies.Add(recordSummary);
                    }
                }

            }
            else if (exchange.ToLower() == "finsec")
            {
                var connectionString = ConfigurationManager.ConnectionStrings["AtsDbContext"].ConnectionString;
                var sql = @" SELECT top 1 cast(1 as nvarchar) as 'Id' ,b.fnam + '(' + b.company + ') - $' + cast(Lastmatched as nvarchar) as 'WebCompanyName', b.company + ',' + cast(Lastmatched as nvarchar) as 'WebCompanyValue' FROM [testcds_ROUTER].[dbo].[MarketWatch] a, testcds_ROUTER.dbo.para_company b WHERE a.company = '" + company + "'";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        CompanyPrices recordSummary = new CompanyPrices();
                        recordSummary.Id = rdr["Id"].ToString();
                        recordSummary.WebCompanyName = rdr["WebCompanyName"].ToString();
                        recordSummary.WebCompanyValue = rdr["WebCompanyValue"].ToString();
                        companies.Add(recordSummary);
                    }
                }
            }

            return Json(companies, JsonRequestBehavior.AllowGet);
        }
        //
        private string SendSms(string messages, string mobile)
        {
            // Find your Account Sid and Token at twilio.com/console
            // DANGER! This is insecure. See http://twil.io/secure
            System.Net.ServicePointManager.ServerCertificateValidationCallback = (object se, System.Security.Cryptography.X509Certificates.X509Certificate cert, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslerror) => true;

            const string accountSid = "ACb039356b48f7e1357e744ff67d7db32f";
            const string authToken = "0857661b8093d1eb0e513eac12b92724";
            var mess = "";
            TwilioClient.Init(accountSid, authToken);
            try
            {
                var message = MessageResource.Create(
                    body: messages,
                    from: new Twilio.Types.PhoneNumber("CTrade"),
                    to: new Twilio.Types.PhoneNumber(mobile)
                );

                Console.WriteLine(message.Sid);
            }
            catch (ApiException e)
            {
                mess = e.Message;
                mess = mess + $"Twilio Error {e.Code} - {e.MoreInfo}";
            }




            return mess;
        }
        public JsonResult SendSmss(string messages, string mobile)
        {
            // Find your Account Sid and Token at twilio.com/console
            // DANGER! This is insecure. See http://twil.io/secure
            // ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            const string accountSid = "ACb039356b48f7e1357e744ff67d7db32f";
            const string authToken = "0857661b8093d1eb0e513eac12b92724";
            var mess = "";
            TwilioClient.Init(accountSid, authToken);
            try
            {
                var message = MessageResource.Create(
                    body: messages,
                    from: new Twilio.Types.PhoneNumber("CTrade"),
                    to: new Twilio.Types.PhoneNumber(mobile)
                );

                Console.WriteLine(message.Sid);
            }
            catch (ApiException e)
            {
                mess = e.Message;
                mess = mess + $"Twilio Error {e.Code} - {e.MoreInfo}";
            }




            return Json(mess, JsonRequestBehavior.AllowGet);
        }

        public JsonResult AcceptClub(Boolean state, string club_id, string phone)
        {

            var sql = "update club_members set rejected='" + state + "', confirmed='1' where member_phone = '" + phone + "' and club_id = '" + club_id + "' and [member_phone]='" + phone + "'";
            var updt = _cdscDbContext.Database.ExecuteSqlCommand(sql);
            return Json(updt, JsonRequestBehavior.AllowGet);
        }
        public JsonResult ActivateMembership(Boolean state, string club_id, string cdsnumber)
        {
            var sql = "update club_members set rejected='" + state + "', confirmed='1' where member_cds_number = '" + cdsnumber + "' and club_id = '" + club_id + "' ";
            var updt = _cdscDbContext.Database.ExecuteSqlCommand(sql);
            return Json(updt, JsonRequestBehavior.AllowGet);
        }

        public string WidthdrawToClub(string cdsnumber, string groupcdsnumber, string ammount)
        {
            var tempDbContext = new cdscDbContext();
            try
            {
                //check locked status


                var moneyAvail =
                tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsnumber && x.TransStatus.Trim() == "1");

                if (moneyAvail != null)
                {

                    var theCashBal =
                    tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsnumber && x.TransStatus.Trim() == "1")
                    .Select(x => x.Amount)
                    .Sum();
                    if (theCashBal <= 10 || theCashBal < (Decimal.Parse(ammount)))
                    {
                        return "You have insufficient balance in your Cash account";
                    }
                }
                else
                {
                    return "You have insufficient balance in your Cash account";
                }

                //Selecting distinct
                var orderCashTrans = new CashTrans
                {
                    Description = "Withdrawal",
                    TransType = "Withdraw",
                    TransStatus = "1",
                    Amount = -(Decimal.Parse(ammount)),
                    CDS_Number = cdsnumber,
                    DateCreated = DateTime.Now
                };
                tempDbContext.CashTrans.Add(orderCashTrans);
                tempDbContext.SaveChanges();

                var orderCashTransClub = new CashTrans
                {
                    Description = "Deposit",
                    TransType = "Deposit",
                    TransStatus = "1",
                    Amount = (Decimal.Parse(ammount)),
                    CDS_Number = groupcdsnumber,
                    DateCreated = DateTime.Now
                };
                tempDbContext.CashTrans.Add(orderCashTransClub);
                tempDbContext.SaveChanges();

                var orderCashGroupRecordTrans = new CashTransGroup
                {
                    Description = "Deposit",
                    TransType = "Deposit",
                    TransStatus = "1",
                    Amount = (Decimal.Parse(ammount)),
                    CDS_Number = cdsnumber,
                    CDS_NumberGroup = groupcdsnumber,
                    DateCreated = DateTime.Now
                };
                tempDbContext.CashTransGroup.Add(orderCashGroupRecordTrans);
                tempDbContext.SaveChanges();


                recordClubActivity(groupcdsnumber,"c");

                return "Deposit Successfull";
            }
            catch (Exception ex)
            {
                return "Failed to make withdrawal" + ex;
            }
            //return Json(companies, JsonRequestBehavior.AllowGet);
        }

        public JsonResult CtradeLimits()
        {
            var limits = _cdDataContext.CTRADELIMITS.ToList();
            return Json(limits, JsonRequestBehavior.AllowGet);
        }
        //cdc mast
        public JsonResult cdcmast(string cdsnumber)
        {
            var scs = _cdDataContext.Accounts_Clients_Web.ToList().Where(a => a.CDS_Number.ToLower().Replace(" ", "") == cdsnumber.ToLower().Replace(" ", "")).FirstOrDefault();

            var mastlist = _cdDataContext.Database.SqlQuery<CDCMast>("select Company,shares, FORMAT (Updated_On, 'dd/MM/yyyy hh:mm:ss') as UpdatedOn  from CDC_Balances where CDS_Number='" + scs.CDC_Number + "'");
            return Json(mastlist, JsonRequestBehavior.AllowGet);
        }

        //cdcportfolio
        public JsonResult Equiry(string cdsnumber)
        {
            var mess = "Enquiry has been saved.";
            try
            {
                Enquiry enquiry = new Enquiry();
                enquiry.Request = cdsnumber;
                enquiry.RequestDate = DateTime.Now;
                enquiry.Sent = false;
                _cdscDbContext.Enquiries.Add(enquiry);
                _cdscDbContext.SaveChanges();
            }
            catch (Exception f)
            {

                mess = f.ToString();
            }
            return Json(mess, JsonRequestBehavior.AllowGet);
        }

        public JsonResult testbal(string cdsnumber, string company)
        {
            decimal? theCashBal = 0;
            var chk_cdc = _cdDataContext.Accounts_Clients_Web.ToList().Where(a => a.CDS_Number == cdsnumber).FirstOrDefault();
            //.SqlQuery<Balancess>("SELECT amt  FROM New_Balz  where cds_number = '" + cdsnumber + "'").FirstOrDefault();
            var mybal = _cdDataContext.Database.SqlQuery<Balancess>("SELECT sum(Shares) as amt  FROM [CDS_ROUTER].[dbo].[CDC_Balances] where Cds_number='" + chk_cdc.CDC_Number + "' and Company='" + company + "'").FirstOrDefault();
            theCashBal = mybal.amt;
            return Json(theCashBal, JsonRequestBehavior.AllowGet);
        }
        public JsonResult Certificates(string cdsnumber)
        {

            //SELECT top 100 Cert as [Certficate No], Company, Shares from [Mast] WHERE COMPANY = 'OMZIL' and shareholder> 0 and shares> 0 and shareholder = ''
            var chk_cert = cERT.Database.SqlQuery<Certificates>("SELECT top 100 cast(Cert as nvarchar) as 'CertificateNo', Company, Shares from [Mast] WHERE COMPANY = 'OMZIL' and shareholder> 0 and shares> 0 and replace(cast(cast(shareholder as decimal) as nvarchar),'-','')=cast('" + cdsnumber + "' as nvarchar)");
            return Json(chk_cert, JsonRequestBehavior.AllowGet);
        }
        public JsonResult FinsecSharess(string cdsnumber)
        {

            //SELECT top 100 Cert as [Certficate No], Company, Shares from [Mast] WHERE COMPANY = 'OMZIL' and shareholder> 0 and shares> 0 and shareholder = ''
            // SELECT[Company] as Company ,[CDS_Number] as CdsNumber, isNull(sum(Shares),0) as 'Shares'  FROM[CDS].[dbo].[trans] where CDS_Number LIKE '%2733192105%' group by company,cds_number
            var chk_cert = cDSFINSEC.Database.SqlQuery<FinsecShares>("SELECT [Company] as Company ,[CDS_Number] as CdsNumber, isNull(sum(Shares),0) as 'Shares'  FROM [CDS_ROUTER].[dbo].[trans] where CDS_Number LIKE '%" + cdsnumber + "%' group by company,cds_number");
            return Json(chk_cert, JsonRequestBehavior.AllowGet);
        }

        public decimal? FinsecSharessBal(string cdsnumber, string company)
        {

            //SELECT top 100 Cert as [Certficate No], Company, Shares from [Mast] WHERE COMPANY = 'OMZIL' and shareholder> 0 and shares> 0 and shareholder = ''
            // SELECT[Company] as Company ,[CDS_Number] as CdsNumber, isNull(sum(Shares),0) as 'Shares'  FROM[CDS].[dbo].[trans] where CDS_Number LIKE '%2733192105%' group by company,cds_number

            writetofile("SHARES Finsec----" + cdsnumber + "        " + company);
            var chk_cert = cDSFINSEC.Database.SqlQuery<FinsecShares>("SELECT [Company] as Company ,[CDS_Number] as CdsNumber, isNull(sum(Shares),0) as 'Shares'  FROM [CDS_ROUTER].[dbo].[trans] where CDS_Number = '" + cdsnumber + "' and company='" + company + "' group by company,cds_number").FirstOrDefault();
            writetofile("SHARES Finsec----" + chk_cert.Shares);



            return chk_cert.Shares;

        }

        //   var chk_cdc = cdsDbContext.Database.SqlQuery<Accounts_Clients_Web>("SELECT * FROM Accounts_Clients_Web where CDS_Number='"+ cdsNumber +"' ").ToList().FirstOrDefault();
        public JsonResult TestCDS(string cdsNumber)
        {
            var cdsDbContext = new CdDataContext();

            var chk_cdc = cdsDbContext.Database.SqlQuery<Accounts_Clients_Web>("SELECT * FROM Accounts_Clients_Web where CDS_Number='" + cdsNumber + "' ").ToList().FirstOrDefault();
            return Json(chk_cdc, JsonRequestBehavior.AllowGet);
        }


        //paynow
        [HttpGet]
        public async Task<ActionResult> DirectPayOnline(string amount, string cdsnumber, string email)
        {

            var companytoken = "";
            var dpo = _cdscDbContext.DPOes.ToList().FirstOrDefault();
            var xmlmessage = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                    "<API3G>\n" +
                    "<CompanyToken>" + dpo.CompanyToken + "</CompanyToken>\n" +
                    "<Request>createToken</Request>\n" +
                    "<Transaction>\n" +
                    "<PaymentAmount>" + amount + "</PaymentAmount>\n" +
                    "<PaymentCurrency>USD</PaymentCurrency>\n" +
                    "<CompanyRef>CORPSERVE</CompanyRef>\n" +
                    "<RedirectURL>" + dpo.RedirectUrl + "</RedirectURL>\n" +
                    "<BackURL>" + dpo.RedirectUrl + "</BackURL>\n" +
                    "<CompanyRefUnique>0</CompanyRefUnique>\n" +
                    "<PTL>96</PTL>\n" +
                    "</Transaction>\n" +
                    "<Services>\n" +
                    "  <Service>\n" +
                    "    <ServiceType>" + dpo.ServiceTypeProduct + "</ServiceType>\n" +
                    "    <ServiceDescription>DEPOSIT</ServiceDescription>\n" +
                    "    <ServiceDate>" + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "</ServiceDate>\n" +
                    "  </Service>\n" +
                    "</Services>\n" +
                    "</API3G>";
            ServicePointManager.ServerCertificateValidationCallback += ValidateRemoteCertificate;
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            string url = dpo.CreateToken;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            byte[] requestInFormOfBytes = System.Text.Encoding.ASCII.GetBytes(xmlmessage);
            request.Method = "POST";
            request.ContentType = "text/xml;charset=utf-8";
            request.ContentLength = requestInFormOfBytes.Length;
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(requestInFormOfBytes, 0, requestInFormOfBytes.Length);
            requestStream.Close();

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader respStream = new StreamReader(response.GetResponseStream(), System.Text.Encoding.Default);
            var receivedResponse = respStream.ReadToEnd();
            // WriteErrorLog(receivedresponse1+"\n"+receivedResponse);
            respStream.Close();
            response.Close();


            //response url

            //save do payment
            DPOPayment dPOPayment = new DPOPayment();
            XmlReader xReader = XmlReader.Create(new StringReader(receivedResponse));
            string tempName = "";

            while (xReader.Read())
            {
                switch (xReader.NodeType)
                {
                    case XmlNodeType.Element:
                        tempName = xReader.Name;
                        break;
                    case XmlNodeType.Text:
                        {
                            if (tempName == "Result")
                            {
                                dPOPayment.Result = xReader.Value;
                            }
                            if (tempName == "ResultExplanation")
                            {
                                dPOPayment.ResultExplanation = xReader.Value;
                            }
                            if (tempName == "TransToken")
                            {
                                dPOPayment.TransToken = xReader.Value;
                            }
                            if (tempName == "TransRef")
                            {
                                dPOPayment.TransRef = xReader.Value;
                            }

                        }
                        break;

                }
            }
            dPOPayment.CDSNumber = cdsnumber;
            dPOPayment.Email = email;
            dPOPayment.Amount = Convert.ToDecimal(amount);
            dPOPayment.TimeStamp = DateTime.Now;
            _cdscDbContext.DPOPayments.Add(dPOPayment);
            _cdscDbContext.SaveChanges();
            string token = dPOPayment.TransToken;

            string finalurl = dpo.PaymentUrl + token;
            if (string.IsNullOrEmpty(token) == true)
            {
                finalurl = dpo.ErrorUrl;
            }
            return (ActionResult)this.Redirect(finalurl);
        }
        public void verifyToken(string companyToken, string transactionToken, string TransID)
        {
            var dpo = _cdscDbContext.DPOes.ToList().FirstOrDefault();
            var xmlmessage = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                    "<API3G>\n" +
                    "  <CompanyToken>" + companyToken + "</CompanyToken>\n" +
                    "  <Request>verifyToken</Request>\n" +
                    "  <TransactionToken>" + transactionToken + "</TransactionToken>\n" +
                    "</API3G>";
            ServicePointManager.ServerCertificateValidationCallback += ValidateRemoteCertificate;
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            string url = dpo.VerifyToken;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            byte[] requestInFormOfBytes = System.Text.Encoding.ASCII.GetBytes(xmlmessage);
            request.Method = "POST";
            request.ContentType = "text/xml;charset=utf-8";
            request.ContentLength = requestInFormOfBytes.Length;
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(requestInFormOfBytes, 0, requestInFormOfBytes.Length);
            requestStream.Close();

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader respStream = new StreamReader(response.GetResponseStream(), System.Text.Encoding.Default);
            var receivedResponse = respStream.ReadToEnd();
            // WriteErrorLog(receivedresponse1+"\n"+receivedResponse);
            respStream.Close();
            response.Close();


            //decode payment
            DPOPaymentResult dPOPaymentResult = new DPOPaymentResult();
            XmlReader xReader = XmlReader.Create(new StringReader(receivedResponse));
            string tempName = "";

            while (xReader.Read())
            {
                switch (xReader.NodeType)
                {
                    case XmlNodeType.Element:
                        tempName = xReader.Name;
                        break;
                    case XmlNodeType.Text:
                        {
                            if (tempName == "Result")
                            {
                                dPOPaymentResult.Result = xReader.Value;
                            }
                            if (tempName == "ResultExplanation")
                            {
                                dPOPaymentResult.ResultExplanation = xReader.Value;
                            }

                            if (tempName == "CustomerName")
                            {
                                dPOPaymentResult.CustomerName = xReader.Value;
                            }
                            if (tempName == "CustomerCredit")
                            {
                                dPOPaymentResult.CustomerCredit = xReader.Value;
                            }
                            if (tempName == "CustomerCreditType")
                            {
                                dPOPaymentResult.CustomerCreditType = xReader.Value;
                            }
                            if (tempName == "TransactionApproval")
                            {
                                dPOPaymentResult.TransactionApproval = xReader.Value;
                            }
                            if (tempName == "TransactionCurrency")
                            {
                                dPOPaymentResult.TransactionCurrency = xReader.Value;
                            }
                            if (tempName == "TransactionAmount")
                            {
                                dPOPaymentResult.TransactionAmount = xReader.Value;
                            }
                            if (tempName == "FraudAlert")
                            {
                                dPOPaymentResult.FraudAlert = xReader.Value;
                            }
                            if (tempName == "FraudExplnation")
                            {
                                dPOPaymentResult.FraudExplnation = xReader.Value;
                            }

                            //
                            if (tempName == "TransactionNetAmount")
                            {
                                dPOPaymentResult.TransactionNetAmount = xReader.Value;
                            }
                            if (tempName == "TransactionSettlementDate")
                            {
                                dPOPaymentResult.TransactionSettlementDate = xReader.Value;
                            }
                            if (tempName == "TransactionRollingReserveAmount")
                            {
                                dPOPaymentResult.TransactionRollingReserveAmount = xReader.Value;
                            }
                            if (tempName == "TransactionRollingReserveDate")
                            {
                                dPOPaymentResult.TransactionRollingReserveDate = xReader.Value;
                            }
                            if (tempName == "CustomerPhone")
                            {
                                dPOPaymentResult.CustomerPhone = xReader.Value;
                            }

                            //
                            if (tempName == "CustomerCountry")
                            {
                                dPOPaymentResult.CustomerCountry = xReader.Value;
                            }
                            if (tempName == "CustomerAddress")
                            {
                                dPOPaymentResult.CustomerAddress = xReader.Value;
                            }
                            if (tempName == "CustomerCity")
                            {
                                dPOPaymentResult.CustomerCity = xReader.Value;
                            }
                            if (tempName == "CustomerZip")
                            {
                                dPOPaymentResult.CustomerZip = xReader.Value;
                            }
                            if (tempName == "MobilePaymentRequest")
                            {
                                dPOPaymentResult.MobilePaymentRequest = xReader.Value;
                            }
                            if (tempName == "AccRef")
                            {
                                dPOPaymentResult.AccRef = xReader.Value;
                            }
                            if (tempName == "TransactionFinalCurrency")
                            {
                                dPOPaymentResult.TransactionFinalCurrency = xReader.Value;
                            }
                            if (tempName == "TransactionFinalAmount")
                            {
                                dPOPaymentResult.TransactionFinalAmount = xReader.Value;
                            }


                        }
                        break;

                }
            }
            dPOPaymentResult.TransactionToken = transactionToken;
            dPOPaymentResult.TimeStamp = DateTime.Now;
            _cdscDbContext.DPOPaymentResults.Add(dPOPaymentResult);
            _cdscDbContext.SaveChanges();

            if (dPOPaymentResult.Result.Replace(" ", "") == "000")
            {
                //deposit to cashtransforex
                var dbop = _cdscDbContext.Database.SqlQuery<DPOPayment>("select  top 1 * from [CDSC].[dbo].[DPOPayments]  where TransToken='" + transactionToken + "' and TransID='" + TransID + "' order by Id desc ").FirstOrDefault();
                //
                CashTrans_forex entity = new CashTrans_forex()
                {
                    Description = "DIRECT PAY DEPOSIT",
                    TransType = "DEPOSIT",
                    TransStatus = "1",
                    Amount = dbop.Amount,
                    CDS_Number = dbop.CDSNumber,
                    DateCreated = DateTime.Now,
                    Currency = dPOPaymentResult.TransactionFinalCurrency

                };
                _cdscDbContext.CashTrans_forex.Add(entity);
                _cdscDbContext.SaveChanges();
            }


        }
        [HttpGet]
        public async Task<ActionResult> DirectPayOnlineResultUrl(string TransID, string CCDapproval, string PnrID, string TransactionToken, string CompanyRef)
        {
            /*FormCollection formCollection
            = formCollection["TransID"].ToString();
             = formCollection["CCDapproval"].ToString();
            = formCollection["PnrID"].ToString();
             = formCollection["TransactionToken"].ToString();
            = formCollection["CompanyRef"].ToString();

                */
            var dpo = _cdscDbContext.DPOes.ToList().FirstOrDefault();
            //transaction verification

            var dbop = _cdscDbContext.Database.ExecuteSqlCommand("Update [CDSC].[dbo].[DPOPayments] set PnrID='" + PnrID + "' ,TransID='" + TransID + "' , CCDapproval='" + CCDapproval + "' , CompanyRef='" + CompanyRef + "' , TransactionToken='" + TransactionToken + "'  where TransToken='" + TransactionToken + "' and isNull(TransID,'0')='0' ");



            verifyToken(dpo.CompanyToken, TransactionToken, TransID);


            return (ActionResult)this.Redirect(dpo.SuccessUrl);
        }

        private static bool ValidateRemoteCertificate(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors error)
        {
            // If the certificate is a valid, signed certificate, return true.
            if (error == System.Net.Security.SslPolicyErrors.None)
            {
                return true;
            }

            //Console.WriteLine("X509Certificate [{0}] Policy Error: '{1}'",
            //    cert.Subject,
            //    error.ToString());

            return false;
        }

        public string OrderPostingMakeNewTest(string company, string security, string orderTrans,
          string orderType, string quantity, string price, string cdsNumber,
          string broker, string source, string tif, string date_ = null, string corp_name = null, string corp_id = null)

        {

            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "L";
            Double basePrice = Double.Parse(price, CultureInfo.InvariantCulture); //;
            var theOrderTrans = "";


            var user_acc = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);
            //check for CRT
            var chk_cdc = cdsDbContext.Database.SqlQuery<Accounts_Clients_Web>("SELECT * FROM Accounts_Clients_Web where CDS_Number='" + cdsNumber + "' ").ToList().FirstOrDefault();
            var acc_type = user_acc.AccountType;

            //check if account is locked
            try
            {
                if (user_acc.AccountState.ToLower().Replace(" ", "") == "locked")
                {
                    return "Your account is locked.Please Contact C-Trade Team.";
                }
            }
            catch (Exception)
            {


            }

            //check if user is sanctioned
            if (SanctionedExsistsval(user_acc.Forenames + " " + user_acc.Surname) == 1)
            {
                return "Order Posting failed.Please Contact C-Trade Team.";
            }

            if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
            {
                theOrderTrans = "BUY";
            }
            else
            {
                theOrderTrans = "SELL";
            }


            long orderNumber = 0;
            var myCompany = "";
            var myBrokerCode = "";


            var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
            if (theBrokerRef != null)
            {
                orderNumber = theBrokerRef.OrderNo + 1;
            }
            else
            {
                orderNumber = 1;
            }

            var theCompnay =
                atsDbContext.para_company.OrderByDescending(x => x.ID)
                    .Where(x => x.Company == company)
                    .FirstOrDefault(x => x.Company == company);

            if (theCompnay == null)
            {
                return "Select a valid company";
            }

            //if (int.Parse(quantity) < 50)
            //{
            //    return "Please Enter Quantity Above 50 ";
            //}

            myCompany = theCompnay.Company;
            var theCds = cdsNumber + "";

            //                var theBroker = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);

            if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
            {
                return "Enter CDS Number";
            }


            var theBroker1 = cdsDbContext.Client_Companies.FirstOrDefault(x => x.Company_Code == broker);
            if (theBroker1 == null)
            {
                return "Enter valid broker";
            }


            //decimal shares = 0;

            //if (acc_type == "i")
            //{
            if (orderTrans.ToString().ToUpper().Equals("SELL"))
            {

                var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                var sql = "select * from cdsc.dbo.PortfolioAll d where d.CDS_Number='" + cdsNumber + "' and Company = '" + myCompany + "' ";
                var shareAvail = 0;
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(sql, connection);
                    cmd.CommandType = CommandType.Text;
                    connection.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        shareAvail = int.Parse(rdr["Net"].ToString());
                        //break;
                    }
                }
                decimal? finsec = 0;
                try
                {
                    finsec = FinsecSharessBal(cdsNumber, myCompany);
                }
                catch (Exception)
                {

                    finsec = 0;
                }
                //validate cdc
                if (string.IsNullOrEmpty(chk_cdc.CDC_Number) == false)
                {
                    decimal? theCashBal = 0;
                    //.SqlQuery<Balancess>("SELECT amt  FROM New_Balz  where cds_number = '" + cdsnumber + "'").FirstOrDefault();
                    var mybal = _cdsDataContext.Database.SqlQuery<Balancess>("SELECT sum(Shares) as amt  FROM [CDS_ROUTER].[dbo].[CDC_Balances] where Cds_number='" + chk_cdc.CDC_Number + "' and Company='" + myCompany + "'").FirstOrDefault();
                    theCashBal = mybal.amt;
                    if (string.IsNullOrEmpty(theCashBal.ToString()) == true)
                    {
                        theCashBal = 0;
                    }
                    if (theCashBal < int.Parse(quantity))
                    {
                        return "You have insufficient units in your account.";
                    }
                }
                else if (string.IsNullOrEmpty(finsec.ToString()) == false)
                {
                    if (finsec < int.Parse(quantity))
                    {
                        return "You have insufficient units in your account.";
                    }
                    else
                    {
                        shareAvail = Convert.ToInt32(finsec);
                    }
                }
                else
                {
                    if (shareAvail < int.Parse(quantity))
                    {
                        return "You have insufficient units in your account.";
                    }
                }
            }
            //}

            //IF BUY ORDER
            var totalAmountToSpent = decimal.Parse("0.0");
            var theQuantity = 0;
            if (quantity != null)
            {
                theQuantity = int.Parse(quantity);
            }
            if (GetTradingPlaform(myCompany).Equals("ZSE"))
            {
                totalAmountToSpent = theQuantity * decimal.Parse(price) * decimal.Parse("1.01693");
            }
            else
            {
                totalAmountToSpent = theQuantity * decimal.Parse(price) * decimal.Parse("1.01693");
            }
            if (!acc_type.Equals("c"))
            {
                if (orderTrans.ToString().ToUpper().Equals("BUY"))
                {
                    var moneyAvail =
                        tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                    if (moneyAvail != null)
                    {
                        var theCashBal =
                            tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                                .Select(x => x.Amount)
                                .Sum();
                        if (theCashBal <= 0 || theCashBal < totalAmountToSpent)
                        {
                            return "You have insufficient funds in your cash account";
                        }
                    }
                    else
                    {
                        return "You have insufficient funds in your cash account";
                    }
                }
            }
            //SAVING TO DB
            var orderStatus = "OPEN";
            if (acc_type == "c")
            {
                orderStatus = "NOT AUTHORISED";
            }
            var createdDate = DateTime.Now;
            var dealBeginDate = DateTime.Now;
            var expiryDate = DateTime.Now; ;
            if (date_ == null)
            {
                expiryDate = DateTime.ParseExact(date_, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            else
            {
                expiryDate = DateTime.Now; ;
            }
            var brokerCode = "";
            var orderAttrib = "";
            var marketBoard = "Normal Board";
            var timeInForce = tif;
            var orderQualifier = "None";
            //var brokerRef = theBroker1.Company_Code + "" + orderNumber;
            var contraBrokerId = "";
            var brokerRef = broker + orderNumber;
            var maxPrice = 0;
            var minPrice = 0;
            var flagOldOrder = false;
            var orderNum = "MOB-" + orderNumber;
            var currency = "$";


            var name = GetCdsNumber(cdsNumber).ToUpper();

            if (company.ToLower().Equals("usd"))
            {
                security = "FOREX";
            }


            if (string.IsNullOrEmpty(chk_cdc.CDC_Number) == false)
            {
                source = "CDC";
                cdsNumber = chk_cdc.CDC_Number;
            }


            var orderLive = new Pre_Order_Live
            {
                OrderType = orderTrans.ToUpper(),
                Company = myCompany,
                SecurityType = security,
                CDS_AC_No = cdsNumber,
                Broker_Code = broker,
                Client_Type = acc_type,
                Tax = 0,
                Shareholder = cdsNumber,
                ClientName = name,
                TotalShareHolding = 0,
                OrderStatus = orderStatus,
                Create_date = createdDate,
                Deal_Begin_Date = dealBeginDate,
                Expiry_Date = expiryDate,
                Quantity = theQuantity,
                BasePrice = basePrice,
                AvailableShares = 0,
                OrderPref = orderPref,
                OrderAttribute = orderAttrib,
                Marketboard = marketBoard,
                TimeInForce = timeInForce,
                OrderQualifier = orderQualifier,
                BrokerRef = brokerRef,
                ContraBrokerId = contraBrokerId,
                MaxPrice = maxPrice,
                MiniPrice = minPrice,
                Flag_oldorder = flagOldOrder,
                OrderNumber = orderNum,
                Currency = currency,
                trading_platform = GetTradingPlaform(myCompany),
                Source = source,
                FOK = false,
                Affirmation = true,
                Custodian = chk_cdc.BIC
            };

            //save to cdsc tempPreorderLive too
            CashTrans orderCashTrans = null;

            orderCashTrans = new CashTrans
            {
                Description = "BUY - Order",
                TransType = "BUY",
                TransStatus = "1",
                Amount = -totalAmountToSpent,
                CDS_Number = cdsNumber,
                DateCreated = DateTime.Now
            };


            atsDbContext.Pre_Order_Live.Add(orderLive);
            atsDbContext.SaveChanges();
            if (orderTrans.ToString().ToUpper().Equals("BUY"))
            {

                tempDbContext.CashTrans.Add(orderCashTrans);
                tempDbContext.SaveChanges();
            }


            return "1";





        }
        public string OrderPostingMakeNewMe(string company, string security, string orderTrans,
           string orderType, string quantity, string price, string cdsNumber,
           string broker, string source, string amountValue, string tif, string date_ = null, string corp_name = null, string corp_id = null)

        {

            var today = DateTime.Today.ToString("yyyy-MM-dd");
            var ret = "";
            var atsDbContext = new AtsDbContext();
            var cdsDbContext = new CdDataContext();
            var tempDbContext = new cdscDbContext();
            var orderPref = "L";
            Double basePrice = Double.Parse(price, CultureInfo.InvariantCulture); //;
            var theOrderTrans = "";

            try
            {
                var user_acc = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);
                //check for CRT
                var chk_cdc = cdsDbContext.Database.SqlQuery<Accounts_Clients_Web>("SELECT * FROM Accounts_Clients_Web where CDS_Number='" + cdsNumber + "' ").ToList().FirstOrDefault();
                var acc_type = user_acc.AccountType;

                try
                {
                    //check if account is locked
                    if (user_acc.AccountState.ToLower().Replace(" ", "") == "locked")
                    {
                        return "Your account is locked.Please Contact C-Trade Team.";
                    }
                }
                catch (Exception)
                {


                }

                //check if user is sanctioned
                if (SanctionedExsistsval(user_acc.Forenames + " " + user_acc.Surname) == 1)
                {
                    return "Order Posting failed.Please Contact C-Trade Team.";
                }

                if (orderTrans != null && orderTrans.Trim().Equals("Buy"))
                {
                    theOrderTrans = "BUY";
                }
                else
                {
                    theOrderTrans = "SELL";
                }


                long orderNumber = 0;
                var myCompany = "";
                var myBrokerCode = "";


                var theBrokerRef = atsDbContext.Pre_Order_Live.OrderByDescending(x => x.OrderNo).FirstOrDefault();
                if (theBrokerRef != null)
                {
                    orderNumber = theBrokerRef.OrderNo + 1;
                }
                else
                {
                    orderNumber = 1;
                }

                var theCompnay =
                    atsDbContext.para_company.OrderByDescending(x => x.ID)
                        .Where(x => x.Company == company)
                        .FirstOrDefault(x => x.Company == company);

                if (theCompnay == null)
                {
                    return "Select a valid company";
                }

                //if (int.Parse(quantity) < 50)
                //{
                //    return "Please Enter Quantity Above 50 ";
                //}

                myCompany = theCompnay.Company;
                var theCds = cdsNumber + "";

                //                var theBroker = cdsDbContext.Accounts_Clients.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                if (GetCdsNumber(cdsNumber) == "0" || GetCdsNumber(cdsNumber) == "1")
                {
                    return "Enter CDS Number";
                }


                var theBroker1 = cdsDbContext.Client_Companies.FirstOrDefault(x => x.Company_Code == broker);
                if (theBroker1 == null)
                {
                    return "Enter valid broker";
                }


                //decimal shares = 0;

                //if (acc_type == "i")
                //{
                if (orderTrans.ToString().ToUpper().Equals("SELL"))
                {

                    var connectionString = ConfigurationManager.ConnectionStrings["cdscDbContext"].ConnectionString;
                    var sql = "select * from cdsc.dbo.PortfolioAll d where d.CDS_Number=@cdsNumber and Company =@myCompany ";
                    var shareAvail = 0;
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand(sql, connection);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@cdsNumber", cdsNumber);
                        cmd.Parameters.AddWithValue("@myCompany", myCompany);
                        connection.Open();
                        SqlDataReader rdr = cmd.ExecuteReader();
                        while (rdr.Read())
                        {
                            if (security.Trim().ToString() == "UNIT TRUST")
                            {
                                shareAvail = int.Parse(rdr["totAllShares"].ToString());
                            }
                            else
                            {
                                shareAvail = int.Parse(rdr["Net"].ToString());
                            }
                        }
                    }
                    decimal? finsec = 0;
                    try
                    {
                        finsec = FinsecSharessBal(cdsNumber, myCompany);
                    }
                    catch (Exception)
                    {

                        finsec = 0;
                    }
                    if (string.IsNullOrEmpty(shareAvail.ToString()) == true)
                    {
                        shareAvail = 0;
                    }

                    var trading = GetTradingPlaform(myCompany).ToLower();
                    //if (shareAvail < int.Parse(quantity))
                    //{
                    //    return "You have insufficient units in your account.";
                    //}
                    if (string.IsNullOrEmpty(finsec.ToString()) == false && trading == "finsec")
                    {
                        if (finsec < int.Parse(quantity))
                        {
                            return "You have insufficient units in your account. shareAvail" + shareAvail + "int.Parse(quantity) " + int.Parse(quantity);
                        }
                        else
                        {
                            shareAvail = Convert.ToInt32(finsec);
                        }
                    }
                    else
                    {
                        if (shareAvail < int.Parse(quantity))
                        {
                            return int.Parse(quantity) + "You have insufficient units in your account.shareAvail" + shareAvail;
                        }
                    }
                }
                //}

                //IF BUY ORDER
                var totalAmountToSpent = decimal.Parse("0.0");
                var theQuantity = 0;
                if (quantity != null)
                {
                    theQuantity = int.Parse(quantity);
                }
                if (GetTradingPlaform(myCompany).Equals("ZSE"))
                {
                    //totalAmountToSpent = theQuantity * decimal.Parse(price) ;
                }
                else
                {
                    //totalAmountToSpent = theQuantity * decimal.Parse(price);
                }
                if (!acc_type.Equals("c"))
                {
                    if (orderTrans.ToString().ToUpper().Equals("BUY"))
                    {
                        var moneyAvail =
                            tempDbContext.CashTrans.FirstOrDefault(x => x.CDS_Number == cdsNumber);

                        if (moneyAvail != null)
                        {
                            var theCashBal =
                               tempDbContext.CashTrans.Where(x => x.CDS_Number == cdsNumber)
                                    .Select(x => x.Amount)
                                    .Sum();
                            if (theCashBal <= 0 || theCashBal < Decimal.Parse(amountValue))
                            {
                                return "You have insufficient funds in your cash account theCashBal" + theCashBal + " totalAmountToSpent:" + totalAmountToSpent;
                            }
                        }
                        else
                        {
                            return "You have insufficient funds in your cash account moneyAvail" + moneyAvail;
                        }
                    }
                }
                //SAVING TO DB
                var orderStatus = "OPEN";
                if (acc_type == "c")
                {
                    orderStatus = "NOT AUTHORISED";
                }
                var createdDate = DateTime.Now;
                var dealBeginDate = DateTime.Now;
                var expiryDate = DateTime.Now; ;
                if (date_ == null)
                {
                    expiryDate = DateTime.ParseExact(date_, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                else
                {
                    expiryDate = DateTime.Now; ;
                }
                var brokerCode = "";
                var orderAttrib = "";
                var marketBoard = "Normal Board";
                var timeInForce = tif;
                var orderQualifier = "None";
                //var brokerRef = theBroker1.Company_Code + "" + orderNumber;
                var contraBrokerId = "";
                var brokerRef = broker + orderNumber;
                var maxPrice = 0;
                var minPrice = 0;
                var flagOldOrder = false;
                var orderNum = "MOB-" + orderNumber;
                var currency = "$";


                var name = GetCdsNumber(cdsNumber).ToUpper();

                if (company.ToLower().Equals("usd"))
                {
                    security = "FOREX";
                }

                try
                {
                    if (string.IsNullOrEmpty(chk_cdc.CDC_Number) == false)
                    {
                        source = "CDC";
                        cdsNumber = chk_cdc.CDC_Number;
                    }


                    var orderLive = new Pre_Order_Live
                    {
                        OrderType = orderTrans.ToUpper(),
                        Company = myCompany,
                        SecurityType = security,
                        CDS_AC_No = cdsNumber,
                        Broker_Code = broker,
                        Client_Type = acc_type,
                        Tax = 0,
                        Shareholder = cdsNumber,
                        ClientName = name,
                        TotalShareHolding = 0,
                        OrderStatus = orderStatus,
                        Create_date = createdDate,
                        Deal_Begin_Date = dealBeginDate,
                        Expiry_Date = expiryDate,
                        Quantity = theQuantity,
                        BasePrice = basePrice,
                        AvailableShares = 0,
                        OrderPref = orderPref,
                        OrderAttribute = orderAttrib,
                        Marketboard = marketBoard,
                        TimeInForce = timeInForce,
                        OrderQualifier = orderQualifier,
                        BrokerRef = brokerRef,
                        ContraBrokerId = contraBrokerId,
                        MaxPrice = maxPrice,
                        MiniPrice = minPrice,
                        Flag_oldorder = flagOldOrder,
                        OrderNumber = orderNum,
                        Currency = currency,
                        trading_platform = GetTradingPlaform(myCompany),
                        Source = source,
                        FOK = false,
                        AmountValue = Decimal.Parse(amountValue),
                        Affirmation = true,
                        Custodian = chk_cdc.BIC
                    };

                    //save to cdsc tempPreorderLive too
                    CashTrans orderCashTrans = null;

                    orderCashTrans = new CashTrans
                    {
                        Description = "BUY - Order",
                        TransType = "BUY",
                        TransStatus = "1",
                        Amount = -Decimal.Parse(amountValue),
                        CDS_Number = cdsNumber,
                        DateCreated = DateTime.Now
                    };

                    try
                    {

                        atsDbContext.Pre_Order_Live.Add(orderLive);
                        atsDbContext.SaveChanges();
                        if (orderTrans.ToString().ToUpper().Equals("BUY"))
                        {

                            tempDbContext.CashTrans.Add(orderCashTrans);
                            tempDbContext.SaveChanges();
                        }


                        return "1";
                    }
                    catch (Exception e)
                    {
                        return e.Message + " \n " + e.StackTrace; //"Error occured please contact support at ctrade@escrowgroup.org";
                    }
                }
                catch (Exception e)
                {
                    return e.Message + " \n " + e.StackTrace; //"Error occured please contact support at ctrade@escrowgroup.org";
                }

            }
            catch (Exception ex)
            {
                return ex.Message + " \n " + ex.StackTrace; //"Error occured please contact support at ctrade@escrowgroup.org";
            }
        }


        ///Issuer App


        private JsonResult getPrices(String company)
        {
            return Json("", JsonRequestBehavior.AllowGet);
        }
        private JsonResult getDividend(String company)
        {
            return Json("", JsonRequestBehavior.AllowGet);
        }
        //New On Investment Club
        public JsonResult addClubRequests(string gcdsnum, string mcdsnum, string gphone, string gname, string type, string reqBy, string mphone)
        {
            SqlConnection con = new SqlConnection(connectionStringCDS_Router);
            string query = "insert into CDS_ROUTER.dbo.investiment_club_requests values('" + mcdsnum + "','" + gcdsnum + "', '" + gphone + "',0,0,0,'" + type + "', getDate(),'" + gname + "','" + reqBy + "','" + mphone + "')";

            var not_registered = true;

            var req = _cdDataContext.requests_.FirstOrDefault(x=> x.req_cds_number == mcdsnum.Trim() && x.req_group_cds_number == gcdsnum.Trim());

            var mem = _cdDataContext.members.FirstOrDefault(x => x.member_cds_number == mcdsnum.Trim() && x.club_cds_number == gcdsnum.Trim());

            if(mem == null)
            {
                if (req != null) not_registered = false;

                SqlCommand cmd = new SqlCommand(query, con);
                try
                {
                    CustomResponses cr;
                    if (not_registered)
                    {
                        con.Open();
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();

                        if (type == "i")
                        {
                            cr = new CustomResponses()
                            {
                                status = true,
                                message = "Request Successfully Sent,Awaiting Member's Approval"
                            };
                        }
                        else if (type == "j")
                        {
                            cr = new CustomResponses()
                            {
                                status = true,
                                message = "Request Successfully Sent,Awaiting Chairman's Approval"
                            };
                        }
                        else
                        {
                            cr = new CustomResponses()
                            {
                                status = false,
                                message = "Failed To Validate Type.Please Contact CTrade Team"
                            };
                        }
                        con.Close();
                        return Json(cr, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        cr = new CustomResponses()
                        {
                            status = true,
                            message = "A Request Had Aready Been Sent."
                        };
                        return Json(cr, JsonRequestBehavior.AllowGet);
                    }
                }
                catch (SqlException e)
                {
                    CustomResponses cr = new CustomResponses()
                    {
                        status = false,
                        message = "Failed To Process Your Request.Please Try Again Later"
                    };
                    return Json(cr, JsonRequestBehavior.AllowGet);
                }
            }else
            {
                CustomResponses cr = new CustomResponses()
                {
                    status = false,
                    message = "This Account Is Already A Member Of This Club"
                };
                return Json(cr, JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult checkTermsAndConditionsClubs(string cdsnumber)
        {
            var terms = _cdDataContext.clubs_ts_n_cs.FirstOrDefault(x => x.cdsnumber == cdsnumber.Trim());
            CustomResponses cr;
            if (terms != null)
            {
                cr = new CustomResponses
                {
                    status = true,
                    message = "Members Already Accepted The Terms."
                };
            }
            else
            {

                cr = new CustomResponses
                {
                    status = false,
                    message = "Not Yet Accepted Terms And Conditions."
                };

            }
            return Json(cr, JsonRequestBehavior.AllowGet);
        }
        public JsonResult acceptTermsAndCs(string cdsnumber)
        {
            try
            {
                string sqlx = "insert into clubs_ts_n_cs values('"+cdsnumber+"',1)";

                using (SqlConnection connectionsx = new SqlConnection(connectionStringCDS_Router))
                {
                    SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                    connectionsx.Open();
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    connectionsx.Close();

                    CustomResponses cr = new CustomResponses
                    {
                        status = true,
                        message = "Accepted Terms And Conditions"
                    };

                    return Json(cr, JsonRequestBehavior.AllowGet);

                }

            }
            catch (Exception e)
            {
                Console.Write(e.Message.ToString());
                CustomResponses cr = new CustomResponses
                {
                    status = false,
                    message = "Failed To Validate Request Type"
                };
                return Json(cr, JsonRequestBehavior.AllowGet);

            }
        }
        public JsonResult checkRequests(string cdsnumber, string type="",string special="",string email = "")
        {
            string sql;
            if (type == "i")
            {
                sql = "select ar.req_group_name,ar.req_updated_date,ar.req_group_cds_number as cds,concat(aw.Forenames,' ',aw.Surname)as names,aw.Email,aw.Tel, (select count(id) from CDS_ROUTER.dbo.investiment_club_requests where req_group_cds_number = ar.req_group_cds_number) as members from CDS_ROUTER.dbo.investiment_club_requests ar left join CDS_ROUTER.dbo.Accounts_Clients_Web aw on ar.req_by = aw.CDS_Number where req_cds_number = '" + cdsnumber + "' and req_type = 'i' and req_accepted = 0 and req_rejected = 0 and req_rejectected_count < 4";
            }
            else if (type == "j")
            {
                sql = "select ar.req_group_name,ar.req_updated_date,ar.req_cds_number as cds,concat(aw.Forenames,' ',aw.Surname)as names,aw.Email,aw.Tel from CDS_ROUTER.dbo.investiment_club_requests ar left join CDS_ROUTER.dbo.Accounts_Clients_Web aw on ar.req_cds_number = aw.CDS_Number where req_group_cds_number = '" + cdsnumber + "' and req_type = 'j' and req_accepted = 0 and req_rejected = 0 and req_rejectected_count < 4";
            }else if (special == "URC")
            {
                sql = "select club_cds_number as cds,dateposted as req_updated_date,Forenames as names,Forenames as req_group_name, aw.Email ,aw.Tel from investmentclubs_requests_urc left join Accounts_Clients_Web aw on CDS_Number = club_cds_number where inv_email = '"+email+"' and club_cds_number = '"+cdsnumber+"' and accepted = 0  and rejected = 0";
            }
            else
            {
                CustomResponses cr = new CustomResponses
                {
                    status = true,
                    message = "Failed To Validate Request Type"
                };
                return Json(cr, JsonRequestBehavior.AllowGet);
            }


            var shareAllocations = new List<ClubRequests>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    ClubRequests shareAllocation = new ClubRequests
                    {

                        cds = rdr["cds"].ToString(),
                        name = rdr["names"].ToString(),
                        clubname = rdr["req_group_name"].ToString(),
                        email = rdr["Email"].ToString(),
                        phone = rdr["Tel"].ToString(),
                        date = rdr["req_updated_date"].ToString(),



                    };
                    shareAllocations.Add(shareAllocation);


                }

                connection.Close();
            }

            return Json(shareAllocations, JsonRequestBehavior.AllowGet);

        }
        public JsonResult searchCtradeUser(string email)
        {
            var sql = "select concat(Forenames,' ',Surname) as fname,CDS_Number,DOB,tel,Email from CDS_ROUTER.dbo.Accounts_Clients_Web acw where AccountType = 'i' and Email like '%" + email + "%'";

            var users = new List<CTradeUser>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    //string password = rdr["Password"].ToString();
                    //int id = int.Parse(rdr["Id"].ToString());
                    CTradeUser user = new CTradeUser
                    {

                        name = rdr["fname"].ToString(),
                        cdsnumber = rdr["CDS_Number"].ToString(),
                        phone = rdr["tel"].ToString(),
                        email = rdr["Email"].ToString()

                    };
                    users.Add(user);


                }

                connection.Close();
            }

            return Json(users, JsonRequestBehavior.AllowGet);
        }
        public JsonResult myInvestmentClubs(string cdsNumber)
        {
            var sql = "select cm.member_title,aw.Forenames,aw.CDS_Number,aw.Tel,aw.DOB,cat.investiments_noti,cat.contributions_noti,cat.exiting_noti,cat.joining_noti,cat.group_feed_noti,(select top 1 welcome_message from CDS_ROUTER.dbo.ctrade_investment_clubs_members where club_cds_number = cm.club_cds_number and member_title = 'CHAIRMAN') as wmessage,readMessage,last_updated from CDS_ROUTER.dbo.ctrade_investment_clubs_members cm left join CDS_ROUTER.dbo.Accounts_Clients_Web aw  on aw.CDS_Number = cm.club_cds_number left join  CDS_ROUTER.dbo.investment_clubs_activity_trackor cat on cat.group_cds_number = cm.club_cds_number and cat.member_cds_number = cm.member_cds_number where cm.member_cds_number = '"+cdsNumber+"' and club_active = 1 and member_active = 1 order by last_updated desc";
            var clubs = new List<InvestmentClub>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    InvestmentClub user = new InvestmentClub
                    {
                        
                        title = rdr["member_title"].ToString(),
                        clubname = rdr["Forenames"].ToString(),
                        dateCreated = rdr["DOB"].ToString(),
                        cdsnumber = rdr["CDS_Number"].ToString(),
                        nInv = rdr["investiments_noti"].ToString(),
                        nCont = rdr["contributions_noti"].ToString(),
                        nFeed = rdr["group_feed_noti"].ToString(),
                        nJoin = rdr["joining_noti"].ToString(),
                        nExit = rdr["exiting_noti"].ToString(),
                        message = rdr["wmessage"].ToString(),
                        readMessage = bool.Parse(rdr["readMessage"].ToString()),
                        last_updated = DateTime.Parse(rdr["last_updated"].ToString()).ToString("dd MMM yyyy")

                    };
                    clubs.Add(user);


                }

                connection.Close();
            }

            return Json(clubs, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getNotifications(string mcdsNumber,string gcdsnumber)
        {
            var sql = "select * from cds_router.dbo.investment_clubs_activity_trackor where member_cds_number = '"+mcdsNumber+"' and group_cds_number = '"+gcdsnumber+"'";
            var clubs = new List<Notifications>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Notifications user = new Notifications
                    {
                        nInv = rdr["investiments_noti"].ToString(),
                        nCont = rdr["contributions_noti"].ToString(),
                        nFeed = rdr["group_feed_noti"].ToString(),
                        nJoin = rdr["joining_noti"].ToString(),
                        nExit = rdr["exiting_noti"].ToString(),
                    };
                    clubs.Add(user);


                }

                connection.Close();
            }

            return Json(clubs, JsonRequestBehavior.AllowGet);
        }
        public JsonResult clubsAvailableOnCtrade(string cdsnumber)
        {
            var sql = "select sum(isnull(Amount,0)) as cashbal,sum((isnull(currePrice,0) * (isnull(totAllShares,0))))as portfolio,mobile,Forenames,aw.CDS_Number,DOB,(select count(id) from cds_router.dbo.ctrade_investment_clubs_members where club_cds_number = aw.CDS_Number) as members from CDS_ROUTER.dbo.ctrade_investment_clubs_members right join CDS_ROUTER.dbo.Accounts_Clients_Web aw on CDS_Number=club_cds_number left join cdsc.dbo.PortfolioAll pa on pa.CDS_Number = aw.CDS_Number left join cdsc.dbo.CashTransGroups on aw.CDS_Number = CDS_NumberGroup where member_title = 'CHAIRMAN' and aw.cds_number not in(select club_cds_number from ctrade_investment_clubs_members where member_cds_number = '"+cdsnumber+"') and isPublic = 1 group by mobile,Forenames,aw.CDS_Number,DOB";

            var clubsAvailable = new List<CTradeInvestmentClubs>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    CTradeInvestmentClubs ctradeClubs = new CTradeInvestmentClubs
                    {

                        name = rdr["Forenames"].ToString(),
                        dateCreated = rdr["DOB"].ToString(),
                        cdsnumber = rdr["CDS_Number"].ToString(),
                        club_phone = rdr["mobile"].ToString(),
                        members = rdr["members"].ToString(),
                        portfolio = rdr["portfolio"].ToString(),
                        cash = rdr["cashbal"].ToString(),

                    };
                    clubsAvailable.Add(ctradeClubs);
                }

                connection.Close();
            }

            return Json(clubsAvailable, JsonRequestBehavior.AllowGet);
        }
        public JsonResult acceptRequests(string gname, string gcdsnum, string mcdsnum, string gphone, string mphone, string confirm,string spercial = "",string email = "")
        {
            SqlConnection con = new SqlConnection(connectionStringCDS_Router);
            SqlCommand cmd;
            string query;
            if (confirm == "YES")
            {
                    query = "insert into CDS_ROUTER.dbo.ctrade_investment_clubs_members values('" + gname + "','" + gcdsnum + "','" + mcdsnum + "','" + gphone + "','1','1','MEMBER','" + mphone + "',GetDate(),'','',0,getdate())";
                    cmd = new SqlCommand(query, con);
            }
            else
            {
                if (spercial == "URC")
                {
                    query = "update  investmentclubs_requests_urc set rejected = 1 where club_cds_number = '"+gcdsnum+"' and inv_email = '"+email+"'";
                    cmd = new SqlCommand(query, con);
                }
                else
                {
                    query = "update CDS_ROUTER.dbo.investiment_club_requests set req_rejected = 1,req_rejectected_count = req_rejectected_count + 1 where req_group_cds_number = '" + gcdsnum + "' and req_cds_number = '" + mcdsnum + "'";
                    cmd = new SqlCommand(query, con);
                }

            }
            var mem = _cdDataContext.members.FirstOrDefault(x => x.member_cds_number == mcdsnum.Trim() && x.club_cds_number == gcdsnum.Trim());
            if (mem == null)
            {
                try
                {
                    con.Open();
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    con.Close();

                    if (spercial == "URC")
                    {
                        query = "update  investmentclubs_requests_urc set accepted = 1 where club_cds_number = '" + gcdsnum + "' and inv_email = '" + email + "'";

                    }
                    else
                    {
                        query = "update CDS_ROUTER.dbo.investiment_club_requests set req_accepted = 1 where req_group_cds_number = '"+gcdsnum+"' and req_cds_number = '"+mcdsnum+"'";
                    }
                    
                    cmd = new SqlCommand(query, con);
                    con.Open();
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    CustomResponses cr;
                    if (confirm == "YES")
                    {
                        cr = new CustomResponses()
                        {
                            status = true,
                            message = "Request Has Been Accepted Successfully!"
                        };

                        regForActivityTracking(mcdsnum, gcdsnum);
                        recordClubActivity(gcdsnum, "j");
                    }
                    else
                    {
                        cr = new CustomResponses()
                        {
                            status = true,
                            message = "You Have Rejected This Request."
                        };
                    }
                    con.Close();
                    return Json(cr, JsonRequestBehavior.AllowGet);
                }
                catch (SqlException e)
                {
                    CustomResponses cr = new CustomResponses()
                    {
                        status = false,
                        message = "Failed To Process Your Request.Please Try Again Later"
                    };
                    return Json(cr, JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                CustomResponses cr = new CustomResponses()
                {
                    status = true,
                    message = "This Account Is Already A Part Of This Club"
                };
                return Json(cr, JsonRequestBehavior.AllowGet);
            }
        }
        private bool recordClubActivity(string gcdsnumber, string type)
        {
            try
            {
                string sqlx = "Declare @g_cds_number nvarchar(MAX) = '" + gcdsnumber + "' Declare @activity_type nchar = '" + type + "'if @activity_type = 'c' Begin update investment_clubs_activity_trackor set contributions_noti = contributions_noti + 1 where group_cds_number = @g_cds_number End if @activity_type = 'i' Begin update investment_clubs_activity_trackor set investiments_noti = investiments_noti + 1 where group_cds_number = @g_cds_number End if @activity_type = 'f' Begin update investment_clubs_activity_trackor set group_feed_noti = group_feed_noti + 1 where group_cds_number = @g_cds_number End if @activity_type = 'j' Begin update investment_clubs_activity_trackor set joining_noti = joining_noti + 1 where group_cds_number = @g_cds_number End if @activity_type = 'e' Begin update investment_clubs_activity_trackor set exiting_noti = exiting_noti + 1 where group_cds_number = @g_cds_number End update investment_clubs_activity_trackor set last_updated = GETDATE() where group_cds_number = @g_cds_number";

                using (SqlConnection connectionsx = new SqlConnection(connectionStringCDS_Router))
                {
                    SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                    connectionsx.Open();
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    connectionsx.Close();
                    return true;

                }

            }
            catch (Exception e)
            {
                Console.Write(e.Message.ToString());
                return false;

            }
        }

        private int doRequestsV2(string gcdsnum, string mcdsnum, string gphone, string gname, string type, string reqBy, string mphone)
        {
            SqlConnection con = new SqlConnection(connectionStringCDS_Router);
            string query = "insert into CDS_ROUTER.dbo.investiment_club_requests values('" + mcdsnum + "','" + gcdsnum + "', '" + gphone + "',0,0,0,'" + type + "', getDate(),'" + gname + "','" + reqBy + "','" + mphone + "')";

            var not_registered = true;

            var req = _cdDataContext.requests_.FirstOrDefault(x => x.req_cds_number == mcdsnum.Trim() && x.req_group_cds_number == gcdsnum.Trim());

            var mem = _cdDataContext.members.FirstOrDefault(x => x.member_cds_number == mcdsnum.Trim() && x.club_cds_number == gcdsnum.Trim());

            if (mem == null)
            {
                if (req != null) not_registered = false;
                int cr;
                SqlCommand cmd = new SqlCommand(query, con);
                try
                {
                    
                    if (not_registered)
                    {
                        con.Open();
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();

                        cr = 1;//success
                        con.Close();
                        return cr;
                    }
                    else
                    {
                        cr = 2;//requested already
                        return cr;
                    }
                }
                catch (SqlException e)
                {
                    cr = 0;
                    return cr;
                }
            }
            else
            {
                
                return 3;// already a member
            }
        }

        public JsonResult addClubRequestsURC(string gcdsnumber,string fname, string sname, string email, string phone, string clubphone,string clubname,string chcdsnumber)
        {
            var rets = _cdDataContext.Accounts_Clients.FirstOrDefault(x => x.Email.Trim() == email.Trim());

            var urc = _cdDataContext.request_urc.FirstOrDefault(x => x.club_cds_number == gcdsnumber.Trim() && x.inv_email == email.Trim());

            if (rets != null)
            {
                int test_req = doRequestsV2(gcdsnumber,rets.CDS_Number,clubphone,clubname,"i",chcdsnumber,rets.Mobile);
                CustomResponses cr;

                switch (test_req)
                {
                    case 0:
                        cr = new CustomResponses()
                        {
                            status = true,
                            message = "Something Went Wrong While Processing Your Request.Please Try Again Later!"
                        };
                        break;
                    case 1:
                        cr = new CustomResponses()
                        {
                            status = true,
                            message = "An Invitation Has Been Sent To The CTrade Account With This Email '" + email + "'"
                        };
                        break;
                    case 2:
                        cr = new CustomResponses()
                        {
                            status = true,
                            message = "An Invitation Has Been Sent Already For This Account!"
                        };
                        break;
                    case 3:
                        cr = new CustomResponses()
                        {
                            status = true,
                            message = "This Account Is Already A Member Of This Club!"
                        };
                        break;
                    default:
                        cr = new CustomResponses()
                        {
                            status = true,
                            message = "Something Went Wrong While Processing Your Request.Please Try Again Later!"
                        };
                        break;
                }
                return Json(cr, JsonRequestBehavior.AllowGet);
            }
            else
            {
                if (urc == null)
                {

                    try
                    {
                        string sqlx = "insert into investmentclubs_requests_urc values('" + gcdsnumber + "','" + fname + "','" + sname + "','" + email + "','" + phone + "',0,GETDATE(),'" + clubphone + "',0);";

                        using (SqlConnection connectionsx = new SqlConnection(connectionStringCDS_Router))
                        {
                            SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                            connectionsx.Open();
                            cmd.CommandType = CommandType.Text;
                            cmd.ExecuteNonQuery();
                            connectionsx.Close();
                            CustomResponses cr = new CustomResponses()
                            {
                                status = true,
                                message = "Invitation Sent Successfully Awaiting Member Acceptance!"
                            };

                            return Json(cr, JsonRequestBehavior.AllowGet);

                        }

                    }
                    catch (Exception e)
                    {
                        CustomResponses cr = new CustomResponses()
                        {
                            status = false,
                            message = "Could Not Send Invitation At The Moment"
                        };

                        return Json(cr, JsonRequestBehavior.AllowGet);

                    }
                }
                else
                {
                    CustomResponses cr = new CustomResponses()
                    {
                        status = false,
                        message = "An Invitation Had Already Been Sent"
                    };

                    return Json(cr, JsonRequestBehavior.AllowGet);
                }
            }
            

        }



        private bool recordActivityViewed(string mcdsnumber, string gcdsnumber, string type)
        {
            try
            {
                string sqlx = "declare @mcdsnumber nvarchar(MAX) = '" + mcdsnumber + "',@g_cds_number nvarchar(Max)= '" + gcdsnumber + "',@activity_type nchar(1) = '" + type + "'Begin update investment_clubs_activity_trackor set contributions_noti = 0 where group_cds_number = @g_cds_number and member_cds_number = @mcdsnumber End if @activity_type = 'i' Begin update investment_clubs_activity_trackor set investiments_noti = 0 where group_cds_number = @g_cds_number and member_cds_number = @mcdsnumber End if @activity_type = 'f' Begin update investment_clubs_activity_trackor set group_feed_noti = 0 where group_cds_number = @g_cds_number and member_cds_number = @mcdsnumber End if @activity_type = 'm' Begin update investment_clubs_activity_trackor set joining_noti = 0 where group_cds_number = @g_cds_number and member_cds_number = @mcdsnumber End if @activity_type = 'm' Begin update investment_clubs_activity_trackor set exiting_noti = 0 where group_cds_number = @g_cds_number and member_cds_number = @mcdsnumber End  if @activity_type = 'c' Begin update investment_clubs_activity_trackor set contributions_noti = 0 where group_cds_number = @g_cds_number and member_cds_number = @mcdsnumber End";

                using (SqlConnection connectionsx = new SqlConnection(connectionStringCDS_Router))
                {
                    SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                    connectionsx.Open();
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    connectionsx.Close();
                    return true;
                }

            }
            catch (Exception e)
            {
                Console.Write(e.Message.ToString());
                return false;

            }
        }
        private bool regForActivityTracking(string mcdsnumber, string gcdsnumber)
        {
            try
            {
                string sqlx = "Declare @m_cds_number nvarchar(MAX) = '" + mcdsnumber + "' Declare @g_cds_number nvarchar(MAX) = '" + gcdsnumber + "' insert into investment_clubs_activity_trackor values(@m_cds_number,@g_cds_number,0,0,0,0,0,GETDATE())";

                using (SqlConnection connectionsx = new SqlConnection(connectionStringCDS_Router))
                {
                    SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                    connectionsx.Open();
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    connectionsx.Close();
                    return true;

                }

            }
            catch (Exception e)
            {
                Console.Write(e.Message.ToString());
                return false;

            }
        }
        public JsonResult createANewInvestmentClub(string creatorCds, string creatorPhone, string cname, string cwelcomeMessagwe, string isPublic, string creatorEmail)
        {

            string ran = RandomNumber(100000, 90000000).ToString() + "/" + RandomNumber(1000, 90000).ToString() + RandomString(4, true);

            CustomResponses cr;

            var mem = _cdDataContext.members.FirstOrDefault(x => x.club_name == cname.Trim());

            if (mem != null)
            {
                cr = new CustomResponses()
                {
                    status = false,
                    message = "Club Name Is already Taken"
                };
                return Json(cr, JsonRequestBehavior.AllowGet);
            }

            SqlConnection con = new SqlConnection(connectionStringCDS_Router);
            string query = query = "insert into CDS_ROUTER.dbo.ctrade_investment_clubs_members values('" + cname + "','" + ran + "','" + creatorCds + "','" + creatorPhone + "','1','1','CHAIRMAN','" + creatorPhone + "',GetDate(),'" + cwelcomeMessagwe + "','" + isPublic + "',0,getdate())";
            SqlCommand cmd = new SqlCommand(query, con);

            try
            {
                con.Open();
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
                if (investmentClubsClient(cname, creatorPhone, ran, creatorEmail))
                {
                    if (regForActivityTracking(creatorCds, ran))
                    {
                        cr = new CustomResponses()
                        {
                            status = true,
                            message = "Your Investment Club Has Been Created Successfully"
                        };
                    }
                    else
                    {
                        cr = new CustomResponses()
                        {
                            status = true,
                            message = "Your Investment Club Has Been Created,But Didn't Sit Right Please Contact The CTrade Team"
                        };
                    }
                }
                else
                {
                    cr = new CustomResponses()
                    {
                        status = true,
                        message = "Your Investment Club Has Been Created,But Didn't Sit Right Please Contact The CTrade Team"
                    };
                    regForActivityTracking(creatorCds, ran);
                }

                return Json(cr, JsonRequestBehavior.AllowGet);
            }
            catch (SqlException e)
            {
                cr = new CustomResponses()
                {
                    status = false,
                    message = "Failed To Process Your Request.Please Try Again Later"
                };
                return Json(cr, JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult allClubMembers(string cdsNumber,string mcdsnumber)
        {
            var sql = "select distinct member_cds_number,CONCAT(Forenames, ' ', Surname) as Names,member_phone,member_joined,member_title,ISNULL(((select isnull(sum(Shares), 0.00) from CDS_ROUTER.dbo.trans_Groups where CDS_Number = member_cds_number and groupid = club_cds_number) * (SELECT K.Price FROM(SELECT ticker as Company,Current_price as Price FROM CDS_ROUTER.DBO.ZSE_market_data union SELECT company, [Average Price] as Price FROM testcds_ROUTER.DBO.fin_price )K where K.Company = tg.Company)),0.00) as TotalPortfolio,(select isnull(sum(isnull(Amount, 0)), 0) from CDSc.dbo.CashTransGroups ctg where CDS_Number = im.member_cds_number and CDS_NumberGroup = im.club_cds_number) as amount from CDS_ROUTER.dbo.ctrade_investment_clubs_members im left join CDSc.dbo.CashTransGroups ct on cds_number = member_cds_number left join CDS_ROUTER.dbo.trans_Groups tg on tg.CDS_Number = member_cds_number left join cds_router.dbo.Accounts_Clients_Web an on an.CDS_Number = member_cds_number where club_cds_number = '"+cdsNumber+ "'and member_active = 1 gROUP BY Forenames,Surname,tg.Company,member_cds_number,club_cds_number,member_phone,member_joined,member_title,GroupID";

            var clubMembers = new List<ClubMember>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    ClubMember member = new ClubMember
                    {

                        name = rdr["Names"].ToString(),
                        dateJoined = rdr["member_joined"].ToString(),
                        cdsnumber = rdr["member_cds_Number"].ToString(),
                        telephoneNumber = rdr["member_phone"].ToString(),
                        contribution = rdr["amount"].ToString(),
                        investment = rdr["TotalPortfolio"].ToString(),

                    };
                    clubMembers.Add(member);
                }
                recordActivityViewed(mcdsnumber,cdsNumber,"m");
                connection.Close();
            }

            return Json(clubMembers, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getClubInvestments(string gcdsnumber, string mcdsnumber)
        {
            var sql = "Declare @cds_number nvarchar(max) = '" + mcdsnumber + "',@group_cdsnumber nvarchar(max) = '" + gcdsnumber + "' select g.company, P.BOARD ,sum(g.shares) as units, p.InitialPrice , sum(g.shares)*p.InitialPrice as [Value], (select sum(shares) from cds_router.dbo.trans_Groups where GroupID=@group_cdsnumber and cds_Number=@cds_number and company=g.Company ) as [MyShare] from cds_router.dbo.trans_Groups g, testcds_ROUTER.dbo.para_company p where g.Company=p.Company and g.GroupID=@group_cdsnumber group by g.company, P.BOARD, p.InitialPrice";

            var clubInvestments = new List<ClubInvestments>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    ClubInvestments investment = new ClubInvestments
                    {
                        counter = rdr["company"].ToString(),
                        units = rdr["units"].ToString(),
                        type = rdr["BOARD"].ToString(),
                        price = rdr["InitialPrice"].ToString(),
                        value = rdr["Value"].ToString(),
                        myshare = rdr["MyShare"].ToString(),
                    };
                    clubInvestments.Add(investment);
                }

                connection.Close();
            }

            return Json(clubInvestments, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getClubContributions(string gcdsnumber)
        {
            var sql = "Declare @cdsnumber nvarchar (max) = '" + gcdsnumber + "' select sum(Amount) as balance, (select sum(Amount)from cdsc.dbo.CashTransGroups where CDS_NumberGroup =@cdsnumber and Amount > 0 ) as Total ,(select isnull(sum(Amount),0) from cdsc.dbo.CashTransGroups where CDS_NumberGroup = @cdsnumber and Amount < 0 ) as invested from cdsc.dbo.CashTransGroups where CDS_NumberGroup = @cdsnumber";

            var contributionCs = new List<ContributionC>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    ContributionC contributionC = new ContributionC
                    {
                        investedCont = rdr["invested"].ToString(),
                        totalCont = rdr["Total"].ToString(),
                        balanceCont = rdr["balance"].ToString(),
                    };
                    contributionCs.Add(contributionC);
                }

                connection.Close();
            }
            
            return Json(contributionCs, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getClubContributionList(string gcdsnumber, string mcdsnumber)
        {
            var sql = " select CDS_Number,member_active,isnull(member_exited,'1900-01-01') as member_exited,CONCAT(Forenames,' ',Surname) as name,isNull((select sum(Amount) as tot_cont from cdsc.dbo.CashTransGroups cg where cg.CDS_Number = aw.CDS_Number and CDS_NumberGroup = club_cds_number),0) as contribution from cds_router.dbo.ctrade_investment_clubs_members left join CDS_ROUTER.dbo.Accounts_Clients_Web aw on member_cds_number = CDS_Number where club_cds_number = '" + gcdsnumber+"'";

            var contributions = new List<Contribution>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Contribution contribution = new Contribution
                    {
                        cdsnumber = rdr["CDS_Number"].ToString(),
                        name = rdr["name"].ToString(),
                        contribution_ = rdr["contribution"].ToString(),
                        active = bool.Parse(rdr["member_active"].ToString()),
                        exit_date = DateTime.Parse(rdr["member_exited"].ToString()).ToString("dd MMM yyyy")
                    };
                    contributions.Add(contribution);
                }
                connection.Close();
                recordActivityViewed(mcdsnumber, gcdsnumber, "c");
            }
            
            return Json(contributions, JsonRequestBehavior.AllowGet); ;
        }
        public JsonResult getChairmanDetails(string cdsNumber,string mcdsnumber)
        {
            var sql = "select CDS_Number,concat(Forenames,' ',Surname) as chnames,mobile as chmobile,IDNoPP as chid from CDS_ROUTER.dbo.ctrade_investment_clubs_members left join  CDS_ROUTER.dbo.Accounts_Clients_Web on member_cds_number = CDS_Number where club_cds_number = '" + cdsNumber + "'and member_title = 'CHAIRMAN'";

            var chairmen = new List<Chairman>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Chairman chairman = new Chairman
                    {

                        name = rdr["chnames"].ToString(),
                        phone = rdr["chmobile"].ToString(),
                        cdsnumber = rdr["CDS_Number"].ToString(),
                        natId = rdr["chid"].ToString(),

                    };
                    chairmen.Add(chairman);
                }

                connection.Close();
            }
            tickReadMessage(cdsNumber, mcdsnumber);
            return Json(chairmen, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getMyContributions(string cdsnumber)
        {
            var sql = "select Forenames ,(select convert(numeric(18,2),isnull(sum(Amount),0)) as club_tot from cdsc.dbo.CashTransGroups where CDS_NumberGroup = ci.club_cds_number) as club_tot,(select convert(numeric(18,2),isnull(sum(Amount),0)) from cdsc.dbo.CashTransGroups where CDS_NumberGroup = ci.club_cds_number and CDS_Number = ci.member_cds_number) as my_tot from CDS_ROUTER.dbo.ctrade_investment_clubs_members ci left join CDS_ROUTER.dbo.Accounts_Clients_Web aw on aw.CDS_Number = ci.club_cds_number where member_cds_number = '" + cdsnumber + "'";

            var myContributions = new List<MyContributions>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MyContributions contributions = new MyContributions
                    {
                        group = rdr["Forenames"].ToString(),
                        clubTotal = rdr["club_tot"].ToString(),
                        myTotal = rdr["my_tot"].ToString(),
                    };
                    myContributions.Add(contributions);
                }

                connection.Close();
            }
            return Json(myContributions, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getMyInvestments(string cdsnumber)
        {
            var sql = "select Forenames,(select convert(numeric(18,2),isnull(sum(shares),0)) from CDS_ROUTER.dbo.trans_Groups where GroupID = ci.club_cds_number) as club_tot,(select convert(numeric(18,2),isnull(sum(shares),0)) from CDS_ROUTER.dbo.trans_Groups where GroupID = ci.club_cds_number and CDS_Number = ci.member_cds_number) as my_tot from CDS_ROUTER.dbo.ctrade_investment_clubs_members ci left join CDS_ROUTER.dbo.Accounts_Clients_Web aw on aw.CDS_Number = ci.club_cds_number where member_cds_number = '" + cdsnumber + "'";

            var myInvestiments = new List<MyInvestiments>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MyInvestiments investiment = new MyInvestiments
                    {
                        group = rdr["Forenames"].ToString(),
                        clubTotal = rdr["club_tot"].ToString(),
                        myTotal = rdr["my_tot"].ToString(),

                    };
                    myInvestiments.Add(investiment);
                }

                connection.Close();
            }
            return Json(myInvestiments, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getClubsAvailableOnCtradeByText(string text)
        {
            var sql = "select mobile,Forenames,CDS_Number,DOB,(select count(id) from cds_router.dbo.ctrade_investment_clubs_members where club_cds_number = CDS_Number) as members from CDS_ROUTER.dbo.ctrade_investment_clubs_members right join CDS_ROUTER.dbo.Accounts_Clients_Web on CDS_Number=club_cds_number where member_title = 'CHAIRMAN' and isPublic = 1 and forenames like '%" + text + "%'";

            var clubsAvailable = new List<CTradeInvestmentClubs>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    CTradeInvestmentClubs ctradeClubs = new CTradeInvestmentClubs
                    {

                        name = rdr["Forenames"].ToString(),
                        dateCreated = rdr["DOB"].ToString(),
                        cdsnumber = rdr["CDS_Number"].ToString(),
                        members = rdr["members"].ToString(),
                        club_phone = rdr["mobile"].ToString(),
                        portfolio = "0.0",//rdr["CDS_Number"].ToString(),
                        cash = "0.0",//rdr["CDS_Number"].ToString(),

                    };
                    clubsAvailable.Add(ctradeClubs);
                }

                connection.Close();
            }

            return Json(clubsAvailable, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getForexBidPurpose(string gcdsnumber)
        {
            var sql = "SELECT TOP 1000 [id],[purpose] FROM [CPayForex].[dbo].[para_bid_purpose]";

            var purposes = new List<Purpose>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Purpose purpose = new Purpose
                    {
                        id = rdr["id"].ToString(),
                        name = rdr["purpose"].ToString(),
                    };
                    purposes.Add(purpose);
                }

                connection.Close();
            }
            return Json(purposes, JsonRequestBehavior.AllowGet); ;
        }
        public JsonResult getForexBidSector(string gcdsnumber)
        {
            var sql = "SELECT TOP 1000 [id],[sector] FROM [CPayForex].[dbo].[para_bid_sector]";

            var sectors = new List<Sector>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Sector sector = new Sector
                    {
                        id = rdr["id"].ToString(),
                        name = rdr["sector"].ToString(),
                    };
                    sectors.Add(sector);
                }

                connection.Close();
            }
            return Json(sectors, JsonRequestBehavior.AllowGet); ;
        }
        public JsonResult getMyForeportfolio(string cdsnumber)
        {
            var sql = "SELECT TOP (1000) [ID],[Description],[state],[Amount],[DateCreated],[TransStatus],[CDS_Number],[Paid],[Reference],[preferredRate],[bidPurpose],[Rollover],[currency],[authorised]FROM[CPayForex].[dbo].[CPayWallet] where TransType = 'DEPOSIT' and CDS_Number = '" + cdsnumber + "' and state ='cleared' and transStatus =  1 and [Description] = 'SETTLEMENT DEPOSIT'";

            var contributionCs = new List<BidPortfolio>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    BidPortfolio orders = new BidPortfolio
                    {
                        Description = rdr["Description"].ToString(),
                        state = rdr["state"].ToString(),
                        amount = rdr["Amount"].ToString(),
                        currency = rdr["currency"].ToString(),
                        auctionId = rdr["Reference"].ToString(),
                        purpose = rdr["bidPurpose"].ToString(),
                        is_rollover = bool.Parse(rdr["Rollover"].ToString()),
                        datePosted = rdr["DateCreated"].ToString()
                    };
                    contributionCs.Add(orders);
                }

                connection.Close();
            }
            return Json(contributionCs, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getMyForexOrders(string cdsnumber)
        {
            var sql = "SELECT TOP (1000) [ID],[Description],TransType,[state],[Amount],[DateCreated],[TransStatus],[CDS_Number],[Paid],[Reference],[preferredRate],[bidPurpose],[Rollover],[currency],[authorised]FROM[CPayForex].[dbo].[CPayWallet] where TransType = 'Buy' and CDS_Number = '" + cdsnumber + "'";

            var contributionCs = new List<BidOrders>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    BidOrders orders = new BidOrders
                    {
                        TransType = rdr["TransType"].ToString(),
                        state = rdr["state"].ToString(),
                        amount = rdr["Amount"].ToString(),
                        preferredRate = rdr["preferredRate"].ToString(),
                        auctionId = rdr["Reference"].ToString(),
                        purpose = rdr["bidPurpose"].ToString(),
                        is_rollover = bool.Parse(rdr["Rollover"].ToString()),
                        datePosted = rdr["DateCreated"].ToString()
                    };
                    contributionCs.Add(orders);
                }

                connection.Close();
            }
            return Json(contributionCs, JsonRequestBehavior.AllowGet);
        }
        public JsonResult getMyForexStatement(string cdsnumber)
        {
            var sql = "SELECT TOP (1000) [ID],[Description],[TransType],[Amount],[DateCreated],[TransStatus],[CDS_Number],[Paid],[Reference],[preferredRate],[bidPurpose],[Rollover],[currency],[authorised]FROM[CPayForex].[dbo].[CPayWallet] where CDS_Number = '" + cdsnumber + "'";

            var fxstatement = new List<Statement>();

            using (SqlConnection connection = new SqlConnection(connectionStringCDS_Router))
            {
                SqlCommand cmd = new SqlCommand(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                connection.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Statement statement = new Statement
                    {
                        amount = rdr["Amount"].ToString(),
                        currency = rdr["currency"].ToString(),
                        transaction_type = rdr["TransType"].ToString(),
                        date_created = rdr["DateCreated"].ToString(),
                        authorised = bool.Parse(rdr["authorised"].ToString()),
                    };
                    fxstatement.Add(statement);
                }
                connection.Close();
            }
            return Json(fxstatement, JsonRequestBehavior.AllowGet);
        }
        public JsonResult exitInvestmentClub(string gcdsnumber, string mcdsnumber)
        {

            var atsDbContext = new AtsDbContext();

            var orders = atsDbContext.Pre_Order_Live.FirstOrDefault(x => x.CDS_AC_No == gcdsnumber && x.OrderStatus == "OPEN");

            if (orders == null)
            {
                try
                {
                    string sqlx = "update cds_router.dbo.ctrade_investment_clubs_members set member_active = 0,member_exited = getdate()  where club_cds_number = '" + gcdsnumber + "' and member_cds_number = '" + mcdsnumber + "'";


                    using (SqlConnection connectionsx = new SqlConnection(connectionStringCDS_Router))
                    {
                        SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                        connectionsx.Open();
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();

                        CustomResponses cr;

                        if (Desolvemember(mcdsnumber, gcdsnumber))
                        {
                            cr = new CustomResponses()
                            {
                                status = true,
                                message = "You Have Successfully Exited This Club.Your Investments Have Been Credited To Your CTrade Main Account Account"
                            };

                            recordClubActivity(gcdsnumber, "e");
                        }
                        else
                        {
                            cr = new CustomResponses()
                            {
                                status = true,
                                message = "You Have Successifully Exited The Club.But Failed to Desolve Your Shares Please Contact The CTrade Team"
                            };
                            recordClubActivity(gcdsnumber, "e");
                        }
                        return Json(cr, JsonRequestBehavior.AllowGet);

                    }

                }
                catch (Exception e)
                {
                    Console.Write(e.ToString());
                    CustomResponses cr = new CustomResponses()
                    {
                        status = false,
                        message = "Failed To Remove You From This Club At The Moment.Please Try Again Later"
                    };
                    return Json(cr, JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                CustomResponses cr = new CustomResponses()
                {
                    status = false,
                    message = "Could Not Exit At This Moment As There Are Still 'OPEN' Orders In This Club"
                };
                return Json(cr, JsonRequestBehavior.AllowGet);
            }
        }
        private bool tickReadMessage(string gcdsnumber, string mcdsnumber)
        {
            try
            {
                string sqlx = " update CDS_ROUTER.dbo.ctrade_investment_clubs_members set readMessage = 1 where club_cds_number ='" + gcdsnumber + "' and member_cds_number = '" + mcdsnumber + "'";

                using (SqlConnection connectionsx = new SqlConnection(connectionStringCDS_Router))
                {
                    SqlCommand cmd = new SqlCommand(sqlx, connectionsx);
                    connectionsx.Open();
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    connectionsx.Close();
                    return true;
                }

            }
            catch (Exception e)
            {
                Console.Write(e.Message.ToString());
                return false;

            }
        }
    }
}