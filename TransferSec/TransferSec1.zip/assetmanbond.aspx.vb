﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO

Partial Class Assetmanbond
    Inherits System.Web.UI.Page
    Dim constr As String = (System.Configuration.ConfigurationManager.AppSettings("connpath"))
    Dim cn As New SqlConnection(constr)
    Dim cmd As SqlCommand
    Dim adp As SqlDataAdapter
    Dim ds As New DataSet
    Dim maxholder As Integer = 0
    Public Sub msgbox(ByVal strMessage As String)

        'finishes server processing, returns to client.
        Dim strScript As String = "<script language=JavaScript>"
        strScript += "window.alert(""" & strMessage & """);"
        strScript += "</script>"
        Dim lbl As New System.Web.UI.WebControls.Label
        lbl.Text = strScript
        Page.Controls.Add(lbl)

    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'loadModules()

        Page.MaintainScrollPositionOnPostBack = True
        If (Not IsPostBack) Then
            'getcompanies()
            ' Getorders()
            'loadModules()
            getcompanies()
            loadcomboforassetmanagers()


        End If
        If Session("finish") = "yes" Then
            Session("finish") = ""
            msgbox("Sent for Approval")
        End If
    End Sub

    Public Sub loadcomboforassetmanagers()
        Dim dsport As New DataSet
        cmd = New SqlCommand("select AssetManagerCode as code, p.AssetMananger from  para_AssetManager p", cn)
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dsport, "trans")
        If (dsport.Tables(0).Rows.Count > 0) Then
            cmbassetmanager.DataSource = dsport
            cmbassetmanager.TextField = "AssetMananger"
            cmbassetmanager.ValueField = "code"
            cmbassetmanager.DataBind()

            cmbassetmanager0.DataSource = dsport
            cmbassetmanager0.TextField = "AssetMananger"
            cmbassetmanager0.ValueField = "code"
            cmbassetmanager0.DataBind()

        End If
    End Sub

    'Public Sub Getorders()
    '    Try
    '        Dim ds As New DataSet
    '        cmd = New SqlCommand("select fund,Client_Account ,Client_Name , Total_Units ,TransType from UnitAccounts ", cn)
    '        adp = New SqlDataAdapter(cmd)
    '        adp.Fill(ds, "para_lendingRules")
    '        If (ds.Tables(0).Rows.Count > 0) Then
    '            grdRules.DataSource = ds.Tables(0)
    '            grdRules.DataBind()
    '        Else
    '            grdRules.DataSource = Nothing
    '            grdRules.DataBind()
    '        End If
    '    Catch ex As Exception
    '        msgbox(ex.Message)
    '    End Try
    'End Sub















    Protected Sub btnupload_Click(sender As Object, e As EventArgs)

        If fileupload1.HasFile Then
            Dim connectionString As String = ""
            Dim fileName2 As String = Path.GetFileName(fileupload1.PostedFile.FileName)


            Dim fileLocation As String = Server.MapPath("~/uploads/recon_" & Date.Now.ToString("ddMMyyyymmsss") & fileName2)
            fileupload1.SaveAs(fileLocation)
            Dim fileExtension As String = Path.GetExtension(fileupload1.PostedFile.FileName)
            If fileExtension = ".xls" Then
                connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 8.0;HDR=No;IMEX=1"""
            ElseIf fileExtension = ".xlsx" Then
                connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0;HDR=No;IMEX=1"""
            Else
                msgbox("File Type Invalid")
                Exit Sub
            End If
            'Create OleDB Connection and OleDb Command

            Dim conn As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand()

            cmd.CommandType = System.Data.CommandType.Text
            cmd.Connection = conn

            Dim dAdapter As New OleDbDataAdapter(cmd)

            Dim dtExcelRecords As New DataTable()

            conn.Open()

            Dim dtExcelSheetName As DataTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
            Dim getExcelSheetName As String = dtExcelSheetName.Rows(0)("Table_Name").ToString()
            cmd.CommandText = "Select * FROM [" & getExcelSheetName & "]"
            dAdapter.SelectCommand = cmd
            dAdapter.Fill(dtExcelRecords)





            Dim x As Integer = 0
            For x = 1 To dtExcelRecords.Rows.Count - 1                                                                                                                                                                                      '                                                                                                                                                                                                                                                                                                                               ImportID,Company,Date_trade,CDS_Ref,Date_Settlement,Client_Id,Other_Names,Surname,Buy_Sell,Quantity,Price,UploadDate)
                '                                                                                                                                                                                                                  ImportID,                      Date_trade,                                         CDS_Ref,                                             Date_Settlement,                                        Client_Id,                             Surname,                                        Buy_Sell,                                        Quantity,                                   Price,                                              UploadDate
                Dim dr = dtExcelRecords.Rows(x)

                Dim cmd2 As New SqlCommand
                Dim cmdStr As String = "insert into Recon_AssetManager ([DateUploaded] ,[ForDate] ,[AccountNumber] ,[CSDAccount] ,[Name] ,[AssetManager],[Company] ,[Units] ,[MarketValue],[UploadedBy],[SystemUploadBy], [RecordDate]) values (@DateUploaded ,@ForDate ,@AccountNumber ,@CSDAccount ,@Name ,@AssetManager,@Company ,@Units ,@MarketValue,@UploadedBy,@SystemUploadBy, getdate())"
                cmd2 = New SqlCommand(cmdStr, cn)
                cmd2.Parameters.AddWithValue("@DateUploaded", dr.Item(0).ToString)
                cmd2.Parameters.AddWithValue("@ForDate", dtdate.Text)
                cmd2.Parameters.AddWithValue("@AccountNumber", dr.Item(1).ToString)
                cmd2.Parameters.AddWithValue("@CSDAccount", dr.Item(2).ToString)
                cmd2.Parameters.AddWithValue("@Name", dr.Item(3).ToString)
                cmd2.Parameters.AddWithValue("@AssetManager", dr.Item(4).ToString)
                cmd2.Parameters.AddWithValue("@Company", dr.Item(5).ToString)
                cmd2.Parameters.AddWithValue("@Units", dr.Item(6).ToString)
                cmd2.Parameters.AddWithValue("@MarketValue", dr.Item(7).ToString)
                cmd2.Parameters.AddWithValue("@UploadedBy", dr.Item(8).ToString)
                cmd2.Parameters.AddWithValue("@SystemUploadBy", Session("Username"))





                Try
                    cn.Open()
                    cmd2.ExecuteNonQuery()
                    cn.Close()
                Catch ex As Exception

                End Try


            Next
            conn.Close()
            'Return True
        Else
            'Return False
        End If
        msgbox("upload successful")
        'inserttoTrans()
        'cleartable()

        ' Getorders()

    End Sub

    Public Sub cleartable()
        cmd = New SqlCommand("truncate table unitAccounts  ", cn)
        If (cn.State = ConnectionState.Open) Then
            cn.Close()
        End If
        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()
    End Sub
    'Public Sub inserttoTrans()
    '    cmd = New SqlCommand("insert into [CDS_ROUTER].[dbo].[trans](Company, CDS_Number, Update_Type, Shares, Date_Created, Trans_Time, Created_By, source) (Select  u.fund,u.client_Account,'crediting' , CASE TRANSTYPE  WHEN  'Purchase'   THEN convert(numeric (18,10) ,replace(total_units,',','')) ELSE  convert(numeric (18,10) ,replace(total_units,',','')) * -1 END AS totalunits ,getdate(),getdate(),'Escrow' ,'unittrusts' from unitAccounts u  where u.client_Account in (select CDS_Number from  [CDS_ROUTER].[dbo].[Accounts_Clients_Web])) ", cn)
    '    If (cn.State = ConnectionState.Open) Then
    '        cn.Close()
    '    End If
    '    cn.Open()
    '    cmd.ExecuteNonQuery()
    '    cn.Close()
    'End Sub
    Dim sCommand As SqlCommand
    Dim sAdapter As SqlDataAdapter
    Dim sBuilder As SqlCommandBuilder
    Dim sDs As DataSet
    Dim sTable As DataTable





    Public Sub loadModules()
        Try
            cmd = New SqlCommand("SELECT Company as company, CDS_Number as cdsnumber, Date_Created as datecreated, Shares as shares FROM [CDS_Router].[dbo].[trans] WHERE CDS_Number NOT IN (SELECT CDS_Number FROM trans)", cn)
            adp = New SqlDataAdapter(cmd)
            Dim ds1 As New DataSet
            ds1.Clear()
            adp.Fill(ds1, "company")
            If ds1.Tables(0).Rows.Count > 0 Then
                ASPxGridView2.DataSource = ds1.Tables(0)
            Else
                ASPxGridView2.DataSource = Nothing
            End If
            ASPxGridView2.DataBind()
        Catch ex As Exception

            MesgBox(ex.Message)
        End Try
    End Sub
    Public Sub getcompanies()
        cmd = New SqlCommand("SELECT distinct company from trans", cn)
        adp = New SqlDataAdapter(cmd)
        Dim ds1 As New DataSet
        ds1.Clear()
        adp.Fill(ds1, "company")
        If ds1.Tables(0).Rows.Count > 0 Then
            cmbcompany.DataSource = ds1
            cmbcompany.TextField = "company"
            cmbcompany.ValueField = "company"
            cmbcompany.DataBind()
        End If
    End Sub
    Public Sub loadModules2()
        Try
            cmd = New SqlCommand("SELECT Company as company, CDS_Number as cdsnumber, Date_Created as datecreated, Shares as shares FROM [trans] WHERE CDS_Number NOT IN (SELECT CDS_Number FROM  [CDS_Router].[dbo].[trans] )", cn)
            adp = New SqlDataAdapter(cmd)
            Dim ds1 As New DataSet
            ds1.Clear()
            adp.Fill(ds1, "company")
            If ds1.Tables(0).Rows.Count > 0 Then
                ASPxGridView2.DataSource = ds1.Tables(0)
            Else
                ASPxGridView2.DataSource = Nothing
            End If
            ASPxGridView2.DataBind()
        Catch ex As Exception

            MesgBox(ex.Message)
        End Try
    End Sub
    Public Sub loadModules3()
        Try
            cmd = New SqlCommand("Select sum(Shares) as [shares], (select '500') as CDC_Balance, cds_number from trans group by cds_number having sum(shares)>0", cn)
            adp = New SqlDataAdapter(cmd)
            Dim ds1 As New DataSet
            ds1.Clear()
            adp.Fill(ds1, "company")
            If ds1.Tables(0).Rows.Count > 0 Then
                ASPxGridView2.DataSource = ds1.Tables(0)
            Else
                ASPxGridView2.DataSource = Nothing
            End If
            ASPxGridView2.DataBind()
        Catch ex As Exception

            MesgBox(ex.Message)
        End Try
    End Sub
    Private Sub MesgBox(ByVal sMessage As String)
        Dim msg As String
        msg = "<script language='javascript'>"
        msg += "alert('" & sMessage & "');"
        msg += "<" & "/script>"
        Response.Write(msg)
    End Sub

    Protected Sub cmbtype_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbtype.SelectedIndexChanged

    End Sub
    Protected Sub btnupload0_Click(sender As Object, e As EventArgs) Handles btnupload0.Click
        Try
            If cmbtype.SelectedItem.Text = "Exceptions" Then
                cmd = New SqlCommand("declare @company nvarchar(50)='" + cmbcompany.SelectedItem.Text + "';  declare @date date='" + dtdateview.Text + "' select *, case when j.variance>0 then 'Less units at Asset Manager' when j.Variance<0 then 'More units at Asset Manager' else 'Balancing' end as [Status] from ( select t.cds_number as [Account No], a.Surname+' '+a.Forenames as [Names],   t.Company as [Security], isnull(sum(t.shares),0) as [C-Trade Holding],   (select isnull(sum(units),0) from Recon_AssetManager where company=t.Company and AccountNumber=t.CDS_Number and convert(date, dateUploaded)='" + dtdateview.Date + "' and AssetManager='" + cmbassetmanager0.SelectedItem.Value.ToString + "') as [Asset Manager Holding]  ,isnull(sum(t.shares),0)-  (select isnull(sum(units),0) from Recon_AssetManager where company=t.Company and AccountNumber=t.CDS_Number and convert(date, dateUploaded)='" + dtdateview.Date + "' and AssetManager='" + cmbassetmanager0.SelectedItem.Value.ToString + "') as [Variance]  from trans t, Accounts_Clients a where a.CDS_Number = t.CDS_Number  and Company=@company  and convert(date, t.date_created)<=@date and AssetManager='" + cmbassetmanager0.SelectedItem.Value.ToString + "'  group by t.CDS_Number, a.Surname, a.Forenames, t.Company) j ", cn)
            Else
                cmd = New SqlCommand("select AccountNumber as [Account No], [Name], AssetManager, Company as [Security], Units, MarketValue, RecordDate from Recon_AssetManager where company='" + cmbcompany.SelectedItem.Text + "' and AssetManager='" + cmbassetmanager0.SelectedItem.Value.ToString + "' and convert(date, Dateuploaded)<='" + dtdateview.Text + "' and AccountNumber not in (select cds_number from Accounts_clients)", cn)
            End If

            adp = New SqlDataAdapter(cmd)
            Dim ds1 As New DataSet
            ds1.Clear()
            adp.Fill(ds1, "company")
            If ds1.Tables(0).Rows.Count > 0 Then
                ASPxGridView2.DataSource = ds1.Tables(0)
            Else
                ASPxGridView2.DataSource = Nothing
            End If
            ASPxGridView2.DataBind()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

End Class
